import sys, os
import data_quality_helper

python_path = sys.argv[1]
lib_path = sys.argv[2]
config_path = sys.argv[3]
batch_id = sys.argv[4]
bow_id = sys.argv[5]
logical_deletion_indicator = sys.argv[6]
load_number = sys.argv[7]
batch_exec_id = sys.argv[8]
sbow_id = sys.argv[9]
file_crm_ingestion = sys.argv[10]

print("(python_path) " + python_path)
print("(lib_path) " + lib_path)
print("(config_path) " + config_path)
print("Arguments are : arg 1 (batch_id) " + batch_id)
print("Arguments are : arg 2 (bow_id) " + bow_id)
print("Arguments are : arg 3 (logical_deletion_indicator) " + logical_deletion_indicator)
print("Arguments are : arg 4 (load_number) " + load_number)
print("Arguments are : arg 5 (batch_exec_id) " + batch_exec_id)
print("Arguments are : arg 6 (sbow_id) " + sbow_id)
print("Arguments are : arg 7 (file_crm_ingestion) " + file_crm_ingestion)

table_config = config_path.rstrip('/') + '/table_config.ini'
props = data_quality_helper.read_all_properties(table_config)

mode = props['DEPLOY_MODE']
exec_mem = props['EXECUTOR_MEMORY']
num_exec = props['NUM_OF_EXECUTOR']
queue = props['JOB_QUEUE']
cores = props['EXECUTOR_CORES']
hive_config = props['HIVE_CONFIG_PATH']

script_path = python_path.rstrip('/') + '/table_validation.py'
file_path = python_path.rstrip('/') + '/table_ingestion.py,' + python_path.rstrip('/') + '/data_quality_helper.py,' + python_path.rstrip('/') + '/data_quality_configuration.py'
arguments = batch_id + ' ' + bow_id + ' ' + logical_deletion_indicator + ' ' + load_number + ' ' + batch_exec_id + ' ' + sbow_id + ' ' + file_crm_ingestion + ' ' + config_path.rstrip('/') + '/table_config.ini'
jar_file = lib_path.rstrip('/') + '/spark-avro_2.10-3.1.0.jar'

#spark_submit = 'export SPARK_MAJOR_VERSION=2; spark-submit --master yarn --deploy-mode ' + mode + ' --jars ' + jar_file + ' --executor-memory ' + exec_mem + ' --num-executors ' + num_exec + ' --executor-cores ' + cores + ' --queue ' + queue + ' --py-files ' + file_path + ' --files ' + hive_config + ' ' + script_path + ' ' + arguments
spark_submit = 'export SPARK_MAJOR_VERSION=2; spark-submit --master local[*]' + ' --jars ' + jar_file + ' --py-files ' + file_path + ' --files ' + hive_config + ' ' + script_path + ' ' + arguments
os.system(spark_submit)
