import sys, os
import data_quality_helper as file_helper

python_path = sys.argv[1]
lib_path = sys.argv[2]
config_path = sys.argv[3]
batch_id = sys.argv[4]
bow_id = sys.argv[5]
logical_deletion_indicator = sys.argv[6]
load_number = sys.argv[7]
batch_exec_id = sys.argv[8]
sbow_id = sys.argv[9]


print("(python_path) " + python_path)
print("(lib_path) " + lib_path)
print("(config_path) " + config_path)
print("Arguments are : arg 1 (batch_id) " + batch_id)
print("Arguments are : arg 2 (bow_id) " + bow_id)
print("Arguments are : arg 3 (logical_deletion_indicator) " + logical_deletion_indicator)
print("Arguments are : arg 4 (load_number) " + load_number)
print("Arguments are : arg 5 (batch_exec_id) " + batch_exec_id)
print("Arguments are : arg 6 (sbow_id) " + sbow_id)

FILE_CONFIG = config_path.rstrip('/') + '/file_config.ini'
script_name = 'python ' + python_path.rstrip('/') + '/file_validation.py'


props = file_helper.read_all_properties(FILE_CONFIG)

#commented below code @ 06th jan 2019
#user = props['USER']
#keytab = props['KEYTAB']
#os.system('pbrun su - ' + user)
#os.system(keytab)

all_parameter_obj = file_helper.load_file_control_ingestion(props, batch_id, bow_id)
for parameter_obj in all_parameter_obj:
    args = [script_name, parameter_obj.source_file_path, parameter_obj.hdfs_good_path, parameter_obj.hdfs_reject_path, parameter_obj.file_landing_path, load_number, logical_deletion_indicator, python_path, parameter_obj.log_path, 'dummy', parameter_obj.lz_table_name, parameter_obj.delimiter, 'dummy', parameter_obj.extension, parameter_obj.type_of_load, parameter_obj.is_compressed, parameter_obj.compression_format, parameter_obj.is_file_vlaidation, parameter_obj.is_control_file, parameter_obj.is_audit_file, parameter_obj.is_header_included, 'dummy', parameter_obj.is_part_file, parameter_obj.is_rev_id, parameter_obj.is_src_sys_cd_seq, 'dummy', lib_path, config_path, batch_exec_id, sbow_id, batch_id, bow_id, parameter_obj.uow_id, parameter_obj.job_name, parameter_obj.timestamp_format, parameter_obj.archive_file_path, parameter_obj.audit_code]
    exec_command = ' '.join(args)
    print(exec_command)
    os.system(exec_command)
