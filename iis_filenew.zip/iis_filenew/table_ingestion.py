from pyspark.sql.functions import unix_timestamp, from_unixtime, substring, concat, lit
from pyspark.sql.types import IntegerType
from datetime import datetime


def insert_data(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table, ):

    #unique_records_df.show(5)
    # unique_records_df.write.mode("overwrite").saveAsTable(good_table)
    spark.sql("SET hive.exec.dynamic.partition = true")
    spark.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
    # Truncate and Load
    unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType())).write.mode("append").format("avro").insertInto(good_table, overwrite=False)

    if count_error_records > 0:
        error_records.write.mode("append").format("text").insertInto(reject_table, overwrite=False)
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]