class JobParameterIngestion(object):

    def __init__(self, insert_gmt_timestamp, batch_number, uow_id, job_name, lz_table_name, stage_table_name, hst_table_name, number_of_days_count, active_flag, delete_flag, release_number, pattern, bow_id, devconn_id, itgconn_id, prodconn_id, filedelimiter, dry_run_flag):
        self._insert_gmt_timestamp = insert_gmt_timestamp
        self._batch_number = batch_number
        self._uow_id = uow_id
        self._job_name = job_name
        self._lz_table_name = lz_table_name
        self._stage_table_name = stage_table_name
        self._hst_table_name = hst_table_name
        # self._source_query_text = source_query_text
        self._number_of_days_count = number_of_days_count
        self._active_flag = active_flag
        self._delete_flag = delete_flag
        self._release_number = release_number
        self._pattern = pattern
        self._bow_id = bow_id
        self._devconn_id = devconn_id
        self._itgconn_id = itgconn_id
        self._prodconn_id = prodconn_id
        self._filedelimiter = filedelimiter
        # self._dryrunquery = dryrunquery
        self._dry_run_flag = dry_run_flag

    @property
    def insert_gmt_timestamp(self):
        return self._insert_gmt_timestamp

    @insert_gmt_timestamp.setter
    def insert_gmt_timestamp(self, value):
        self._insert_gmt_timestamp = value

    @property
    def batch_number(self):
        return self._batch_number

    @batch_number.setter
    def batch_number(self, value):
        self._batch_number = value

    @property
    def uow_id(self):
        return self._uow_id

    @uow_id.setter
    def uow_id(self, value):
        self._uow_id = value

    @property
    def job_name(self):
        return self._job_name

    @job_name.setter
    def job_name(self, value):
        self._job_name = value

    @property
    def lz_table_name(self):
        return self._lz_table_name

    @lz_table_name.setter
    def lz_table_name(self, value):
        self._lz_table_name = value

    @property
    def stage_table_name(self):
        return self._stage_table_name

    @stage_table_name.setter
    def stage_table_name(self, value):
        self._stage_table_name = value

    @property
    def hst_table_name(self):
        return self._hst_table_name

    @hst_table_name.setter
    def hst_table_name(self, value):
        self._hst_table_name = value

    # @property
    # def source_query_text(self):
    #     return self._source_query_text
    #
    # @source_query_text.setter
    # def source_query_text(self, value):
    #     self._source_query_text = value

    @property
    def number_of_days_count(self):
        return self._number_of_days_count

    @number_of_days_count.setter
    def number_of_days_count(self, value):
        self._number_of_days_count = value

    @property
    def active_flag(self):
        return self._active_flag

    @active_flag.setter
    def active_flag(self, value):
        self._active_flag = value

    @property
    def delete_flag(self):
        return self._delete_flag

    @delete_flag.setter
    def delete_flag(self, value):
        self._delete_flag = value

    @property
    def release_number(self):
        return self._release_number

    @release_number.setter
    def release_number(self, value):
        self._release_number = value

    @property
    def pattern(self):
        return self._pattern

    @pattern.setter
    def pattern(self, value):
        self._pattern = value

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def devconn_id(self):
        return self._devconn_id

    @devconn_id.setter
    def devconn_id(self, value):
        self._devconn_id = value

    @property
    def itgconn_id(self):
        return self._itgconn_id

    @itgconn_id.setter
    def itgconn_id(self, value):
        self._itgconn_id = value

    @property
    def prodconn_id(self):
        return self._prodconn_id

    @prodconn_id.setter
    def prodconn_id(self, value):
        self._prodconn_id = value

    @property
    def filedelimiter(self):
        return self._filedelimiter

    @filedelimiter.setter
    def filedelimiter(self, value):
        self._filedelimiter = value

    # @property
    # def dryrunquery(self):
    #     return self._dryrunquery
    #
    # @dryrunquery.setter
    # def dryrunquery(self, value):
    #     self._dryrunquery = value

    @property
    def dry_run_flag(self):
        return self._dry_run_flag

    @dry_run_flag.setter
    def dry_run_flag(self, value):
        self._dry_run_flag = value

    @staticmethod
    def populate_job_parameter_ingestion(self, data):
        return JobParameterIngestion(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17])


class FileControlIngestion(object):

    def __init__(self, batch_id, bow_id, uow_id, source_file_path, lz_table_name, hst_table_name, reject_table_name, file_pattern, timestamp_pattern, source_system_identifier, extension, delimiter, type_of_load, is_part_file, is_compressed, compression_format, is_file_vlaidation, is_audit_file, is_control_file, is_header_included, hdfs_good_path, hdfs_reject_path, file_landing_path, log_path, touch_file_path, insert_time_stamp, update_time_stamp, userid, active_flag, job_name, is_rev_id, is_src_sys_cd_seq, timestamp_format, archive_file_path, audit_code):
        self._batch_id = batch_id
        self._bow_id = bow_id
        self._uow_id = uow_id
        self._source_file_path = source_file_path
        self._lz_table_name = lz_table_name
        self._hst_table_name = hst_table_name
        self._reject_table_name = reject_table_name
        self._file_pattern = file_pattern
        self._timestamp_pattern = timestamp_pattern
        self._source_system_identifier = source_system_identifier
        self._extension = extension
        self._delimiter = delimiter
        self._type_of_load = type_of_load
        self._is_part_file = is_part_file
        self._is_compressed = is_compressed
        self._compression_format = compression_format
        self._is_file_vlaidation = is_file_vlaidation
        self._is_audit_file = is_audit_file
        self._is_control_file = is_control_file
        self._is_header_included = is_header_included
        self._hdfs_good_path = hdfs_good_path
        self._hdfs_reject_path = hdfs_reject_path
        self._file_landing_path = file_landing_path
        self._log_path = log_path
        self._touch_file_path = touch_file_path
        self._insert_time_stamp = insert_time_stamp
        self._update_time_stamp = update_time_stamp
        self._userid = userid
        self._active_flag = active_flag
        self._job_name = job_name
        self._is_rev_id = is_rev_id
        self._is_src_sys_cd_seq = is_src_sys_cd_seq
        self._timestamp_format = timestamp_format
        # self._zip_file_pattern = zip_file_pattern
        self._archive_file_path = archive_file_path
        self._audit_code = audit_code

    @property
    def batch_id(self):
        return self._batch_id

    @batch_id.setter
    def batch_id(self, value):
        self._batch_id = value

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def uow_id(self):
        return self._uow_id

    @uow_id.setter
    def uow_id(self, value):
        self._uow_id = value

    @property
    def source_file_path(self):
        return self._source_file_path

    @source_file_path.setter
    def source_file_path(self, value):
        self._source_file_path = value

    @property
    def lz_table_name(self):
        return self._lz_table_name

    @lz_table_name.setter
    def lz_table_name(self, value):
        self._lz_table_name = value

    @property
    def hst_table_name(self):
        return self._hst_table_name

    @hst_table_name.setter
    def hst_table_name(self, value):
        self._hst_table_name = value

    @property
    def reject_table_name(self):
        return self._reject_table_name

    @reject_table_name.setter
    def reject_table_name(self, value):
        self._reject_table_name = value

    @property
    def file_pattern(self):
        return self._file_pattern

    @file_pattern.setter
    def file_pattern(self, value):
        self._file_pattern = value

    @property
    def timestamp_pattern(self):
        return self._timestamp_pattern

    @timestamp_pattern.setter
    def timestamp_pattern(self, value):
        self._timestamp_pattern = value

    @property
    def source_system_identifier(self):
        return self._source_system_identifier

    @source_system_identifier.setter
    def source_system_identifier(self, value):
        self._source_system_identifier = value

    @property
    def extension(self):
        return self._extension

    @extension.setter
    def extension(self, value):
        self._extension = value

    @property
    def delimiter(self):
        return self._delimiter

    @delimiter.setter
    def delimiter(self, value):
        self._delimiter = value

    @property
    def type_of_load(self):
        return self._type_of_load

    @type_of_load.setter
    def type_of_load(self, value):
        self._type_of_load = value

    @property
    def is_part_file(self):
        return self._is_part_file

    @is_part_file.setter
    def is_part_file(self, value):
        self._is_part_file = value

    @property
    def is_compressed(self):
        return self._is_compressed

    @is_compressed.setter
    def is_compressed(self, value):
        self._is_compressed = value

    @property
    def compression_format(self):
        return self._compression_format

    @compression_format.setter
    def compression_format(self, value):
        self._compression_format = value

    @property
    def is_file_vlaidation(self):
        return self._is_file_vlaidation

    @is_file_vlaidation.setter
    def is_file_vlaidation(self, value):
        self._is_file_vlaidation = value

    @property
    def is_audit_file(self):
        return self._is_audit_file

    @is_audit_file.setter
    def is_audit_file(self, value):
        self._is_audit_file = value

    @property
    def is_control_file(self):
        return self._is_control_file

    @is_control_file.setter
    def is_control_file(self, value):
        self._is_control_file = value

    @property
    def is_header_included(self):
        return self._is_header_included

    @is_header_included.setter
    def is_header_included(self, value):
        self._is_header_included = value

    @property
    def hdfs_good_path(self):
        return self._hdfs_good_path

    @hdfs_good_path.setter
    def hdfs_good_path(self, value):
        self._hdfs_good_path = value

    @property
    def hdfs_reject_path(self):
        return self._hdfs_reject_path

    @hdfs_reject_path.setter
    def hdfs_reject_path(self, value):
        self._hdfs_reject_path = value

    @property
    def file_landing_path(self):
        return self._file_landing_path

    @file_landing_path.setter
    def file_landing_path(self, value):
        self._file_landing_path = value

    @property
    def log_path(self):
        return self._log_path

    @log_path.setter
    def log_path(self, value):
        self._log_path = value

    @property
    def touch_file_path(self):
        return self._touch_file_path

    @touch_file_path.setter
    def touch_file_path(self, value):
        self._touch_file_path = value

    @property
    def insert_time_stamp(self):
        return self._insert_time_stamp

    @insert_time_stamp.setter
    def insert_time_stamp(self, value):
        self._insert_time_stamp = value

    @property
    def update_time_stamp(self):
        return self._update_time_stamp

    @update_time_stamp.setter
    def update_time_stamp(self, value):
        self._update_time_stamp = value

    @property
    def userid(self):
        return self._userid

    @userid.setter
    def userid(self, value):
        self._userid = value

    @property
    def active_flag(self):
        return self._active_flag

    @active_flag.setter
    def active_flag(self, value):
        self._active_flag = value

    @property
    def job_name(self):
        return self._job_name

    @job_name.setter
    def job_name(self, value):
        self._job_name = value

    @property
    def is_rev_id(self):
        return self._is_rev_id

    @is_rev_id.setter
    def is_rev_id(self, value):
        self._is_rev_id = value

    @property
    def is_src_sys_cd_seq(self):
        return self._is_src_sys_cd_seq

    @is_src_sys_cd_seq.setter
    def is_src_sys_cd_seq(self, value):
        self._is_src_sys_cd_seq = value

    @property
    def timestamp_format(self):
        return self._timestamp_format

    @timestamp_format.setter
    def timestamp_format(self, value):
        self._timestamp_format = value

    # @property
    # def zip_file_pattern(self):
    #     return self._zip_file_pattern
    #
    # @zip_file_pattern.setter
    # def zip_file_pattern(self, value):
    #     self._zip_file_pattern = value

    @property
    def archive_file_path(self):
        return self._archive_file_path

    @archive_file_path.setter
    def archive_file_path(self, value):
        self._archive_file_path = value

    @property
    def audit_code(self):
        return self._audit_code

    @audit_code.setter
    def audit_code(self, value):
        self._audit_code = value

    @staticmethod
    def populate_file_control_ingestion(self, data):
        return FileControlIngestion(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17], data[18], data[19], data[20], data[21], data[22], data[23], data[24], data[25], data[26], data[27], data[28], data[29], data[30], data[31], data[32], data[33], data[34])
