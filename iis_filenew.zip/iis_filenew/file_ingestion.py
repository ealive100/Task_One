from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, from_unixtime
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType,DecimalType
from datetime import datetime
import sys
import data_quality_helper as file_helper

file = sys.argv[1]
source_table_name = sys.argv[2]
doPreProcess = sys.argv[3]
load_number = sys.argv[4]
logical_deletion_indicator = sys.argv[5]
config_path = sys.argv[6]
log_path = sys.argv[7]
touch_path = sys.argv[8]
sheet_or_split = sys.argv[9]
source_system_identifier = sys.argv[10]
file_type = sys.argv[11]
is_part_file = sys.argv[12]
is_header_included = sys.argv[13]
is_control_file_included = sys.argv[14]
record_count = sys.argv[15]
batch_exec_id = sys.argv[16]
sbow_id = sys.argv[17]
batch_id = sys.argv[18]
bow_id = sys.argv[19]
uow_id = sys.argv[20]
job_name = sys.argv[21]
time_value = sys.argv[22]
time_format = sys.argv[23]
landing_path = sys.argv[24]

file_config = config_path.rstrip('/') + '/file_config.ini'
new_time_value = datetime.strptime(time_value, time_format).strftime('%Y-%m-%d %H:%M:%S.%f')
aux_control_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("bow_name", StringType(), True), StructField("cdc_start_timestamp", StringType(), True),StructField("cdc_end_timestamp", StringType(), True), StructField("prev_cdc_start_timestamp", TimestampType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),StructField("uow_unique_id", StringType(), True), StructField("cdc_type_description", StringType(), True), StructField("change_data_capture_last_sequence_number", DecimalType(), True),StructField("previous_change_data_capture_last_sequence_number", DecimalType(), True), StructField("insert_gmt_timestamp", StringType(), True), StructField("batch_execution_id", StringType(), True)])

file_name = file.split('/')[-1].rstrip('.' + file_type)
spark = SparkSession.builder.enableHiveSupport().appName(file_name).getOrCreate()
log4jLogger = spark.sparkContext._jvm.org.apache.log4j
file_logger = log4jLogger.LogManager.getLogger(__name__)
file_logger.info("DQ with pyspark script for " + file_name + " logger initialized")

file_logger.info("Arguments are : arg 1 (file) " + file)
file_logger.info("Arguments are : arg 2 (source_table_name) " + source_table_name)
file_logger.info("Arguments are : arg 3 (doPreProcess) " + doPreProcess)
file_logger.info("Arguments are : arg 4 (load_number) " + load_number)
file_logger.info("Arguments are : arg 5 (logical_deletion_indicator) " + logical_deletion_indicator)
file_logger.info("Arguments are : arg 6 (config_path) " + config_path)
file_logger.info("Arguments are : arg 7 (log_path) " + log_path)
file_logger.info("Arguments are : arg 8 (touch_path) " + touch_path)
file_logger.info("Arguments are : arg 9 (delimiter) " + sheet_or_split)
file_logger.info("Arguments are : arg 10 (source_system_identifier) " + source_system_identifier)
file_logger.info("Arguments are : arg 11 (file_type) " + file_type)
file_logger.info("Arguments are : arg 12 (is_part_file) " + is_part_file)
file_logger.info("Arguments are : arg 13 (is_header_included) " + is_header_included)
file_logger.info("Arguments are : arg 14 (is_control_file_included) " + is_control_file_included)
file_logger.info("Arguments are : arg 15 (record_count) " + record_count)
file_logger.info("Arguments are : arg 16 (batch_exec_id) " + batch_exec_id)
file_logger.info("Arguments are : arg 17 (sbow_id) " + sbow_id)
file_logger.info("Arguments are : arg 18 (batch_id) " + batch_id)
file_logger.info("Arguments are : arg 19 (bow_id) " + bow_id)
file_logger.info("Arguments are : arg 20 (uow_id) " + uow_id)
file_logger.info("Arguments are : arg 21 (job_name) " + job_name)
file_logger.info("Arguments are : arg 22 (time_value) " + time_value)
file_logger.info("Arguments are : arg 23 (time_format) " + time_format)
file_logger.info("Arguments are : arg 24 (landing_path) " + landing_path)


def read_data_file(spark, file_name, schema, sheet_split, file_ext):
    set_header = "false"
    if is_header_included.lower() == 'y':
        set_header = "true"

    file_logger.info('DATA file is of type ' + file_ext)

    if file_ext.lower() == props['XLSX'].lower():
        excel_data_df = spark.read.format("com.crealytics.spark.excel").option("location", file_name).option("sheetName", sheet_split).option("treatEmptyValuesAsNulls", "true").option("addColorColumns", "false").option("inferSchema", "true").option("spark.read.simpleMode", "true").option("useHeader", set_header).load("com.databricks.spark.csv")
        return excel_data_df

    elif file_ext.lower() == props['TXT'].lower():
        file_data_df = spark.createDataFrame(spark.sparkContext.textFile(file_name).map(lambda x: x.split(sheet_split))).toDF(*schema)
        return file_data_df

    elif file_ext.lower() == props['FILE_ENDSWITH_DAT'].lower():
        file_data_df = spark.createDataFrame(
            spark.sparkContext.textFile(file_name).map(lambda x: x.split(sheet_split))).toDF(*schema)
        return file_data_df
    #json
    elif file_ext.lower() == props['FILE_ENDSWITH_JSON'].lower():
        file_data_df =  spark.read.json(file_name)
        return file_data_df
    #xml
    elif file_ext.lower() == props['FILE_ENDSWITH_XML'].lower():
        file_data_df = spark.createDataFrame(spark.read.format("com.databricks.spark.xml").options("rowTag","user").load(file_name).map(lambda x: x.split(sheet_split))).toDF(*schema)
        return file_data_df
        file_data_df = spark.read.format("com.databricks.spark.xml").options("rowTag","user")
    elif file_ext.lower() == props['CSV'].lower():
        file_data_df = spark.read.format("com.databricks.spark.csv").option("encoding", "UTF-8").option("ignoreLeadingWhiteSpace", "true").option("ignoreTrailingWhiteSpace", "true").option("header", set_header).option("treatEmptyValuesAsNulls", "true").option("inferSchema", "true").option("escape", '"').option("quote", "\"").option("multiLine", "true").load(file_name).toDF(*schema)
        return file_data_df

    elif file_ext.lower() == props['LZ4'].lower():
        if is_part_file.lower() == 'y':
            dir_name = '/'.join(file_name.split('/')[:-1])
            file_data_df = spark.read.option("header", set_header).option("delimiter",sheet_split).csv(dir_name).toDF(*schema)
            file_data_df.show(5, truncate=False)
        else:
            file_data_df = spark.read.option("header", set_header).option("delimiter", sheet_split).csv(file_name).toDF(*schema)
        return file_data_df

    else:
        file_logger.info('DATA file type of ' + file_ext + ' not defined. So exiting the process.')
        sys.exit(0)


def execute_spark(spark_session, file, source_table_name, doPreProcess, load_number, source_id, indicator, split_sheet, file_ext,  props):

    if not source_table_name:
        file_logger.info('The target hive table is not defined, so exiting the process.')
        sys.exit(0)
    col_name = props['TS_COLUMN_NAME']
    new_col_name = col_name + '_copy'
    file_logger.info('File name ' + file)
    if doPreProcess == 'true':
        source_system_id = source_id

        query = "desc " + source_table_name
        col_list, data_type_list, nullable_list = file_helper.read_schema_from_hive(props['REGEX_DESCRIBE'], query, props['JDBC_URL_BEELINE'])
        file_logger.info('Schema from hive')
        file_logger.info(col_list)

        table_cols = col_list[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):]
        df = read_data_file(spark_session, file, table_cols, split_sheet, file_ext)
        df_count = df.count()
        file_logger.info('The df_count is ' + str(df_count))

        if is_control_file_included.lower() == 'y':
            if int(record_count) > 0:
                if df_count == int(record_count):
                    file_logger.info('The control file validation successful')
                else:
                    file_logger.info('The record count does not match')
                    sys.exit(0)
        #system_id, log_ind, insert_ts, load_job_number, insert_ts
        insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        spark_session.sql("SET hive.exec.dynamic.partition = true")
        spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
        # partition_col = props['PARTITION_COLUMN_NAME'] .withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType()))
        df.select(lit(source_system_id).alias('source_system_identifier'),lit(indicator).alias('logical_deletion_indicator'),lit(insert_ts).alias('insert_gmt_timestamp'),lit(load_number).alias('load_job_number'),lit(insert_ts).alias('source_system_extract_gmt_timestamp'), lit(insert_ts).alias('last_modified_ts'), '*').write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)


props = file_helper.read_all_properties(file_config)

if not sheet_or_split:
    file_logger.info('The split char not provided, So System exited with status zero.')
    sys.exit(0)

sheet_or_split = chr(int(sheet_or_split))
file_logger.info('The file type ' + file_type + ' where the split char provided as ' + sheet_or_split)
pre_table_name = props['DATABASE_NAME']
if not source_table_name.startswith(pre_table_name):
    source_table_name = pre_table_name + source_table_name

execute_spark(spark, file, source_table_name, doPreProcess, load_number, source_system_identifier, logical_deletion_indicator, sheet_or_split, file_type, props)

aux_control_data = [[int(bow_id), None, new_time_value[:-3], new_time_value[:-3], None, None, uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id]]
aux_ctrl_df = file_helper.create_df(spark, aux_control_data, aux_control_schema)
pre_db_name = props['ABCR_DATABASE_NAME']
aux_ctrl_table_name = pre_db_name + props['AUX_CONTROL_TABLE']
aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name', unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_start_timestamp"), unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp', 'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description', 'change_data_capture_last_sequence_number', 'previous_change_data_capture_last_sequence_number', unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id')
aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
app_id = spark.sparkContext.applicationId
spark.stop()
# touch_file = source_table_name.lower()
# print(touch_file)

# if touch_file.startswith(pre_table_name):
#     touch_file = touch_file.split(pre_table_name)[-1]
# touch_file_name = touch_path.rstrip('/') + '/' + touch_file + '.dat'
# print('touch_file ' + touch_file_name)

log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
log_file_name = landing_path.rstrip('/') + '/dq1_ingestion_batch_id_' + str(batch_id) + '_bow_id_' + str(bow_id) + '_' + log_time_value + '.log'
file_logger.info("(log_file_name) " + log_file_name)
file_helper.generate_log(file_logger, log_file_name, app_id, 'dummy')
file_helper.copy_log_files(landing_path, log_path)

