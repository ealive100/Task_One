import subprocess, re, os, io
import data_quality_configuration

def create_df(spark, data, schema):
    return spark.createDataFrame(data, schema=schema)


def read_all_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.toDF(*schema)


def count_all_rows_from_hive(spark, table_name):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.count()


def read_distinct_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select distinct * from " + table_name)

    return table_schema_df.toDF(*schema)


def check_progress(application_id, logger):
    cmd = 'yarn application -status ' + application_id
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    logger.info("Job status Code " + str(p.returncode) + " with result " + out)
    lines = out.splitlines()
    complete = False
    for line in lines:
        if 'RUNNING' in line:
            complete = False
        if 'SUCCEEDED' in line:
            complete = True
    return complete


def list_files_by_date(location, file_pattern, timestamp_pattern, logger):
    file_list_by_date = []

    if timestamp_pattern:
        dir_files = os.listdir(location)
        set_date_values = sorted(list(set(find_all_dates_for_group(logger, dir_files, file_pattern, timestamp_pattern))))
        print(set_date_values)
        for file_date in set_date_values:
            file_list = []
            for source_file in dir_files:
                if file_pattern in source_file.lower() and file_date in source_file.lower():
                    file_list.append(source_file)
            file_list_by_date.append(file_list)

    return file_list_by_date


def find_all_dates_for_group(logger, dir_files, pattern_file, regex_pattern):

    all_date_values = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]
            print(my_file)
            try:
                my_file_name = re.search(pattern_file, my_file_name.lower()).group(0)
                print('After using regex on file pattern ' + my_file_name)
            except AttributeError:
                continue
            if my_file_name:
                print('The zip file selected ' + my_file)
                try:
                    date_time_value = re.search(regex_pattern, my_file_name.lower()).group(1)
                    print('After using regex on timestamp pattern ' + date_time_value)
                except AttributeError:
                    continue
                all_date_values.append(date_time_value)
    else:
        logger.info('No files found in the path.')
        exit(0)
    return all_date_values


def read_all_properties(config):
    prop_file = open(config, 'r')
    key_values = {}
    for line in prop_file:
            line_components = line.split('=')
            if line_components[0]:
                key_values[line_components[0].strip()] = line_components[1].strip()
    prop_file.close()
    return key_values


def read_parameter_file(parameter_config, line_split):
    prop_file = open(parameter_config, 'r')
    parameter_props = []

    all_columns = []
    for line in prop_file:
        line = line.rstrip('\n')
        if line:
            all_columns.append(line.split(line_split))
    prop_file.close()

    column_names = all_columns[0]
    column_values = all_columns[1:]
    for columns in column_values:
        key_values = {}
        key_value = zip(column_names, columns)
        for k, v in key_value:
            key_values[k.strip(' ')] = v.strip(' ')
        parameter_props.append(key_values)

    return parameter_props


def count_lines(dat_file):
    counter = 0
    with open(dat_file) as f:
        for i, l in enumerate(f):
            counter = counter + 1
    return counter


def find_column_count(dat_file):
    data_file_reader = open(dat_file, 'r')
    column_count = []
    counter = 0
    for line in data_file_reader:
        counter = counter + 1
        line = line.rstrip('\n')
        if len(line.split(chr(28))) != 106:
            column_count.append(str(counter) + ' ' + str(len(line.split(chr(28)))))
    data_file_reader.close()
    return column_count


def read_schema_from_hive(regex_desc, desc_query, jdbc_url):
    print(desc_query)
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", desc_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    stdout, stderr = p.communicate()
    p.wait()
    lines = stdout.splitlines()
    col_names = []
    data_types = []
    nullable = []
    for line in lines:
        cols = re.findall(regex_desc, line.replace('|', ''))
        if len(cols) == 10:
            col_names.append(cols[0])
            data_types.append(cols[1])
            nullable.append(cols[3])
    return col_names, data_types, nullable


def load_hive_data_from_python(split_char, sql_query, jdbc_url, obj):


    first_column = sql_query.split(',')[0].strip('select').strip(' ')
    col_count = len(sql_query.split(','))
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", sql_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    print(sql_query)
    stdout, stderr = p.communicate()
    print(p.returncode)
    p.wait()
    lines = stdout.split((chr(int(split_char))))
    object_list = []

    col_len = len(lines)
    junk_col = 1
    rows = int(round(col_len / col_count))
    counter = 1
    start_col_value_index = 0
    last_col_value_index = 0
    for i in range(0, rows):
        start_col_value_index = start_col_value_index + junk_col
        last_col_value_index = col_count + junk_col + last_col_value_index
        data = lines[start_col_value_index: last_col_value_index]
        data = [col.strip(" ") for col in data]
        if len(data) == col_count and data[0] != first_column:
            object_list.append(obj(*data))
        else:
            counter = counter + 1
        start_col_value_index = start_col_value_index + col_count
    return object_list


def generate_log(file_logger, file_path, application_id, touch_file_name):
    file_logger.info("Spark ApplicationId " + application_id)
    # os.system('hadoop fs -rm ' + file_path)
    file_success = '_SUCCESS'
    file_failure = '_FAILED'
    yarn_failure = '_JOB_NOT_RUN'

    if application_id:
        yarn_log_cmd = 'yarn logs -applicationId ' + application_id + ' > ' + file_path
        os.system(yarn_log_cmd)
        # yarn_cmd = yarn_log_cmd.split()
        # log_p = subprocess.Popen(yarn_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # log_out, log_err = log_p.communicate()
        # log_p.wait()
        # if log_p.returncode == 0:
        #     file_logger.info("Yarn log status Code " + str(log_p.returncode))
        # os.system('hadoop fs -rm  ' + file_path)
        # os.system('hadoop fs -put  ' + file_path + ' ' + file_log_path)
        cmd = 'yarn application -status ' + application_id
        command = cmd.split()
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        file_logger.info("Job status Code " + str(p.returncode) + " with result " + out)
        lines = out.splitlines()
        status = False
        is_complete = False
        for line in lines:
            if 'FINISHED' in line:
                is_complete = True
            if 'SUCCEEDED' in line:
                status = True
        # if status and is_complete:
        #     os.system('touch ' + file_path + file_success)
        #     os.system('touch ' + touch_file_name)
        # else:
        #     os.system('touch ' + file_path + file_failure)
    else:
        file_logger.error('YARN FAILURE')
        # os.system('touch ' + file_path + yarn_failure)


def read_aud_file_key(file_path, aud_key, logger, encoding_format):
    aud_keys = {}
    with io.open(file_path, encoding=encoding_format, errors='ignore') as file_reader:
    #with io.open(file_path, encoding='utf-16', errors='ignore') as file_reader:
        for line in file_reader:
            line = line.strip(' ')
            if ':' in line and aud_key in line:
                key_value = line.split(':')
                try:
                    aud_keys[key_value[0].strip()] = key_value[1].encode('latin-1').decode('ascii', 'ignore').strip().rstrip('\n')
                    # print(aud_keys)
                except:
                    logger.error('Encoding error while reading' + file_path + ' for aud_key ' + aud_key)
                    aud_keys[key_value[0].strip()] = key_value[1].strip()
    return aud_keys[aud_key]


def find_all_files(local_path, valid_files_dict):

    if os.path.isdir(local_path):
        for file in os.listdir(local_path):
            valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, file)
    return valid_files_dict


def copy_files(all_files, dest_dir_name):

    # os.system('hadoop fs -rmr ' + dest_dir_name)
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    if len(all_files) > 0:
        files = ' '.join(all_files)
        fs_put(files, dest_dir_name)


def copy_files_if_header_exist(all_files, dest_dir_name, is_header_included, is_compressed, logger):

    os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    # header_enabled_list = props['HEADER_ENABLED'].split(',')
    if len(all_files) > 0:
        files_without_header = []
        for file in all_files:
            file_name = file.split('/')[-1]
            if is_header_included.lower() == 'y' and is_compressed.lower() == 'n':
                logger.info('File having header ' + file)
                os.system("sed '1d' " + file + " | hdfs dfs -put - " + dest_dir_name.rstrip('/') + '/' + file_name)
            else:
                files_without_header.append(file)
        if len(files_without_header) > 0:
            files = ' '.join(files_without_header)
            fs_put(files, dest_dir_name)


def fs_put(file, dir):

    os.system('hadoop fs -put -f ' + file + ' ' + dir)


def check_if_control_exists(extension, local_path, valid_files_dict, invalid_files_dict, logger, props):
    record_count = 0
    is_control_exist = False
    ctrl_file = ''
    # print(local_path)
    if os.path.isdir(local_path):

        for file in os.listdir(local_path):
            if file.endswith(props['CTL_EXT']):
                record_count = read_ctrl_file(os.path.join(local_path, file))
                ctrl_file = file
                if int(record_count) > 0:
                    is_control_exist = True
                else:
                    logger.error('Even though the control file exist, record count is zero. Files not to be processed.')
        if is_control_exist:
            for file in os.listdir(local_path):
                if file.endswith(extension):
                    valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, ctrl_file)
        else:
            for file in local_path:
                logger.error('The control file does not exist for file ' + file)
                invalid_files_dict[os.path.join(local_path, file)] = props['LOG_MSG_FOR_AUD_MISSING']

    return valid_files_dict, invalid_files_dict, record_count


def read_ctrl_file(ctrl_file):
    ctrl_file_reader = open(ctrl_file, 'r')
    lines = ctrl_file_reader.readlines()
    count = 0
    for line in lines:
        if line:
            count = line
    ctrl_file_reader.close()
    return count


def check_if_aud_exists(do_validate_file, local_path, valid_files_dict, invalid_files_dict, logger, props, extension):

    if os.path.isdir(local_path):
        for file in os.listdir(local_path):
            if do_validate_file:
                # print(file)
                # print(extension)
                if file.lower().endswith(extension):
                    aud_file_name = os.path.join(local_path, file).rstrip('.' + extension) + props['AUD_EXT']
                    # print(aud_file_name)
                    if os.path.isfile(aud_file_name):
                        logger.info('The aud exists for file ' + file)
                        valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, aud_file_name)
                    else:
                        logger.error('The aud does not exist for file ' + file)
                        invalid_files_dict[os.path.join(local_path, file)] = props['LOG_MSG_FOR_AUD_MISSING']
            else:
                valid_files_dict[os.path.join(local_path, file)] = ''
    return valid_files_dict, invalid_files_dict


def check_if_row_count_matches(do_validate_file, valid_files, invalid_files, logger, props, is_header_included, encoding_format):

    if props['DO_COUNT_CHECK'] == 'false':
        # print(' COUNT validation ' + props['DO_COUNT_CHECK'])
        # print(valid_files)
        #print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read..." , dat_file)
                row_count = count_lines(dat_file)
                if is_header_included.lower() == 'y':
                    row_count = row_count - 1
                print('rows found in dat file ', dat_file, row_count)
                # print(props['RECORD_COUNT_KEY'])
                record_count_from_aud = read_aud_file_key(valid_files[dat_file], props['RECORD_COUNT_KEY'], logger, encoding_format)
                # print('count key has value', record_count_from_aud)
                logger.info('counts are ' + str(row_count) + ' and ' + record_count_from_aud)
                if row_count == 0:
                    logger.error('The row count is zero in the file ' + dat_file + '. So it would be invalidated.')
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_ZERO_COUNT_MATCH']
                elif str(row_count) == record_count_from_aud.strip():
                    logger.info('The row count matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.error('The row count does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_COUNT_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_rev_matches(is_rev_check, valid_files, invalid_files, logger, props, encoding_format):

    if is_rev_check.lower() == 'n':
        # print(' REV validation ' + is_rev_check)
        # print(valid_files)
        # print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_rev = dat_file.split(os.path.sep)[-1].split('.')[int(props['REV_POSITION'])].strip()
                # print('rev found in dat file ', dat_file, file_rev)
                file_rev_from_aud = read_aud_file_key(valid_files[dat_file], props['REV_KEY'], logger, encoding_format).strip()
                # print('rev key has value', file_rev_from_aud)
                logger.info('Revisions are from file name and aud as 1' + file_rev + '1 and 1' + file_rev_from_aud + '1')
                if file_rev == file_rev_from_aud:
                    logger.info('The rev matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.error('The rev does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_REV_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_seq_matches(is_seq_check, valid_files, invalid_files, logger, props, encoding_format):

    if is_seq_check.lower() == 'n':
        # print(' SEQ validation ' + is_seq_check)
        #print(valid_files)
        # print(invalid_files)
        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_seq = dat_file.split(os.path.sep)[-1].split('.')[int(props['SEQ_POSITION'])]
                # print('seq found in dat file ', dat_file, file_seq)
                file_seq_from_aud = read_aud_file_key(valid_files[dat_file], props['SEQ_KEY'], logger, encoding_format)
                # print('rev key has value', file_seq_from_aud)
                if int(file_seq) == int(file_seq_from_aud):
                    logger.info('The sequence matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.error('The sequence does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_SEQ_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def load_job_paramter_ingestion(table_config, batch_number, bow_id):

    split_char = table_config['JOB_PARAMETER_INGESTION_LAYER_COLUMN_SEPARATOR']
    sql_query = table_config['JOB_PARAMETER_INGESTION_LAYER_QUERY'] + ' where batch_number = ' + batch_number + ' and bow_id = ' + bow_id
    hive_jdbc_url = table_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration.JobParameterIngestion

    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)


def load_file_control_ingestion(file_config, batch_id, bow_id):

    split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
    sql_query = file_config['FILE_CONTROL_INGESTION_QUERY'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id
    hive_jdbc_url = file_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration.FileControlIngestion

    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)


def archive_files(source_path, destination_path):
    if os.path.isdir(source_path):
        for file in os.listdir(source_path):
            os.system('hdfs dfs -put -f ' + os.path.join(source_path, file) + ' ' + destination_path)


def clean_working_path(destination_path):
    os.system('rm -fr  ' + destination_path.rstrip('/') + '/*')


def copy_log_files(source_path, destination_path):
    log_file_list = []
    if os.path.isdir(source_path):
        for file in os.listdir(source_path):
            log_file = os.path.join(source_path, file)
            if os.path.isfile(log_file) and log_file.endswith('.log'):
                log_file_list.append(log_file)
    print(log_file_list)
    copy_files(log_file_list, destination_path)


def find_all_files_for_group(location, pattern_file):
    dir_files = os.listdir(location)
    all_file_names = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]

            try:
                my_file_name = re.search(pattern_file, my_file_name).group(0)

            except AttributeError:
                continue
            if my_file_name:
                all_file_names.append(my_file)
    else:
        print('No files found in the path.')
        exit(0)
    return all_file_names


def sorted_list_files_by_date(dir_files, file_pattern):
    if file_pattern:

        set_file_names = sorted(list(set(find_all_files_for_group(dir_files, file_pattern))))
        print(set_file_names)
        return set_file_names

    return []
