import os, zipfile, logging, sys, tarfile, re
import data_quality_helper as file_helper
from datetime import datetime

archive_location = sys.argv[1]
dir_to_process = sys.argv[2]
dir_not_to_process = sys.argv[3]
landing_path = sys.argv[4]
load_number = sys.argv[5]
logical_deletion_indicator = sys.argv[6]
python_path = sys.argv[7]
log_path = sys.argv[8]
touch_path = sys.argv[9]
table_name = sys.argv[10]
delimiter = sys.argv[11]
extension = sys.argv[13]
type_of_load = sys.argv[14]
is_compressed = sys.argv[15]
compression_format = sys.argv[16]
is_file_validation = sys.argv[17]
is_control_file_included = sys.argv[18]
is_audit_file_included = sys.argv[19]
is_header_included = sys.argv[20]

is_part_file = sys.argv[22]
is_rev_check = sys.argv[23]
is_seq_check = sys.argv[24]
parameter_file = sys.argv[25]
lib_path = sys.argv[26]
config_path = sys.argv[27]
batch_exec_id = sys.argv[28]
sbow_id = sys.argv[29]
batch_id = sys.argv[30]
bow_id = sys.argv[31]
uow_id = sys.argv[32]
job_name = sys.argv[33]
time_format = sys.argv[34]
archive_file_path = sys.argv[35]
audit_encoding_style = sys.argv[36]

param_file_config = config_path.rstrip('/') + '/file_control_config.ini'
log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
LOG_FILE_PATH = landing_path.rstrip('/') + '/' + '/dq1_validation_batch_id_' + str(batch_id) + '_bow_id_' + str(bow_id) + '_' + log_time_value + '.log'
FILE_CONFIG = config_path.rstrip('/') + '/file_config.ini'
control_count = 0

logger = logging.getLogger('dq_server_logger')
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(LOG_FILE_PATH)
fh.setLevel(logging.DEBUG)
# create console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
# add the handlers to logger
logger.addHandler(ch)
logger.addHandler(fh)


logger.info("Arguments are : arg 1 (source or landing path) " + archive_location)
logger.info("Arguments are : arg 2 (dir_to_process) " + dir_to_process)
logger.info("Arguments are : arg 3 (dir_not_to_process) " + dir_not_to_process)
logger.info("Arguments are : arg 4 (landing_path) " + landing_path)
logger.info("Arguments are : arg 5 (LOAD_NUMBER) " + load_number)
logger.info("Arguments are : arg 6 (logical_deletion_indicator) " + logical_deletion_indicator)
logger.info("Arguments are : arg 7 (python_path) " + python_path)
logger.info("Arguments are : arg 8 (log_path) " + log_path)
logger.info("Arguments are : arg 9 (touch_path) " + touch_path)
logger.info("Arguments are : arg 10 (source_table) " + table_name)
logger.info("Arguments are : arg 11 (delimiter) " + delimiter)
logger.info("Arguments are : arg 13 (file_extension) " + extension)
logger.info("Arguments are : arg 14 (type_of_load) " + type_of_load)
logger.info("Arguments are : arg 15 (is_compressed) " + is_compressed)
logger.info("Arguments are : arg 16 (compression_format) " + compression_format)
logger.info("Arguments are : arg 17 (is_file_validation) " + is_file_validation)
logger.info("Arguments are : arg 18 (is_control_file_included) " + is_control_file_included)
logger.info("Arguments are : arg 19 (is_audit_file_included) " + is_audit_file_included)
logger.info("Arguments are : arg 20 (is_header_included) " + is_header_included)
logger.info("Arguments are : arg 22 (is_part_file) " + is_part_file)
logger.info("Arguments are : arg 23 (is_rev_check) " + is_rev_check)
logger.info("Arguments are : arg 24 (is_seq_check) " + is_seq_check)
logger.info("Arguments are : arg 25 (parameter_file) " + parameter_file)
logger.info("Arguments are : arg 26 (lib_path) " + lib_path)
logger.info("Arguments are : arg 27 (config_path) " + config_path)
logger.info("Arguments are : arg 28 (batch_exec_id) " + batch_exec_id)
logger.info("Arguments are : arg 29 (sbow_id) " + sbow_id)
logger.info("Arguments are : arg 30 (batch_id) " + batch_id)
logger.info("Arguments are : arg 31 (bow_id) " + bow_id)
logger.info("Arguments are : arg 32 (uow_id) " + uow_id)
logger.info("Arguments are : arg 33 (job_name) " + job_name)
logger.info("Arguments are : arg 34 (time_format) " + time_format)
logger.info("Arguments are : arg 35 (archive_file_path) " + archive_file_path)
logger.info("Arguments are : arg 37 (audit_encoding_style) " + audit_encoding_style)


def validate_file(do_validate_file, archive_file, logger, props):

    filename, file_extension = os.path.splitext(archive_file)

    is_valid_zip = False

    extract_path = landing_path.rstrip('/') + '/' + str(filename).split('/')[-1]
    # logger.info('The files would be extracted to ' + extract_path)

    if archive_file.endswith("zip"):
        is_valid_zip = True
        try:
            archive = zipfile.ZipFile(archive_file)
            archive.extractall(extract_path)
            archive.close()
        except zipfile.BadZipfile:
            logger.error("The archive file format not supported " + archive_file)
            is_valid_zip = False
    elif archive_file.endswith("tar.gz"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:gz")
        tar.extractall(extract_path)
        tar.close()
    elif archive_file.endswith("tar"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:")
        tar.extractall(extract_path)
        tar.close()

    valid_files_dict = {}
    invalid_files_dict = {}

    if not is_valid_zip:
        print('The files are not in archive format.')
        extract_path = archive_location.rstrip('/')

    if do_validate_file:

        if is_audit_file_included.lower() == 'y':
            logger.info('The file validation is done as per audit file')
            valid_files_aud_check, invalid_files = file_helper.check_if_aud_exists(do_validate_file, extract_path, valid_files_dict, invalid_files_dict, logger, props, extension.lower())

            counter_row_mismatch, valid_files_row_count, invalid_files = file_helper.check_if_row_count_matches(do_validate_file, valid_files_aud_check, invalid_files, logger, props, is_header_included, audit_encoding_style)

            counter_rev_mismatch, valid_files_rev_check, invalid_files = file_helper.check_if_rev_matches(is_rev_check, valid_files_row_count, invalid_files, logger, props, audit_encoding_style)

            counter_seq_mismatch, valid_files_seq_check, invalid_files = file_helper.check_if_seq_matches(is_seq_check, valid_files_rev_check, invalid_files, logger, props, audit_encoding_style)
            return valid_files_seq_check, invalid_files, 0
        elif is_control_file_included.lower() == 'y':
            logger.info('The file validation is done as per control file')
            valid_files_ctl_check, invalid_files, record_count = file_helper.check_if_control_exists(extension, extract_path, valid_files_dict,
                                                                       invalid_files_dict, logger, props)

            return valid_files_ctl_check, invalid_files, record_count
        else:
            logger.error('The validation flag enabled but either audit or control flag is disabled.')
            sys.exit(0)
    else:
        logger.info('The file validation disabled...')

        return file_helper.find_all_files(extract_path, valid_files_dict), invalid_files_dict, 0


def validate(do_validate_file, files, logger, props):
    all_valid_files = {}
    all_invalid_files = {}
    return_all_valid_files={}
    record_count = 0
    for file in files:
        logger.info('File to be validated ' + file + ' where file validation is set to ' + str(do_validate_file)) #tbl_prod_cat_2_HDFS_201903051400000018.dat
        valid_files, invalid_files, record_count = validate_file(do_validate_file, os.path.join(archive_location, file), logger, props)
        valid = all_valid_files.copy()
        valid.update(valid_files)
        all_valid_files = valid
        # all_valid_files = all_valid_files + valid_files
        invalid = all_invalid_files.copy()
        invalid.update(invalid_files)
        all_invalid_files = invalid

        # all_invalid_files = all_invalid_files + invalid_files
    print('The valid files..')
    print(all_valid_files)
    print('The invalid files...')
    print(all_invalid_files)
    select_files = os.path.join(archive_location, file)
    print('select files..',select_files)
    if all_valid_files.get(select_files):
        return_all_valid_files[os.path.join(archive_location, file)] = os.path.join(archive_location, file)
        print('return_all_valid_files...',return_all_valid_files)
    return return_all_valid_files, all_invalid_files, record_count



def post_process(valid_files, invalid_files, good_path_files, reject_path_files,table_nm, sheet_split_nm, props, record_count):
    if len(valid_files) > 0:
        # print(valid_files)
        all_files = list(valid_files.keys()) # + list(valid_files.values())
        # file_helper.copy_files(all_files, good_path_files)
        file_helper.copy_files_if_header_exist(all_files, good_path_files, is_header_included, 'n', logger)
        execute_job(all_files, good_path_files, props['DO_PREPROCESS'], load_number, table_nm, sheet_split_nm, props, record_count)

    if len(invalid_files) > 0:
        # print(invalid_files)
        all_files = list(invalid_files.keys())
        file_helper.copy_files(all_files, reject_path_files)


def start_process(do_validate_file, location, to_process, not_to_process, table_nm, sheet_split_nm, props):

    #dir_files = file_helper.list_files_by_date(location, zip_file_pattern.lower(), zip_file_timestamp_pattern.lower(), logger)
    dir_files = file_helper.sorted_list_files_by_date(location, file_pattern)
    # toucprint(dir_files)
    # for filtered_files in dir_files:
    if len(dir_files) > 0:
        all_valid_files_dict, all_invalid_files_dict, record_count = validate(do_validate_file, dir_files, logger,  props)
        post_process(all_valid_files_dict, all_invalid_files_dict, to_process, not_to_process, table_nm, sheet_split_nm, props, record_count)
    else:
        logger.info('No files selected with the mentioned file pattern.')
    # else:
    #     logger.info('No files to be processed.')


def execute_job(all_files, path_file, doProcess, load_number, table_nm, sheet_split_nm, props, record_count):

    mode = props['DEPLOY_MODE']
    exec_mem = props['EXECUTOR_MEMORY']
    num_exec = props['NUM_OF_EXECUTOR']
    #queue = props['JOB_QUEUE']
    cores = props['EXECUTOR_CORES']
    hive_config = props['HIVE_CONFIG_PATH']
    done = touch_path.rstrip('/') + '/' + props['DONE']
    script_path = python_path.rstrip('/') + '/file_ingestion.py'
    file_path = config_path.rstrip('/') + '/file_config.ini,' + python_path.rstrip('/') + '/data_quality_helper.py'
    jar_file = lib_path.rstrip('/') + '/spark-csv_2.11-1.5.0.jar,' + lib_path.rstrip('/') + '/spark-excel_2.11-0.8.6.jar'
    os.system('rm -fr ' + touch_path.rstrip('/') + '/*')
    if is_part_file.lower() == 'y':
        all_files = [all_files[0]]

    for file in all_files:
        if os.path.isfile(file):
            file_name = file.split('/')[-1]
            file_name_without_ext = file_name.lower().rstrip('.' + extension.lower())
	    print('file_name_without_ext',file_name_without_ext);	
            new_file = path_file.rstrip('/') + '/' + file_name
            print('new_file',new_file);
	    print('timestamp_pattern',timestamp_pattern)	
            date_time_value = re.search(timestamp_pattern.lower(), file_name_without_ext).group(1)
            # source_system_id = re.search(source_system_id_pattern.lower(), file_name_without_ext).group(1)
            source_system_id = source_system_id_pattern

            print('The file name to be processed by sparkspark ' + file + ' having datetime value as ' + date_time_value)
            #spark_submit = 'export SPARK_MAJOR_VERSION=2; spark-submit --master yarn --deploy-mode ' + mode + ' --jars ' + jar_file + ' --executor-memory ' + exec_mem + ' --num-executors ' + num_exec + ' --executor-cores ' + cores + ' --queue ' + queue + ' --py-files ' + file_path + ' --files ' + hive_config + ' ' +\
              #             script_path + ' ' + new_file + ' ' + table_nm + ' ' + doProcess + ' ' + load_number + ' ' + logical_deletion_indicator + ' ' + config_path + ' ' + log_path + ' ' + touch_path + ' ' + sheet_split_nm + ' ' + source_system_id + ' ' + extension + ' ' + is_part_file + ' ' + is_header_included + ' ' + is_control_file_included + ' ' + str(record_count) + ' ' + batch_exec_id + ' ' + sbow_id + ' ' + batch_id + ' ' + bow_id + ' ' + uow_id + ' ' + job_name + ' ' + date_time_value + ' ' + time_format + ' ' + landing_path
            spark_submit = 'export SPARK_MAJOR_VERSION=2; spark-submit --master local[*]' + ' --jars ' + jar_file +  ' --py-files ' + file_path + ' --files ' + hive_config + ' ' +\
                           script_path + ' ' + new_file + ' ' + table_nm + ' ' + doProcess + ' ' + load_number + ' ' + logical_deletion_indicator + ' ' + config_path + ' ' + log_path + ' ' + touch_path + ' ' + sheet_split_nm + ' ' + source_system_id + ' ' + extension + ' ' + is_part_file + ' ' + is_header_included + ' ' + is_control_file_included + ' ' + str(record_count) + ' ' + batch_exec_id + ' ' + sbow_id + ' ' + batch_id + ' ' + bow_id + ' ' + uow_id + ' ' + job_name + ' ' + date_time_value + ' ' + time_format + ' ' + landing_path

            os.system(spark_submit)
        else:
            logger.info('This is not a file ' + file + ' , so would not be processed.')
    # os.system('touch ' + done)


file_pattern = ''
timestamp_pattern = ''
source_system_id_pattern = ''

props = file_helper.read_all_properties(FILE_CONFIG)

all_parameter_obj = file_helper.load_file_control_ingestion(props, batch_id, bow_id)
for parameter_obj in all_parameter_obj:
    if table_name == parameter_obj.lz_table_name:
        file_pattern = parameter_obj.file_pattern
        timestamp_pattern = parameter_obj.timestamp_pattern
        source_system_id_pattern = parameter_obj.source_system_identifier

logger.info("file_pattern " + file_pattern)
logger.info("timestamp_pattern " + timestamp_pattern)
logger.info("source_system_id_pattern " + source_system_id_pattern)


file_validation = True
if is_file_validation.lower() == 'n':
    file_validation = False

start_process(file_validation, archive_location, dir_to_process, dir_not_to_process, table_name, delimiter, props)
