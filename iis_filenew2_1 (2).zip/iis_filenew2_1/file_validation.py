import os, zipfile, sys, tarfile
import data_quality_helper as file_helper


def validate_file(do_validate_file, archive_file, logger, props, parameter_obj, archive_file_with_extracted_file_dict):

    filename, file_extension = os.path.splitext(archive_file)

    is_valid_zip = False

    extract_path = parameter_obj.file_landing_path.rstrip('/') + '/' + str(filename).split('/')[-1]
    # logger.info('The files would be extracted to ' + extract_path)

    if archive_file.endswith("zip"):
        is_valid_zip = True
        try:
            archive = zipfile.ZipFile(archive_file)
            archive.extractall(extract_path)
            archive.close()
        except zipfile.BadZipfile:
            logger.debug("The archive file format not supported " + archive_file)
            is_valid_zip = False
    elif archive_file.endswith("tar.gz"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:gz")
        tar.extractall(extract_path)
        tar.close()
    elif archive_file.endswith("tar"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:")
        tar.extractall(extract_path)
        tar.close()

    if is_valid_zip:
        archive_file_with_extracted_file_dict[archive_file] = extract_path
    else:
        archive_file_with_extracted_file_dict[archive_file] = ""

    valid_files_dict = {}
    invalid_files_dict = {}

    # if is_valid_zip and do_validate_file:
    #     print('The files are in archive format.')
    #     extract_path = extract_path.rstrip('/')

    if do_validate_file and is_valid_zip:

        if parameter_obj.is_audit_file.lower() == 'y':
            logger.debug('The file validation is done as per audit file')
            valid_files_aud_check, invalid_files = file_helper.check_if_aud_exists(do_validate_file, extract_path, valid_files_dict, invalid_files_dict, logger, props, parameter_obj.extension.lower(), archive_file)

            counter_row_mismatch, valid_files_row_count, invalid_files = file_helper.check_if_row_count_matches(do_validate_file, valid_files_aud_check, invalid_files, logger, props, parameter_obj.is_header_included, parameter_obj.audit_code, archive_file)

            counter_rev_mismatch, valid_files_rev_check, invalid_files = file_helper.check_if_rev_matches(parameter_obj.is_rev_id, valid_files_row_count, invalid_files, logger, props, parameter_obj.audit_code, archive_file)

            counter_seq_mismatch, valid_files_seq_check, invalid_files = file_helper.check_if_seq_matches(parameter_obj.is_src_sys_cd_seq, valid_files_rev_check, invalid_files, logger, props, parameter_obj.audit_code, archive_file)
            return valid_files_seq_check, invalid_files
        elif parameter_obj.is_control_file.lower() == 'y':
            logger.debug('The file validation is done as per control file')
            valid_files_ctl_check, invalid_files, record_count = file_helper.check_if_control_exists(parameter_obj.extension, extract_path, valid_files_dict,
                                                                       invalid_files_dict, logger, props)

            return valid_files_ctl_check, invalid_files, record_count
        else:
            logger.debug('The validation flag enabled but either audit or control flag is disabled.')
            sys.exit(0)

    elif not do_validate_file and is_valid_zip:
        logger.debug('The file validation disabled... but files are in archive format')

        if os.path.isdir(extract_path):
            for file in os.listdir(extract_path):
                file_helper.check_if_row_count_zero(os.path.join(extract_path, file), valid_files_dict, invalid_files_dict, logger, props, parameter_obj.is_header_included, archive_file, parameter_obj.extension)
        return valid_files_dict, invalid_files_dict

    elif not do_validate_file and not is_valid_zip:
        logger.debug('The file validation disabled... and files are not in archive format')
        #file_helper.find_all_files(archive_file, valid_files_dict)
        file_helper.check_if_row_count_zero(archive_file, valid_files_dict, invalid_files_dict, logger, props, parameter_obj.is_header_included, archive_file, parameter_obj.extension)
        return valid_files_dict, invalid_files_dict


def validate(do_validate_file, files, logger, props, parameter_obj, archive_files, all_invalid_files):
    all_valid_files = {}

    for file in files:
        logger.debug('File to be validated ' + file + ' where file validation is set to ' + str(do_validate_file))
        valid_files, invalid_files = validate_file(do_validate_file, os.path.join(parameter_obj.source_file_path, file), logger, props, parameter_obj, archive_files)
        valid = all_valid_files.copy()
        valid.update(valid_files)
        all_valid_files = valid
        # all_valid_files = all_valid_files + valid_files
        invalid = all_invalid_files.copy()
        invalid.update(invalid_files)
        all_invalid_files = invalid

        # all_invalid_files = all_invalid_files + invalid_files
    logger.debug('The valid files..')
    logger.debug(all_valid_files)
    logger.debug('The invalid files...')
    logger.debug(all_invalid_files)
    return all_valid_files, all_invalid_files


def post_process(valid_files, invalid_files, good_path_files, reject_path_files, is_header_included, logger):
    if len(valid_files) > 0:
        # print(valid_files)
        all_files = list(valid_files.keys()) # + list(valid_files.values())
        file_helper.copy_files(all_files, good_path_files)
        # file_helper.copy_files_if_header_exist(all_files, good_path_files, is_header_included, is_compressed, logger)

    if len(invalid_files) > 0:
        # print(invalid_files)
        all_files = list(invalid_files.keys())
        file_helper.move_files(all_files, reject_path_files)


def get_valid_files_dict(parameter_obj, props, logger):

    all_good_files = {}
    archive_file_dict = {}
    all_invalid_files_dict = {}
    file_validation = True
    if parameter_obj.is_file_validation.lower() == 'n':
        file_validation = False

    dir_files = file_helper.sorted_list_files_by_date(parameter_obj.source_file_path, parameter_obj.file_pattern)
    if len(dir_files) > 0:
        all_valid_files_dict, all_invalid_files_dict = validate(file_validation, dir_files, logger,  props, parameter_obj, archive_file_dict, all_invalid_files_dict)
        all_good_files = all_valid_files_dict
        post_process(all_valid_files_dict, all_invalid_files_dict, parameter_obj.hdfs_good_path, parameter_obj.hdfs_reject_path, parameter_obj.is_header_included, logger)
    else:
        logger.debug('No files selected with the mentioned file pattern.')

    return all_good_files, archive_file_dict, all_invalid_files_dict


def check_del_in_lz4_files_dict(parameter_obj, props, logger):
    logger.info('inside check_del_in_lz4_files_dict')
    file_validation = False
    hdfs_trans_files , hdfs_del_files = file_helper.find_all_files_for_lz4_group(parameter_obj.source_file_path,parameter_obj.del_file_pattern,parameter_obj.del_timestamp_pattern,parameter_obj.ad_file_pattern,parameter_obj.ad_timestamp_pattern,parameter_obj.extension)
    logger.info('check_del_in_lz4_files_dict - dir_file ', hdfs_trans_files , ' hdfs_del_files :' , hdfs_del_files);

    return hdfs_trans_files , hdfs_del_files

