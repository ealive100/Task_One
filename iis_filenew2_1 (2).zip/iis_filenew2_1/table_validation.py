from pyspark.sql.functions import lit, col, unix_timestamp, concat, from_unixtime, substring, hash
from pyspark.sql import Window
import pyspark.sql.functions as f
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType
from datetime import datetime
import data_quality_helper

"""
This class provides various functions to do data quality checks on source records in form of dat file.
1.Data type check
2.Duplicate record check
3.Null check
"""
# batch_number_arg = sys.argv[1]
# bow_id_arg = sys.argv[2]
# logical_deletion_indicator_arg = sys.argv[3]
# load_number_arg = sys.argv[4]
# batch_id_arg = sys.argv[5]
# sbow_id_arg = sys.argv[6]
# file_crm_ingestion_arg = sys.argv[7]
# table_config_arg = sys.argv[8]
#
# spark_session = SparkSession.builder.enableHiveSupport().appName("Field_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']').getOrCreate()
# log4jLogger = spark_session.sparkContext._jvm.org.apache.log4j
# file_logger = log4jLogger.LogManager.getLogger(__name__)
# file_logger.info("DQ with pyspark script logger initialized")


def read_duplicate_rows_from_hive(full_df, schema, props):
    hash_full_df = full_df.withColumn("_hash", hash(*schema))
    hash_full_df_window = hash_full_df.withColumn("_duplicate", f.count("*").over(Window.partitionBy("_hash")))
    duplicate_df = hash_full_df_window.filter("_duplicate > 1")
    # duplicate_df.show(20, truncate = False)
    return duplicate_df.withColumn(props['COMMENTS_COLUMN'], concat(lit("There are failed records due to primary key check, Record Count="), col('_duplicate'))).drop("_hash").drop("_duplicate")


def create_filter_from_dict(column_dict, total_filter_list):
    column_list = list(column_dict.keys())
    filter_list = [column + " == '' or " + column + " is null or" + column + " != '' and " + column + " rlike '" + column_dict[column] + "'" for column in column_list]

    if filter_list:
        total_filter_list = total_filter_list + filter_list

    return total_filter_list


def create_filter(column_list, regex_pattern, total_filter_list):

    filter_list = [column + " == '' or " + column + " is null or " + column + " != '' and " + column + " rlike '" + regex_pattern + "'" for column in column_list]

    if filter_list:
        total_filter_list = total_filter_list + filter_list

    return total_filter_list


def apply_filter(column, regex_pattern, object_name, comment_column):
    # print(regex_pattern)
    error_record_col = object_name.subtract(object_name.filter(column + " is null or " + column + " == '' or " + column + " is not null and " + column + " rlike '" + regex_pattern + "' or " + column + " != '' and " + column + " rlike '" + regex_pattern + "'"))
    error_record_col_count = error_record_col.count()
    if error_record_col_count > 0:
        # print("Bad records for column " + column)
        error_record_col = error_record_col.withColumn(comment_column, lit("There are failed records due to data type check for column " + column + " with record count=" + str(error_record_col_count)))
        # error_record_col.select(col(column)).show(1, False)
        # print("There are failed records due to data type check for column " + column + " with record count=" + str(error_record_col_count))
    else:
        error_record_col = error_record_col.withColumn(comment_column, lit(""))
    return error_record_col


def check_data_type(table_name, object_name, column_names_with_data_type, logger, props, bow_name):
    error_records = object_name.withColumn(props['COMMENTS_COLUMN'], lit("")).filter("1=0")
    columns_date_list = []
    columns_int_list = []
    columns_timestamp_list = []
    columns_smallint_list = []
    columns_decimal_list = []
    columns_datetime_list = []
    columns_bit_list = []
    columns_bigint_list = []

    for column, data_type in column_names_with_data_type:
        if data_type == props['INT']:
            columns_int_list.append(column)
        elif data_type == props['DATE']:
            columns_date_list.append(column)
        elif data_type == props['TIMESTAMP']:
            columns_timestamp_list.append(column)
        elif data_type == props['SMALLINT']:
            columns_smallint_list.append(column)
        elif props['DECIMAL'] in data_type:
            columns_decimal_list.append(column)
        elif data_type == props['DATETIME']:
            columns_datetime_list.append(column)
        elif data_type == props['BIT']:
            columns_bit_list.append(column)
        elif data_type == props['BIGINT']:
            columns_bigint_list.append(column)
    # object_name.printSchema()
    total_filter_list = []
    # total_filter_list = create_filter(columns_int_list, props['REGEX_INT'], total_filter_list)
    for column in columns_int_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_INT'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_date_list, props['REGEX_DATE'], total_filter_list)
    for column in columns_date_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_DATE'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_timestamp_list, props['REGEX_TIMESTAMP'], total_filter_list)
    for column in columns_timestamp_list:
        if bow_name.lower() != 'apollo':
            error_records = error_records.union(apply_filter(column, props['REGEX_TIMESTAMP'], object_name, props['COMMENTS_COLUMN']))
        else:
            error_records = error_records.union(apply_filter(column, props['REGEX_TIMESTAMP_APOLLO'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_smallint_list, props['REGEX_SMALLINT'], total_filter_list)
    for column in columns_smallint_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_SMALLINT'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter_from_dict(columns_decimal_dict, total_filter_list)
    # columns_decimal_list = list(columns_decimal_dict.keys())
    for column in columns_decimal_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_DECIMAL'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_datetime_list, props['REGEX_DATETIME'], total_filter_list)
    for column in columns_datetime_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_DATETIME'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_bit_list, props['REGEX_BIT'], total_filter_list)
    for column in columns_bit_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_BIT'], object_name, props['COMMENTS_COLUMN']))
    # total_filter_list = create_filter(columns_bigint_list, props['REGEX_BIGINT'], total_filter_list)
    for column in columns_bigint_list:
        error_records = error_records.union(apply_filter(column, props['REGEX_BIGINT'], object_name, props['COMMENTS_COLUMN']))

    total_count = error_records.count()
    if total_count > 0:
        logger.debug("There are failed records in table [" + table_name + "] due to data type check for column, Record Count=" + str(total_count))
        error_records = error_records.drop_duplicates()
    return error_records, total_count


def check_null_values(table_name, object_name, column_names, column_null_options, logger):
    error_records = object_name.filter("1=0")
    total_count = 0
    nullable_col_list = []
    for column, nullable in zip(column_names, column_null_options):
        if nullable.lower() == 'no':
            nullable_col_list.append(column)
    if len(nullable_col_list) > 0:
        filter_condition_list = ["(" + column + " is null) or (trim(" + column + ") = '')" for column in nullable_col_list]
        filter_condition = ' or '.join(filter_condition_list)
        error_records = object_name.filter(filter_condition)

        total_count = error_records.count()
        if total_count > 0:
            logger.debug("There are failed records in table [" + table_name + "] due to null check for column, Record Count=" + str(total_count))
            error_records = error_records.drop_duplicates()
    return error_records, total_count


def validate_table_data(file_df, spark, table_name, logger, props, schema_table, bow_name):

    desc_query = 'desc ' + schema_table
    # error_df = spark.sql("select * from " + error_table + " where 1=0")

    column_names,data_types,column_null_options = data_quality_helper.read_schema_from_hive(props['REGEX_DESCRIBE'], desc_query, props['JDBC_URL_BEELINE'])

    # column_names, data_types, column_null_options = data_quality_helper.read_schema_from_hive_using_collect(spark, desc_query)

    logger.debug(' Columns are ' + ''.join(column_names))
    column_names_with_data_type = zip(column_names[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):], data_types[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):])
    full_data_df = file_df
    source_count = full_data_df.count()
    #is_dq_required = False
    is_dq_required = True
    good_records_df = full_data_df
    error_records = full_data_df.filter("1=0")
    count_reject_records = 0
    if is_dq_required:
        distinct_records_df = full_data_df.drop_duplicates()
        # distinct_records_df = data_quality_helper.read_distinct_rows_from_hive(spark, table_name, column_names)
        distinct_records_df.cache()
        total_count = full_data_df.count()
        distinct_count = distinct_records_df.count()
        duplicate_df = full_data_df.filter("1=0")
        count_duplicate = total_count - distinct_count
        if count_duplicate > 0:
            # duplicate_df = spark.sql("select *, count(*) as _count from " + table_name + " group by " + ','.join(column_names) + ' having _count > 1').withColumn(props['COMMENTS_COLUMN'], concat(lit("There are failed records due to primary key check, Record Count="), col('_count'))).drop('_count')
            duplicate_df = read_duplicate_rows_from_hive(full_data_df, column_names, props)
        else:
            duplicate_df = duplicate_df.withColumn(props['COMMENTS_COLUMN'], lit(''))

        logger.debug('Total number of records in ' + table_name + ' data file are ' + str(total_count))
        logger.debug('Total number of duplicate records in ' + table_name + ' data file are ' + str(duplicate_df.count()))

        bad_records_data_type_check_df, bad_record_data_type_constraint_count = check_data_type(table_name, distinct_records_df, column_names_with_data_type, logger, props, bow_name)
        logger.debug('Number of bad records due to data type check constraint ' + str(bad_record_data_type_constraint_count))

        bad_records_null_check_df, bad_record_nullable_constraint_count = check_null_values(table_name, distinct_records_df, column_names, column_null_options, logger)

        if bad_record_nullable_constraint_count > 0:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(props['COMMENTS_COLUMN'], lit("There are failed records due to null check for columns, Record Count=" + str(bad_record_nullable_constraint_count)))
        else:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(props['COMMENTS_COLUMN'], lit(''))

        logger.debug('Total number of bad records due to Nullable constraint ' + str(bad_record_nullable_constraint_count))
        count_reject_records = count_duplicate + bad_record_data_type_constraint_count + bad_record_nullable_constraint_count
        logger.debug('Total number of good records in source table ' + str(total_count - count_reject_records))
        error_records_df = bad_records_data_type_check_df.union(bad_records_null_check_df).drop_duplicates()

        error_records = error_records_df.union(duplicate_df)
        error_records_without_comment = error_records_df.drop(props['COMMENTS_COLUMN']).drop_duplicates()
        good_records_df = distinct_records_df.subtract(error_records_without_comment)
    target_count = good_records_df.count()
    return good_records_df, error_records, count_reject_records, source_count, target_count


def execute_validation(file_df, spark, table_name, good_table, reject_table, props, partition_col,file_logger, bow_name, load_type):

    unique_records_df, error_records, count_error_records, source_count, target_count = validate_table_data(file_df, spark, table_name, file_logger, props, good_table, bow_name)
    insert_data(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table, bow_name, load_type)
    return source_count, target_count


def validate_parameter_obj(file_df, spark_session, props, parameter_obj, file_logger):

    partition_col = props['PARTITION_COLUMN_NAME']
    if parameter_obj.bow_name.lower() == 'anaplan':
        partition_col = props['PARTITION_COLUMN_NAME_ANAPLAN']
    source_table_name = parameter_obj.lz_table_name
    good_table_name = parameter_obj.hst_table_name
    reject_table_name = parameter_obj.reject_table_name

    if not source_table_name.startswith(parameter_obj.hive_schema_name):
        source_table_name = parameter_obj.hive_schema_name + '.' + source_table_name

    if not good_table_name.startswith(parameter_obj.hive_schema_name):
        good_table_name = parameter_obj.hive_schema_name + '.' + good_table_name

    if not reject_table_name.startswith(parameter_obj.hive_schema_name):
        reject_table_name = parameter_obj.hive_schema_name + '.' + reject_table_name

    file_logger.debug("(source_table_name) " + source_table_name)
    file_logger.debug("(good_table_name) " + good_table_name)
    file_logger.debug("(reject_table_name) " + reject_table_name)

    if file_df is None:
        file_df = spark_session.sql("select * from " + source_table_name)
    src_table_count = file_df.count()
    if src_table_count > 0:
        source_count, target_count = execute_validation(file_df, spark_session, source_table_name, good_table_name, reject_table_name, props, partition_col, file_logger, parameter_obj.bow_name, parameter_obj.type_of_load)
        return source_count, target_count
    return 0, 0


def insert_data(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table, bow_name, type_load):
    overwrite_boolean = False
    if type_load.lower() == 'f':
        overwrite_boolean = True
    #unique_records_df.show(5)
    # unique_records_df.write.mode("overwrite").saveAsTable(good_table)
    spark.sql("SET hive.exec.dynamic.partition = true")
    spark.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
    # Truncate and Load
    if bow_name.lower() != 'anaplan':
        unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4), substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType())).write.format("avro").insertInto(good_table, overwrite=overwrite_boolean)
    else:
        unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2), substring(from_unixtime(unix_timestamp()), 9, 2)).cast(IntegerType())).write.format("avro").insertInto(good_table, overwrite=overwrite_boolean)

    if count_error_records > 0:
        error_records.write.mode("append").format("text").insertInto(reject_table, overwrite=False)
