from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp,col , when, trim
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType, DecimalType,DateType
from datetime import datetime
import sys, os, re
import data_quality_helper as file_helper, data_quality_helper
import file_validation
import table_validation


batch_id_arg = sys.argv[1]
bow_id_arg = sys.argv[2]
load_number_arg = sys.argv[3]
batch_exec_id_arg = sys.argv[4]
sbow_id_arg = sys.argv[5]
file_config = sys.argv[6]
field_validation = sys.argv[7]


print("Arguments are : arg 1 (batch_id) " + batch_id_arg)
print("Arguments are : arg 2 (bow_id) " + bow_id_arg)
print("Arguments are : arg 3 (load_number) " + load_number_arg)
print("Arguments are : arg 4 (batch_exec_id) " + batch_exec_id_arg)
print("Arguments are : arg 5 (sbow_id) " + sbow_id_arg)
print("Arguments are : arg 6 (file_config) " + file_config)
print("Arguments are : arg 7 (field_validation) " + field_validation)


aux_control_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("bow_name", StringType(), True), StructField("cdc_start_timestamp", StringType(), True),StructField("cdc_end_timestamp", StringType(), True), StructField("prev_cdc_start_timestamp", TimestampType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),StructField("uow_unique_id", StringType(), True), StructField("cdc_type_description", StringType(), True), StructField("change_data_capture_last_sequence_number", DecimalType(), True),StructField("previous_change_data_capture_last_sequence_number", DecimalType(), True), StructField("insert_gmt_timestamp", StringType(), True), StructField("batch_execution_id", StringType(), True), StructField("batch_id", IntegerType(), True)])
file_load_hst_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("batch_id", IntegerType(), True), StructField("uow_id", IntegerType(), True), StructField("source_file_path", StringType(), True), StructField("file_landing_path", StringType(), False), StructField("file_name_processed", StringType(), True), StructField("batch_execution_id", StringType(), True), StructField("file_archive_path", StringType(), True)])
app_name = ''
if field_validation == '2':
    app_name = "File_and_Field_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'
else:
    app_name = "File_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'

spark_session_obj = SparkSession.builder.enableHiveSupport().appName(app_name).getOrCreate()
spark_session_obj.sparkContext.setLogLevel("INFO")
log4jLogger = spark_session_obj.sparkContext._jvm.org.apache.log4j
file_logger = log4jLogger.LogManager.getLogger(__name__)

file_logger.error('THIS IS EDW')

def read_data_file(spark_session, data_file, schema, parameter_obj):
    set_header = "false"
    if parameter_obj.is_header_included.lower() == 'y':
        set_header = "true"

    try:
        chr(int(parameter_obj.delimiter))
    except ValueError:
        file_logger.error('Invalid column separator.' + parameter_obj.delimiter)

    file_ext = parameter_obj.extension
    file_logger.info('DATA file is of type ' + file_ext)

    
    if file_ext.lower() == props['LZ4'].lower():
        file_data_df = spark_session.read.option("header", set_header).option("treatEmptyValuesAsNulls", "true").option("delimiter", chr(int(parameter_obj.delimiter))).csv(data_file).toDF(*schema)
        #=======================================================================
        # if parameter_obj.is_part_file.lower() == 'y':
        #     dir_name = '/'.join(data_file.split('/')[:-1])
        #     file_data_df = spark_session.read.option("header", set_header).option("delimiter", chr(int(parameter_obj.delimiter))).csv(dir_name).toDF(*schema)
        #     # file_data_df.show(5, truncate=False)
        # else:
        #     file_data_df = spark_session.read.option("header", set_header).option("delimiter", chr(int(parameter_obj.delimiter))).csv(data_file).toDF(*schema)
        # 
        #=======================================================================
        return file_data_df

    else:
        file_logger.info('DATA file type of ' + file_ext + ' not defined. So exiting the process.')
        sys.exit(0)

#execute_spark(spark_session_obj, source_table, do_pre_process, load_number_arg, logical_deletion_indicator_arg, props, param_obj,all_del_files_list,all_data_files_list)
def execute_spark(spark_session, source_table_name, doPreProcess, load_number, props, parameter_object,files_list_tn,files_list_del,ctl_txn_list , ctl_del_list):
    print("Inside execute_spark for lz4")
    if not source_table_name:
        file_logger.info('The target hive table is not defined, so exiting the process.')
        sys.exit(0)
    col_name = props['TS_COLUMN_NAME']
    #new_col_name = col_name + '_copy'
    #file_logger.info('File name ' + file)
    #full_dataframe,df_tn,df_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    dType = ''
    df_tn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    df_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    full_dataframe_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    full_dataframe_txn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    max_date_del_list = []
    max_date_txn_list = []
    file_hist_load_txn_list = []
    file_hist_load_del_list = []
    if doPreProcess == 'true':
        source_system_id = parameter_object.source_system_identifier
        query = "desc " + source_table_name
        col_list, data_type_list, nullable_list = file_helper.read_schema_from_hive(props['REGEX_DESCRIBE'], query, props['JDBC_URL_BEELINE'])
        file_logger.info('Schema from hive')
        file_logger.info(col_list)

        txn_table_cols = col_list[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):]
        if "extrc_eff_ts" in txn_table_cols: txn_table_cols.remove("extrc_eff_ts")
        
        dict_col = {"string":"StringType()", "bigint":"IntegerType()","timestamp":"TimestampType()","smallint":"IntegerType()","decimal":"DecimalType()","int":"IntegerType()","date":"DateType()","varchar":"StringType()"}
 
        #=======================================================================
        # tnSchema = 'StructType('
        # if len(col_list)>0:
        #     for i in range(len(col_list)):
        #         for x, spark_sql_types in dict_col.items():
        #             if data_type_list[i] in x:
        #                 print(table_cols[i] + " " +spark_sql_types)
        #                 tnSchema = tnSchema +"StructField("+table_cols[i]+","+spark_sql_types+","+nullable_list[i]+")" + ",";
        # tnSchema =  tnSchema[:-1] +")"
        #  
        # print('tnSchema ',tnSchema)
        #  
        #=======================================================================
        del_columns = parameter_object.del_columns
        print(" del_col_list "+del_columns+" ")
        #file_logger.info('del_col_list',del_columns)
        #myListedString="EXTRC_EFF_TS,SPRN_CO_ID,FIN_CLOSE_DT,SO_ID,SRC_SYS_KY,ORD_CRT_DT,SO_LN_ITM_ID,EFF_FRM_GMT_TS,CONTRA_FG,BUS_AREA_CD,PROD_ID,BILT_CUST_ID,END_CUST_ID,SHPT_CUST_ID,SLDT_CUST_ID,SO_TYPE_CD,OM_SRC_SYS_KY,SO_DTL_STAT_CD,SRC_PROD_LN_ID,PRFT_CTR_CD,REC_EXPLN_CD,CROSS_BORD_FG,DOC_CRNCY_CD,CBN_ID,INS_GMT_TS,UPD_GMT_TS,LOAD_JOB_NR"
        #myList = []
        del_col_list  = list(del_columns.split(","));
        print(del_col_list)
        #file_logger.info('del_col_list'+ del_col_list)
        #del_col_list = del_col_strn.replace('"','')
        #print('del_col_list_without_q',del_col_list)
 #==============================================================================
 #        delSchema = 'StructType('
 #        if len(del_col_list)>0:
 #            for i in range(len(col_list)):
 #                for x, spark_sql_types in dict_col.items():
 #                    if (col_list[i] in del_col_list and data_type_list[i] in x):
 #                        print(col_list[i])
 #                        print(spark_sql_types)
 #                        delSchema = delSchema +"StructField("+col_list[i]+","+spark_sql_types+","+nullable_list[i]+")" + ",";
 #        delSchema =  delSchema[:-1] +")"
 # 
 #         
 #        print('delSchema ',delSchema)
 #==============================================================================
        
        if len(files_list_del)>0:
            print("files_list_del ", files_list_del)
            #file_logger.info('files_list_del'+files_list_del)
            dType = "DEL"
            for source_del_file_list in files_list_del:
                for source_del_file in source_del_file_list:
                    print("source_del_file",source_del_file)
                    df_del = read_data_file(spark_session, source_del_file, del_col_list, parameter_object)
                    df_del.show(1,False)
                    df_del_count = df_del.count()
                    file_logger.info('The df_count source_del_file is ' + str(df_del_count))
                    del_cond = del_col_list;
                    print("condition", del_cond)
                    print("Actual Schema")
                    file_logger.info('The condition is  ' + str(del_cond))
                    full_dataframe_del.printSchema()
                    print("DEL file Schema")
                    df_del.printSchema()
                    df_del_final = full_dataframe_del.join(df_del,del_cond,"outer")
                    df_cols = [col(x) for x in col_list]
                    full_dataframe_del = full_dataframe_del.union(df_del_final.select(df_cols))
                    print("After join and union the full dataframe Schema is ")
                    full_dataframe_del.printSchema()
                    full_dataframe_del.show(1,False)
                    file_name = os.path.split(source_del_file)[-1]
                    index_of_extension = file_name.lower().index(param_obj.extension.lower())
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    print(file_name[0:index_of_extension-1])
                    file_split_without_part = file_name_without_ext.split("_")
                    print("file_split_without_part in DEL",file_split_without_part)
                    prep_file_hist_load_del = file_split_without_part[0:-1]
                    file_hist_load_del = param_obj.source_file_path + "_".join(prep_file_hist_load_del)
                    print("file_hist_load_del" ,file_hist_load_del)
                    file_hist_load_del_list.append(file_hist_load_del)
                    print("file_hist_load_del_list",file_hist_load_del_list)
                    date_time_value_del = re.search(param_obj.del_timestamp_pattern.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(param_obj.del_timestamp_pattern.lower(), file_name_without_ext.lower()).group(2))
                    print('The DEL file name to be processed by spark ' + file_name + ' having datetime value as ' + date_time_value_del)
                    file_logger.info('The DEL file name to be processed by spark ' + file_name + ' having datetime value as ' + date_time_value_del)
                    max_date_del_list.append(int(date_time_value_del));
            insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            spark_session.sql("SET hive.exec.dynamic.partition = true")
            spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
            print("before")
            full_dataframe_del.show(1,False)
            full_dataframe_del.printSchema()
            df_del_insert = full_dataframe_del.withColumn('source_system_identifier', lit(full_dataframe_del['SRC_SYS_KY'])).withColumn('logical_deletion_indicator',lit('D')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts));
            print("before")
            df_del_insert.printSchema()
            df_cols = [col(x) for x in col_list]
            df_total_del_count = df_del_insert.count();
            if parameter_object.is_control_file.lower() == 'y':
                audit_control_file_del = ctl_del_list[0]
                print("Reading the CTL file for DEL ",audit_control_file_del)
                record_count = file_helper.read_ctrl_file_edw(audit_control_file_del)
                if int(record_count) > 0:
                    if df_total_del_count == int(record_count):
                        file_logger.info('The control file validation successful')
                    else:
                        file_logger.info('The record count does not match')
                        sys.exit(0)
            df_del_insert.select(df_cols).write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)
            print("After insert")
            df_show = spark_session.sql(" select * from " + source_table_name )
            df_show.show(1,False)
            max_date_del = max(max_date_del_list)
            print("This is the max date of the del file",max_date_del)
            if max_date_del:
                new_time_value = datetime.strptime(str(max_date_del), param_obj.timestamp_format).strftime('%Y-%m-%d %H:%M:%S.%f')
                aux_control_data = [[int(bow_id_arg), None, new_time_value, new_time_value, None, None, param_obj.del_uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id_arg, int(batch_id_arg)]]
                aux_ctrl_df = file_helper.create_df(spark_session_obj, aux_control_data, aux_control_schema)
        
                aux_ctrl_table_name = pre_table_name + props['AUX_CONTROL_TABLE']
                aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name', unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_start_timestamp"), unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp', 'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description', 'change_data_capture_last_sequence_number', 'previous_change_data_capture_last_sequence_number', unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id', 'batch_id')
                aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
                if field_validation == '2':
                    table_validation.validate_parameter_obj_edw(spark_session_obj, batch_id_arg, bow_id_arg, load_number_arg, batch_exec_id_arg, sbow_id_arg, props, param_obj, file_logger,dType)
                file_load_hst_table_name = pre_table_name + props['FILE_LOAD_HST_TABLE']
                file_load_hst_data = file_helper.create_file_load_hst_data_edw(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path,file_hist_load_del_list,batch_exec_id_arg, param_obj.archive_file_path)
                file_load_hst_df = file_helper.create_df(spark_session_obj, file_load_hst_data, file_load_hst_schema)
                file_load_hst_df.write.mode("append").format("text").insertInto(file_load_hst_table_name, overwrite=False)
                #file_helper.archive_files(file_load_hst_data)
        else:
            print("IS_DEL_FILE is set to N, hence not processing DEL")
      
                
          
        if len(files_list_tn)>0:
            print("files_list_tn ", files_list_tn)
            dType = "TXN"
            print('txn_table_cols without preappended cols ' , txn_table_cols)
            for source_tn_file_list in files_list_tn:
                for source_tn_file in source_tn_file_list:
                    print("source_tn_file",source_tn_file)
                    df_tn = read_data_file(spark_session, source_tn_file, txn_table_cols, parameter_object)
                    df_tn.show(1,False)
                    df_tn_count = df_tn.count()
                    file_logger.info('The df_count source_tn_file is ' + str(df_tn_count))
                    insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            
                    df_tn = df_tn.withColumn("extrc_eff_ts",lit(None)).withColumn('source_system_identifier',lit(df_tn['SRC_SYS_KY'])).withColumn('logical_deletion_indicator',lit('U')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts))
                    #df_tn = df_tn.select(lit(full_dataframe_txn['SRC_SYS_KY']).alias('source_system_identifier'),lit('U').alias('logical_deletion_indicator'),lit(insert_ts).alias('insert_gmt_timestamp'),lit(load_number).alias('load_job_number'),lit(insert_ts).alias('source_system_extract_gmt_timestamp'), lit(insert_ts).alias('last_modified_ts'), '*')
                    df_cols = [col(x) for x in col_list]
                    full_dataframe_txn = full_dataframe_txn.union(df_tn.select(df_cols))
                    file_name = os.path.split(source_tn_file)[-1]
                    index_of_extension = file_name.lower().index(param_obj.extension.lower())
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    print(file_name[0:index_of_extension-1])
                    file_split_without_part = file_name_without_ext.split("_")
                    print("file_split_without_part TXN",file_split_without_part)
                    prep_file_hist_load_txn = file_split_without_part[0:-1]
                    file_hist_load_txn = param_obj.source_file_path + "_".join(prep_file_hist_load_txn)
                    print("file_hist_load_txn" ,file_hist_load_txn)
                    file_hist_load_txn_list.append(file_hist_load_txn)
                    print("file_hist_load_txn_list",file_hist_load_txn_list)
                    date_time_value_txn = re.search(param_obj.ad_timestamp_pattern.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(param_obj.ad_timestamp_pattern.lower(), file_name_without_ext.lower()).group(2))
                    max_date_txn_list.append(int(date_time_value_txn));
                    print('The Txn file name to be processed by spark ' + file_name + ' having datetime value as ' + date_time_value_txn)
            spark_session.sql("SET hive.exec.dynamic.partition = true")
            spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
            print("parameter_object.is_control_file" ,parameter_object.is_control_file)
            if parameter_object.is_control_file.lower() == 'y':
                print("Reading the CTL file for TXN ",ctl_txn_list[0])
                audit_control_file_txn = ctl_txn_list[0];
                print("audit_control_file_txn",audit_control_file_txn)
                record_count = file_helper.read_ctrl_file_edw(audit_control_file_txn)
                if int(record_count) > 0:
                    if full_dataframe_txn.count() == int(record_count):
                        print('The control file validation successful with count' ,full_dataframe_txn.count())
                        file_logger.info('The control file validation successful')
                    else:
                        print('The record count does not match')
                        file_logger.info('The record count does not match')
                        sys.exit(0)
            prev_timestamp = data_quality_helper.find_max_insert_gmt_ts(source_table_name,jdbc_url_beeline);
            print("prev_timestamp",prev_timestamp)
            if prev_timestamp == "NULL" or prev_timestamp == '':
                print("Loading LZ for first time hence prev_timestamp is ", prev_timestamp)
                today_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                prev_timestamp =int(datetime.strptime(today_ts, '%Y-%m-%d %H:%M:%S.%f').strftime('%Y%m%d'));
                print("prev_timestamp",prev_timestamp)
            print("prev_timestamp from LZ table before inserting new data" , prev_timestamp)
            full_dataframe_txn.write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)
            max_date_txn = max(max_date_txn_list)
            print("This is the max date of the txn file",max_date_txn)
            if max_date_txn:
                new_time_value = datetime.strptime(str(max_date_txn), param_obj.timestamp_format).strftime('%Y-%m-%d %H:%M:%S.%f')
                aux_control_data = [[int(bow_id_arg), None, new_time_value, new_time_value, None, None, param_obj.uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id_arg, int(batch_id_arg)]]
                aux_ctrl_df = file_helper.create_df(spark_session_obj, aux_control_data, aux_control_schema)
     
                aux_ctrl_table_name = pre_table_name + props['AUX_CONTROL_TABLE']
                aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name', unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_start_timestamp"), unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp', 'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description', 'change_data_capture_last_sequence_number', 'previous_change_data_capture_last_sequence_number', unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id', 'batch_id')
                aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
     
                if field_validation == '2':
                    table_validation.validate_parameter_obj_edw(spark_session_obj, batch_id_arg, bow_id_arg, load_number_arg, batch_exec_id_arg, sbow_id_arg, props, param_obj, file_logger,dType,str(prev_timestamp))
                    total_file_list = files_list_tn + files_list_del
                    print('total_file_list',total_file_list)

                file_load_hst_table_name = pre_table_name + props['FILE_LOAD_HST_TABLE']
                file_load_hst_data = file_helper.create_file_load_hst_data_edw(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path,file_hist_load_txn_list,batch_exec_id_arg, param_obj.archive_file_path)
                print("file_load_hst_data" , file_load_hst_data)
                file_load_hst_df = file_helper.create_df(spark_session_obj, file_load_hst_data, file_load_hst_schema)
                file_load_hst_df.write.mode("append").format("text").insertInto(file_load_hst_table_name, overwrite=False)
                #file_helper.archive_files(file_load_hst_data)
           

        
        

props = file_helper.read_all_properties(file_config)
pre_table_name = props['DATABASE_NAME']
do_pre_process = props['DO_PREPROCESS']
edw_ctrl_format = props['EDW_CTRL_FORMAT']
jdbc_url_beeline = props['JDBC_URL_BEELINE']
lfs_log = ''
landing_path = ''
hdfs_log_path = ''

all_parameter_obj = file_helper.load_file_control_ingestion_for_LZ4(props, batch_id_arg, bow_id_arg)
for param_obj in all_parameter_obj:
    #if param_obj.extension.lower() in ['lz4']:
        print("This is an lz4 file")
        #hdfs_cmd = ['hdfs', 'dfs', '-test', '-d', param_obj.source_file_path+";echo $?"]
        hdfs_cmd = ['hdfs', 'dfs', '-test', '-d', param_obj.source_file_path]
        hdfs_path_exists= file_helper.check_hdfs_path_exists(hdfs_cmd);
        print("hdfs_path_exists", hdfs_path_exists)
        if hdfs_path_exists==0:
            print("hdfs_path_exists",hdfs_path_exists)
            pre_table_name_edw = param_obj.hive_schema_name
            source_table = param_obj.lz_table_name
            lfs_log = param_obj.lfs_log_path
            hdfs_log_path = param_obj.log_path
            if not source_table.startswith(pre_table_name_edw):
                source_table = pre_table_name_edw + '.' + source_table
                tn_files_dict , del_files_dict , txn_ctl_list , del_ctl_list = file_validation.check_del_in_lz4_files_dict(param_obj, props, file_logger,edw_ctrl_format)
                print("tn_files_dict",tn_files_dict)
                print("del_files_dict",del_files_dict)
                if len(tn_files_dict)>0:
                    tn_files_list = tn_files_dict.values()
                    del_files_list = del_files_dict.values()
                    #all_data_files_list = list(all_data_files_dict.keys())
                    execute_spark(spark_session_obj, source_table, do_pre_process, load_number_arg, props, param_obj,tn_files_list,del_files_list ,txn_ctl_list , del_ctl_list)
                else:
                    print("No txn files present in this Path, hence nothing to process, exiting...")
                    sys.exit(0);
        else:
            print("Not a valid HDFS path for lz4")

app_id = spark_session_obj.sparkContext.applicationId
spark_session_obj.stop()

log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
log_file_name = lfs_log.rstrip('/') + '/dq1_ingestion_batch_id_' + str(batch_id_arg) + '_bow_id_' + str(bow_id_arg) + '_' + log_time_value + '.log'
file_logger.info("(log_file_name) " + log_file_name)
file_helper.generate_log(file_logger, log_file_name, app_id, 'dummy')
file_helper.copy_log_files(lfs_log, hdfs_log_path)
