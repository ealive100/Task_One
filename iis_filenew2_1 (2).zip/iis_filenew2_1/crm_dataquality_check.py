from pyspark.sql import SparkSession
from pyspark.sql.functions import unix_timestamp, from_unixtime, substring, concat
from pyspark.sql.types import IntegerType
import sys, os, subprocess, time
import crm_config as config
import crm_helper as table_validation
"""
This class provides various functions to do data quality checks on source records in form of dat file.
1.Data type check
2.Duplicate record check
3.Null check
"""
source_table_name = sys.argv[1]
spark_session = SparkSession.builder.enableHiveSupport().appName(source_table_name).getOrCreate()
log4jLogger = spark_session.sparkContext._jvm.org.apache.log4j
file_logger = log4jLogger.LogManager.getLogger(__name__)
spark_session.sparkContext.setLogLevel("ERROR")
file_logger.debug("DQ with pyspark script logger initialized")

good_table_name = sys.argv[2]
reject_table_name = sys.argv[3]
log_path = sys.argv[4]

file_logger.debug("Arguments are from crm_dataquality_check: arg 1 (source_table_name) " + source_table_name)
file_logger.debug("Arguments are from crm_dataquality_check: arg 2 (good_table_name) " + good_table_name)
file_logger.debug("Arguments are from crm_dataquality_check: arg 3 (reject_table_name) " + reject_table_name)
file_logger.debug("Arguments are from crm_dataquality_check: arg 4 (log_path) " + log_path)
log_table_path = log_path.rstrip('/') + '/' + source_table_name.split('.')[-1]
partition_col = config.PARTITION_COLUMN_NAME


def execute_dq_process_table(spark, table_name,good_table, reject_table):

    unique_records_df, error_records, count_error_records = table_validation.validate_table_data(spark, table_name, file_logger)
    #unique_records_df.show(5)
    # unique_records_df.write.mode("overwrite").saveAsTable(good_table)
    spark.sql("SET hive.exec.dynamic.partition = true")
    spark.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
    # Truncate and Load
    unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType())).write.mode("append").format("avro").insertInto(good_table, overwrite=False)
    if count_error_records > 0:
        error_records.write.mode("append").format("text").insertInto(reject_table, overwrite=False)
    # error_records.write.mode("append").saveAsTable(reject_table)


def check_progress(application_id):
    cmd = 'yarn application -status ' + application_id
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    file_logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
    lines = out.splitlines()
    complete = False
    for line in lines:
        if 'RUNNING' in line:
            complete = False
        if 'SUCCEEDED' in line:
            complete = True
    return complete


def generate_log(log_path, application_id):
    file_logger.debug("Spark ApplicationId " + application_id)
    os.system('hadoop fs -rm -r ' + log_path)
    os.system('mkdir -p ' + log_path)
    os.system('hadoop fs -mkdir -p ' + log_path)
    file_success = config.SUCCESS
    file_failure = config.FAILED
    yarn_failure = config.JOB_NOT_RUN
    file_path = log_path + '/pyspark.log'
    if application_id:
        yarn_log_cmd = 'yarn logs -applicationId ' + application_id + ' > ' + file_path
        yarn_cmd = yarn_log_cmd.split()
        log_p = subprocess.Popen(yarn_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log_out, log_err = log_p.communicate()
        if log_p.returncode == 0:
            file_logger.debug("Yarn log status Code " + str(log_p.returncode))
        os.system('hadoop fs -rm  ' + log_path + '/pyspark.log')
        os.system('hadoop fs -put  ' + log_path + '/pyspark.log ' + log_table_path)
        cmd = 'yarn application -status ' + application_id
        command = cmd.split()
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        file_logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
        lines = out.splitlines()
        status = False
        is_complete = False
        for line in lines:
            if 'FINISHED' in line:
                is_complete = True
            if 'SUCCEEDED' in line:
                status = True
        if status and is_complete:
            os.system('hadoop fs -touchz ' + log_table_path + '/' + file_success)
        else:
            os.system('hadoop fs -touchz ' + log_table_path + '/' + file_failure)
    else:
        os.system('hadoop fs -touchz ' + log_table_path + '/' + yarn_failure)


execute_dq_process_table(spark_session, source_table_name, good_table_name, reject_table_name)
app_id = spark_session.sparkContext.applicationId
spark_session.stop()
generate_log(log_table_path, app_id)

