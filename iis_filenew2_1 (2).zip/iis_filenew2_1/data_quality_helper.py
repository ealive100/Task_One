import subprocess, re, os, io
import data_quality_configuration


def get_connection_url(driver_name, server_name, database_name, uid_name, password):
    return 'DRIVER={' + driver_name + '};SERVER=' + server_name + ';DATABASE=' + database_name + ';UID=' + uid_name + ';PWD=' + password


def update_reject_files(all_files_dict, reject_path, source_file, reject_file_dict, log_msg):

    dir_name = os.path.split(source_file)[0]
    reject_file_list = []
    for key, value in all_files_dict.items():
        if value == dir_name or key == source_file:
            print("key found " + key)
            reject_file_list.append(key)
            reject_file_dict[key] = log_msg
    move_files(reject_file_list, reject_path)
    return reject_file_dict


def sorted_on_datetime(source_file_list, file_ext, timestamp_pattern):

    def find_date_time(source_file, file_ext, timestamp_pattern):
        try:
            file_name = os.path.split(source_file)[-1]
            index_of_extension = file_name.lower().index('.' + file_ext.lower())
            file_name_without_ext = file_name.lower()[0:index_of_extension]
            date_time_value = re.search(timestamp_pattern.lower(), file_name_without_ext).group(1)
            return date_time_value
        except Exception as e:
            print("The source file datetime sorting issue: " + source_file)
            print(e)
        return None

    return sorted(source_file_list, key=lambda x: find_date_time(x, file_ext, timestamp_pattern))


def get_decimal_pattern(precision_scale_pattern, decimal_type, reg_ex_decimal):

    try:
        precision_scale = re.findall(precision_scale_pattern, decimal_type)

    except ValueError:
        precision_scale = ['1,38']
    if not precision_scale:
        precision_scale = ['1,38']

    return reg_ex_decimal.replace('precision', precision_scale[0].split(",")[1]).replace('scale', precision_scale[0].split(",")[0])


def create_file_load_hst_data(bow_id, batch_id, uow_id, source_file_path, file_landing_path, processed_files, batch_exec_id, archive_file_path):
    return [[bow_id, batch_id, uow_id, data_file, processed_files[data_file], None, batch_exec_id, archive_file_path] for data_file in processed_files]


def create_df(spark, data, schema):
    return spark.createDataFrame(data, schema=schema)


def read_all_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.toDF(*schema)


def count_all_rows_from_hive(spark, table_name):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.count()


def read_distinct_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select distinct * from " + table_name)

    return table_schema_df.toDF(*schema)


def check_progress(application_id, logger):
    cmd = 'yarn application -status ' + application_id
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
    lines = out.splitlines()
    complete = False
    for line in lines:
        if 'RUNNING' in line:
            complete = False
        if 'SUCCEEDED' in line:
            complete = True
    return complete


def list_files_by_date(location, file_pattern, timestamp_pattern, logger):
    file_list_by_date = []

    if timestamp_pattern:
        dir_files = os.listdir(location)
        set_date_values = sorted(list(set(find_all_dates_for_group(logger, dir_files, file_pattern, timestamp_pattern))))
        logger.debug(set_date_values)
        for file_date in set_date_values:
            file_list = []
            for source_file in dir_files:
                if file_pattern in source_file.lower() and file_date in source_file.lower():
                    file_list.append(source_file)
            file_list_by_date.append(file_list)

    return file_list_by_date


def find_all_dates_for_group(logger, dir_files, pattern_file, regex_pattern):

    all_date_values = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]
            logger.debug(my_file)
            try:
                my_file_name = re.search(pattern_file, my_file_name.lower()).group(0)
                logger.debug('After using regex on file pattern ' + my_file_name)
            except AttributeError:
                continue
            if my_file_name:
                logger.debug('The zip file selected ' + my_file)
                try:
                    date_time_value = re.search(regex_pattern, my_file_name.lower()).group(1)
                    logger.debug('After using regex on timestamp pattern ' + date_time_value)
                except AttributeError:
                    continue
                all_date_values.append(date_time_value)
    else:
        logger.debug('No files found in the path.')
        exit(0)
    return all_date_values


def read_all_properties(config):
    prop_file = open(config, 'r')
    key_values = {}
    for line in prop_file:
            line_components = line.split('=', 1)
            if line_components[0]:
                key_values[line_components[0].strip()] = line_components[1].strip()
    prop_file.close()
    return key_values


def read_parameter_file(parameter_config, line_split):
    prop_file = open(parameter_config, 'r')
    parameter_props = []

    all_columns = []
    for line in prop_file:
        line = line.rstrip('\n')
        if line:
            all_columns.append(line.split(line_split))
    prop_file.close()

    column_names = all_columns[0]
    column_values = all_columns[1:]
    for columns in column_values:
        key_values = {}
        key_value = zip(column_names, columns)
        for k, v in key_value:
            key_values[k.strip(' ')] = v.strip(' ')
        parameter_props.append(key_values)

    return parameter_props


def count_lines_excel(excel_file_name):
    import xlrd
    workbook = xlrd.open_workbook(excel_file_name, on_demand=True)
    sheet_name = workbook.sheet_names()[0]

    worksheet = workbook.sheet_by_name(sheet_name)
    return worksheet.nrows


def count_lines(dat_file, file_type='dat'):
    counter = 0
    if file_type.lower() == 'xlsx':
        counter = count_lines_excel(dat_file)
    else:
        with open(dat_file) as f:
            for i, l in enumerate(f):
                counter = counter + 1
    return counter


def find_column_count(dat_file):
    data_file_reader = open(dat_file, 'r')
    column_count = []
    counter = 0
    for line in data_file_reader:
        counter = counter + 1
        line = line.rstrip('\n')
        if len(line.split(chr(28))) != 106:
            column_count.append(str(counter) + ' ' + str(len(line.split(chr(28)))))
    data_file_reader.close()
    return column_count


def read_schema_from_hive_using_collect(spark, desc_query):
    print(desc_query)
    # print("collect schema from dataframe")
    schema_list = spark.sql(desc_query).collect()
    col_name_list = [str(row.col_name) for row in schema_list]
    datatype_list = [str(row.data_type) for row in schema_list]
    nullable_list = [str(row.comment).split(":")[0] for row in schema_list]

    return col_name_list, datatype_list, nullable_list


def read_schema_from_hive(regex_desc, desc_query, jdbc_url):
    # print(desc_query)
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", desc_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    stdout, stderr = p.communicate()
    p.wait()
    lines = stdout.splitlines()
    col_names = []
    data_types = []
    nullable = []
    for line in lines:
        cols = re.findall(regex_desc, line.replace('|', ''))
        if len(cols) == 10:
            col_names.append(cols[0])
            data_types.append(cols[1])
            nullable.append(cols[3])
    return col_names, data_types, nullable


def load_hive_data_from_python(split_char, sql_query, jdbc_url, obj):

    first_column = sql_query.split(',')[0].strip('select').strip(' ')
    col_count = len(sql_query.split(','))
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", sql_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # print(sql_query)
    stdout, stderr = p.communicate()
    # print(p.returncode)
    p.wait()
    lines = stdout.split(chr(int(split_char)))
    object_list = []

    col_len = len(lines)
    junk_col = 1
    rows = int(round(col_len / col_count))
    counter = 1
    start_col_value_index = 0
    last_col_value_index = 0
    for i in range(0, rows):
        start_col_value_index = start_col_value_index + junk_col
        last_col_value_index = col_count + junk_col + last_col_value_index
        data = lines[start_col_value_index: last_col_value_index]
        data = [col.strip(" ") for col in data]
        if len(data) == col_count and data[0] != first_column:
            object_list.append(obj(*data))
        else:
            counter = counter + 1
        start_col_value_index = start_col_value_index + col_count
    return object_list


def generate_log(file_logger, file_path, application_id, touch_file_name):
    file_logger.debug("Spark ApplicationId " + application_id)
    # os.system('hadoop fs -rm ' + file_path)
    file_success = '_SUCCESS'
    file_failure = '_FAILED'
    yarn_failure = '_JOB_NOT_RUN'

    if application_id:
        yarn_log_cmd = 'yarn logs -applicationId ' + application_id + ' > ' + file_path
        os.system(yarn_log_cmd)
        # yarn_cmd = yarn_log_cmd.split()
        # log_p = subprocess.Popen(yarn_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # log_out, log_err = log_p.communicate()
        # log_p.wait()
        # if log_p.returncode == 0:
        #     file_logger.info("Yarn log status Code " + str(log_p.returncode))
        # os.system('hadoop fs -rm  ' + file_path)
        # os.system('hadoop fs -put  ' + file_path + ' ' + file_log_path)
        cmd = 'yarn application -status ' + application_id
        command = cmd.split()
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        file_logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
        lines = out.splitlines()
        status = False
        is_complete = False
        for line in lines:
            if 'FINISHED' in line:
                is_complete = True
            if 'SUCCEEDED' in line:
                status = True
        # if status and is_complete:
        #     os.system('touch ' + file_path + file_success)
        #     os.system('touch ' + touch_file_name)
        # else:
        #     os.system('touch ' + file_path + file_failure)
    else:
        file_logger.debug('YARN FAILURE')
        # os.system('touch ' + file_path + yarn_failure)


def read_aud_file_key(file_path, aud_key, logger, encoding_format):
    aud_keys = {}
    with io.open(file_path, encoding=encoding_format, errors='ignore') as file_reader:
    #with io.open(file_path, encoding='utf-16', errors='ignore') as file_reader:
        for line in file_reader:
            line = line.strip(' ')
            if ':' in line and aud_key in line:
                key_value = line.split(':')
                try:
                    aud_keys[key_value[0].strip()] = key_value[1].encode('latin-1').decode('ascii', 'ignore').strip().rstrip('\n')
                    # print(aud_keys)
                except:
                    logger.debug('Encoding error while reading' + file_path + ' for aud_key ' + aud_key)
                    aud_keys[key_value[0].strip()] = key_value[1].strip()
    return aud_keys[aud_key]


def find_all_files(archive_file, valid_files_dict):

    valid_files_dict[archive_file] = archive_file
    return valid_files_dict


def copy_files(all_files, dest_dir_name):

    # os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    if len(all_files) > 0:
        files = ' '.join(all_files)
        # print("Good files " + files + " are being copied to " + dest_dir_name)
        fs_put(files, dest_dir_name)


def move_files(all_files, dest_dir_name):

    # os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    if len(all_files) > 0:
        files = ' '.join(all_files)
        fs_move(files, dest_dir_name)


def copy_files_if_header_exist(all_files, dest_dir_name, is_header_included, is_compressed, logger):

    os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    # header_enabled_list = props['HEADER_ENABLED'].split(',')
    if len(all_files) > 0:
        files_without_header = []
        for file in all_files:
            file_name = file.split('/')[-1]
            if is_header_included.lower() == 'y' and is_compressed.lower() == 'n':
                logger.debug('File having header ' + file)
                os.system("sed '1d' " + file + " | hdfs dfs -put - " + dest_dir_name.rstrip('/') + '/' + file_name)
            else:
                files_without_header.append(file)
        if len(files_without_header) > 0:
            files = ' '.join(files_without_header)
            fs_put(files, dest_dir_name)


def fs_put(file, dir_path):

    os.system('hadoop fs -put -f ' + file + ' ' + dir_path.rstrip('/') + '/')


def fs_move(file, dir_path):
    # print("files are moving from Local " + file + " to hdfs path " + dir_path)
    os.system('hadoop fs -moveFromLocal -f ' + file + ' ' + dir_path.rstrip('/') + '/')


def check_if_control_exists(extension, local_path, valid_files_dict, invalid_files_dict, logger, props):
    record_count = 0
    is_control_exist = False
    ctrl_file = ''
    # print(local_path)
    if os.path.isdir(local_path):

        for file in os.listdir(local_path):
            if file.endswith(props['CTL_EXT']):
                record_count = read_ctrl_file(os.path.join(local_path, file))
                ctrl_file = file
                if int(record_count) > 0:
                    is_control_exist = True
                else:
                    logger.debug('Even though the control file exist, record count is zero. Files not to be processed.')
        if is_control_exist:
            for file in os.listdir(local_path):
                if file.endswith(extension):
                    valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, ctrl_file)
        else:
            for file in local_path:
                logger.debug('The control file does not exist for file ' + file)
                invalid_files_dict[os.path.join(local_path, file)] = props['LOG_MSG_FOR_AUD_MISSING']

    return valid_files_dict, invalid_files_dict, record_count


def read_ctrl_file(ctrl_file):
    ctrl_file_reader = open(ctrl_file, 'r')
    lines = ctrl_file_reader.readlines()
    count = 0
    for line in lines:
        if line:
            count = line
    ctrl_file_reader.close()
    return count


def check_if_aud_exists(do_validate_file, local_path, valid_files_dict, invalid_files_dict, logger, props, extension, archive_file):

    if os.path.isdir(local_path):
        for file in os.listdir(local_path):
            if do_validate_file:
                # print(file)
                # print(extension)
                if file.lower().endswith(extension):
                    aud_file_name = os.path.join(local_path, file).rstrip('.' + extension) + props['AUD_EXT']
                    # print(aud_file_name)
                    if os.path.isfile(aud_file_name):
                        logger.debug('The aud exists for file ' + file)
                        valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, aud_file_name)
                    else:
                        logger.debug('The aud does not exist for file ' + file)
                        invalid_files_dict[archive_file] = props['LOG_MSG_FOR_AUD_MISSING']
            else:
                valid_files_dict[os.path.join(local_path, file)] = ''
    return valid_files_dict, invalid_files_dict


def check_if_row_count_zero(source_file, valid_files, invalid_files, logger, props, is_header_included, archive_file, file_type):

    row_count = count_lines(source_file, file_type)
    if is_header_included.lower() == 'y':
        row_count = row_count - 1
    # print("Dat File ",source_file)
    # print("rows found in dat file" , row_count)

    if row_count == 0:
        logger.debug('The row count is zero in the file ' + source_file + '. So it would be invalidated.')
        invalid_files[archive_file] = props['LOG_MSG_FOR_ZERO_COUNT_MATCH']
    else:
        valid_files[source_file] = source_file


def check_if_row_count_matches(do_validate_file, valid_files, invalid_files, logger, props, is_header_included, encoding_format, archive_file):

    if props['DO_COUNT_CHECK'] == 'false':
        # print(' COUNT validation ' + props['DO_COUNT_CHECK'])
        # print(valid_files)
        #print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read..." , dat_file)
                row_count = count_lines(dat_file)
                if is_header_included.lower() == 'y':
                    row_count = row_count - 1
                print("Dat File ",dat_file)
                print("rows found in dat file" , row_count)

                # print(props['RECORD_COUNT_KEY'])
                record_count_from_aud = read_aud_file_key(valid_files[dat_file], props['RECORD_COUNT_KEY'], logger, encoding_format)

                logger.debug('counts are ' + str(row_count) + ' and ' + record_count_from_aud)
                if row_count == 0:
                    logger.debug('The row count is zero in the file ' + dat_file + '. So it would be invalidated.')
                    counter = counter + 1
                    invalid_files[archive_file] = props['LOG_MSG_FOR_ZERO_COUNT_MATCH']
                elif str(row_count) == record_count_from_aud.strip():
                    logger.debug('The row count matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The row count does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[archive_file] = props['LOG_MSG_FOR_COUNT_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_rev_matches(is_rev_check, valid_files, invalid_files, logger, props, encoding_format, archive_file):

    if is_rev_check.lower() == 'n':
        # print(' REV validation ' + is_rev_check)
        # print(valid_files)
        # print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_rev = dat_file.split(os.path.sep)[-1].split('.')[int(props['REV_POSITION'])].strip()
                # print('rev found in dat file ', dat_file, file_rev)
                file_rev_from_aud = read_aud_file_key(valid_files[dat_file], props['REV_KEY'], logger, encoding_format).strip()
                # print('rev key has value', file_rev_from_aud)
                logger.debug('Revisions are from file name and aud as 1' + file_rev + '1 and 1' + file_rev_from_aud + '1')
                if file_rev == file_rev_from_aud:
                    logger.debug('The rev matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The rev does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[archive_file] = props['LOG_MSG_FOR_REV_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_seq_matches(is_seq_check, valid_files, invalid_files, logger, props, encoding_format, archive_file):

    if is_seq_check.lower() == 'n':
        # print(' SEQ validation ' + is_seq_check)
        #print(valid_files)
        # print(invalid_files)
        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_seq = dat_file.split(os.path.sep)[-1].split('.')[int(props['SEQ_POSITION'])]
                # print('seq found in dat file ', dat_file, file_seq)
                file_seq_from_aud = read_aud_file_key(valid_files[dat_file], props['SEQ_KEY'], logger, encoding_format)
                # print('rev key has value', file_seq_from_aud)
                if int(file_seq) == int(file_seq_from_aud):
                    logger.debug('The sequence matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The sequence does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[archive_file] = props['LOG_MSG_FOR_SEQ_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def load_job_paramter_ingestion(table_config, batch_number, bow_id):

    split_char = table_config['JOB_PARAMETER_INGESTION_LAYER_COLUMN_SEPARATOR']
    sql_query = table_config['JOB_PARAMETER_INGESTION_LAYER_QUERY'] + ' where batch_number = ' + batch_number + ' and bow_id = ' + bow_id
    hive_jdbc_url = table_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration.JobParameterIngestion

    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)


def insert_data_into_abcr_db(file_config, insert_query, data_object_list, db_password):
    sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'],
                                               file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'],
                                               db_password)
    data_quality_configuration.insert_data_object_list(sql_connection_string, insert_query, data_object_list)


def load_file_control_ingestion(file_config, batch_id, bow_id, db_password, hive_or_sql_server=0):

    if hive_or_sql_server == 1:
        split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
        sql_query = file_config['FILE_CONTROL_INGESTION_QUERY'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id
        hive_jdbc_url = file_config['JDBC_URL_BEELINE']
        object_name = data_quality_configuration.FileControlIngestion

        return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)
    else:
        select_query = file_config['FILE_CONTROL_INGESTION_QUERY_SQLDB']
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        # print('query ' + select_query)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration.get_data_object_list(sql_connection_string, data_quality_configuration.FileControlIngestion, select_query, batch_id, bow_id)
        return object_list


def archive_source_files(file_load_hst_data_dict, reject_files_dict, archive_file_path):
    reject_file_list = list(reject_files_dict.keys())
    all_source_files = list(file_load_hst_data_dict.keys())
    for source_file in all_source_files:
        if source_file not in reject_file_list:
            # print("Source File " + source_file + " is archiving  to " + archive_file_path)
            if os.path.isfile(source_file):
                fs_move(source_file, archive_file_path)
                # os.system('hdfs dfs -moveFromLocal ' + source_file + ' ' + archive_file_path)


def clean_working_path(destination_path):
    os.system('rm -fr  ' + destination_path.rstrip('/') + '/*')


def move_log_files(source_path, destination_path):
    log_file_list = []
    if os.path.isdir(source_path):
        for file in os.listdir(source_path):
            log_file = os.path.join(source_path, file)
            if os.path.isfile(log_file) and log_file.endswith('.log'):
                log_file_list.append(log_file)
    # print(log_file_list)
    move_files(log_file_list, destination_path)


def find_all_files_for_group(location, pattern_file):
    dir_files = os.listdir(location)
    all_file_names = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]

            try:
                my_file_name = re.search(pattern_file.lower(), my_file_name.lower()).group(0)

            except AttributeError:
                continue
            if my_file_name:
                all_file_names.append(my_file)
    else:
        print('No files found in the path.')
        exit(0)
    return all_file_names


def sorted_list_files_by_date(dir_files, file_pattern):
    if file_pattern:

        set_file_names = sorted(list(set(find_all_files_for_group(dir_files, file_pattern))))
        # print("set_file_names after sorting in asc ",set_file_names)

        return set_file_names

    return []


def list_hadoop_files(hadoop_path):
    cmd = 'hdfs dfs -ls -C ' + hadoop_path
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    #print("HDFS LS execution status " + str(p.returncode) + " with result " + out)
    files = out.splitlines()
    return files


def clean_hadoop_working_path(working_path):
    all_hadoop_files = list_hadoop_files(working_path)
    for hadoop_file in all_hadoop_files:
        os.system('hdfs dfs -rm -r  ' + hadoop_file)


def clean_local_working_path(file_dict):
    for key, value in file_dict.items():
        if value:
            delete_lfs_file(value)


def delete_lfs_file(lfs_file):
    if os.path.isfile(lfs_file):
        os.system('rm  ' + lfs_file)
    elif os.path.isdir(lfs_file):
        os.system('rm -fr ' + lfs_file)
    else:
        print('The file or dir is not exist in system path ' + lfs_file)

def load_file_control_ingestion_for_LZ4(file_config, batch_id, bow_id):

    split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
    sql_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id + ' and active_flag=Y '
    hive_jdbc_url = file_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration.EDWControlIngestion
    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)

def find_all_files_for_lz4_group(hdfs_path,pattern_file_del,timestamp_pattern_del,pattern_file_ad,timestamp_pattern_ad,file_ext):
    cmd = 'hdfs dfs -ls -C ' + hdfs_path
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    #print("HDFS LS execution status " + str(p.returncode) + " with result " + out)
    files = out.splitlines()
    del_hdfs_file_names_dict = {}
    tn_hdfs_file_names_dict = {}
    date_time_value_del = 0;
    date_time_value_ad = 0;
    if len(files) > 0:
            for my_file in files:
                file_name = os.path.split(my_file)[-1]
                index_of_extension = file_name.lower().index(file_ext)
                file_name_without_ext = file_name[0:index_of_extension-1]
                try:
                    print("Inside Try")
                    #file_name_without_ext = re.search(pattern_file_del.lower(), file_name_without_ext.lower()).group(0)
                    file_name_without_ext = re.search(pattern_file_ad.lower(), file_name_without_ext.lower()).group(0)
                    if file_name_without_ext:
                        try:
                            #date_time_value_del = re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(1)
                            date_time_value_ad = re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(2))
                            tn_hdfs_file_names_dict[date_time_value_ad] = my_file
                        except AttributeError:
                            continue
                except AttributeError:
                    continue
    else:
        print('No LZ4 files found in the path.')
    print('tn_hdfs_file_names_dict',tn_hdfs_file_names_dict)
         
    if len(tn_hdfs_file_names_dict)>0:   
            for my_file in files:
                file_name = os.path.split(my_file)[-1]
                index_of_extension = file_name.lower().index(file_ext)
                file_name_without_ext = file_name[0:index_of_extension-1]
                print(file_name_without_ext)
                try:
                    #file_name_without_ext = re.search(pattern_file_ad, file_name_without_ext).group(0)
                    file_name_without_ext = re.search(pattern_file_del.lower(), file_name_without_ext.lower()).group(0)
                    if file_name_without_ext:
                        try:
                            #date_time_value_ad = re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(1)
                            date_time_value_del = re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(2))
                            if date_time_value_del <= date_time_value_ad:
                                    del_hdfs_file_names_dict[date_time_value_del] = my_file
                        except AttributeError:
                            continue
                except AttributeError:
                    print("Error")
                    continue
    else:
        print('No Transaction files found in the path, exiting....')
     
    print('del_hdfs_file_names_dict ', del_hdfs_file_names_dict)

    return tn_hdfs_file_names_dict,del_hdfs_file_names_dict

#===============================================================================
# def sorted_lz4_list_files_by_date(dir_files,file_pattern_del,pattern_timestamp_del,pattern_file_ad,pattern_timestamp_ad,file_extension):
#     if dir_files:
#         
#         set_file_names = find_all_files_for_lz4_group(dir_files,file_pattern_del,pattern_timestamp_del,pattern_file_ad,pattern_timestamp_ad,file_extension)
#         print(set_file_names)
#         return set_file_names
# 
#     return []
#===============================================================================

def check_hdfs_path_exists(args_list):
    print('Running hdfs command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    proc.communicate()
    return proc.returncode
