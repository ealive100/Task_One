from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp,col , when, trim
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType, DecimalType,DateType
from datetime import datetime
import sys, os, re
import data_quality_helper_edw as file_helper_edw, data_quality_helper_edw
import file_validation_edw
import table_validation_edw_inc


batch_id_arg = sys.argv[1]
bow_id_arg = sys.argv[2]
load_number_arg = sys.argv[3]
batch_exec_id_arg = sys.argv[4]
sbow_id_arg = sys.argv[5]
file_config = sys.argv[6]
field_validation = sys.argv[7]
exec_server_id = sys.argv[8]
source_type = sys.argv[9]
db_password_arg = sys.argv[10]
abcr_database_type = sys.argv[11]
unicode_arr = db_password_arg.split('@')
secret_pass = [chr(int(x)) for x in unicode_arr]
db_password = ''.join(secret_pass)


print("Arguments are : arg 1 (batch_id) " + batch_id_arg)
print("Arguments are : arg 2 (bow_id) " + bow_id_arg)
print("Arguments are : arg 3 (load_number) " + load_number_arg)
print("Arguments are : arg 4 (batch_exec_id) " + batch_exec_id_arg)
print("Arguments are : arg 5 (sbow_id) " + sbow_id_arg)
print("Arguments are : arg 6 (file_config) " + file_config)
print("Arguments are : arg 7 (field_validation) " + field_validation)
print("Arguments are : arg 8 (execution server id) " + exec_server_id)
print("Arguments are : arg 9 (source_type) " + source_type)
print("Arguments are : arg 10 (db_password_arg) " + "XXXXXXXXX")
print("Arguments are : arg 11 (abcr_database_type) " + abcr_database_type)
print("DQ Started :",datetime.now().strftime('%Y%m%d%H%M%S'))

#aux_control_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("bow_name", StringType(), True), StructField("cdc_start_timestamp", StringType(), True),StructField("cdc_end_timestamp", StringType(), True), StructField("prev_cdc_start_timestamp", TimestampType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),StructField("uow_unique_id", StringType(), True), StructField("cdc_type_description", StringType(), True), StructField("change_data_capture_last_sequence_number", DecimalType(), True),StructField("previous_change_data_capture_last_sequence_number", DecimalType(), True), StructField("insert_gmt_timestamp", StringType(), True), StructField("batch_execution_id", StringType(), True), StructField("batch_id", IntegerType(), True)])
#file_load_hst_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("batch_id", IntegerType(), True), StructField("uow_id", IntegerType(), True), StructField("source_file_path", StringType(), True), StructField("file_name_processed", StringType(), True), StructField("batch_execution_id", StringType(), True), StructField("file_archive_path", StringType(), True),StructField("prev_insert_gmt_ts", StringType(), True),StructField("curnt_insert_gmt_ts", StringType(), True)])
app_name = ''
if field_validation == '2':
    app_name = "File_and_Field_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'
else:
    app_name = "File_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'

spark_session_obj = SparkSession.builder.enableHiveSupport().appName(app_name).getOrCreate()
spark_session_obj.sparkContext.setLogLevel("INFO")
log4jLogger = spark_session_obj.sparkContext._jvm.org.apache.log4j
file_logger = log4jLogger.LogManager.getLogger(__name__)

file_logger.error('THIS IS EDW')
txn_files_for_archival=[]
del_files_for_archival=[]

#===============================================================================
# def ingest_data_into_log_control(spark_session, log_control_record):
#     try:
#         log_control_schema = StructType(
#             [StructField("bow_id", IntegerType(), True), StructField("sbow_id", IntegerType(), True),
#              StructField("uow_id", IntegerType(), True),
#              StructField("load_job_number", StringType(), True), StructField("run_start_timestamp", StringType(), True),
#              StructField("run_end_timestamp", StringType(), True),
#              StructField("cdc_start_timestamp", TimestampType(), True),
#              StructField("cdc_end_timestamp", TimestampType(), True), StructField("status", StringType(), True),
#              StructField("batch_id", StringType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),
#              StructField("prev_cdc_start_timestamp", TimestampType(), True),
#              StructField("source_count", IntegerType(), True), StructField("target_count", IntegerType(), True),
#              StructField("batch_number", IntegerType(), True),
#              StructField("job_name", StringType(), True), StructField("record_delete_count", IntegerType(), True),
#              StructField("insert_gmt_timestamp", StringType(), True)])
#         log_ctrl_table_name = pre_table_name + props['LOG_CONTROL_TABLE']
#         df_log_control_data = file_helper_edw.create_df(spark_session, log_control_record, log_control_schema)
#         
#         df_log_control_data = df_log_control_data.select('bow_id', 'sbow_id', 'uow_id', 'load_job_number',
#                                                          unix_timestamp('run_start_timestamp',
#                                                                         "yyyy-MM-dd HH:mm:ss.SSS").cast(
#                                                              TimestampType()).alias("run_start_timestamp"),
#                                                          unix_timestamp('run_end_timestamp',
#                                                                         "yyyy-MM-dd HH:mm:ss.SSS").cast(
#                                                              TimestampType()).alias("run_end_timestamp"),
#                                                          'cdc_start_timestamp', 'cdc_end_timestamp', 'status', 'batch_id',
#                                                          'prev_cdc_end_timestamp', 'prev_cdc_start_timestamp',
#                                                          'source_count', 'target_count', 'batch_number', 'job_name',
#                                                          'record_delete_count', unix_timestamp('insert_gmt_timestamp',
#                                                                                                "yyyy-MM-dd HH:mm:ss.SSS").cast(
#                 TimestampType()).alias("insert_gmt_timestamp"))
#         print("log_ctrl_table_name" , log_ctrl_table_name)
#         df_log_control_data.write.mode("append").format("text").insertInto(log_ctrl_table_name, overwrite=False)
#     except Exception as e:
#             print("Unable to update the " ,log_ctrl_table_name," with exception message ", e)
#             print("Exiting DQ code...")
#             sys.exit(1)
#===============================================================================

def ingest_data_into_log_control(spark_session, log_control_record , file_config, abcr_db_password, hive_or_sql_server=0):
    try:
        if hive_or_sql_server == 1:
            log_control_schema = StructType(
                [StructField("bow_id", IntegerType(), True), StructField("sbow_id", IntegerType(), True),
                 StructField("uow_id", IntegerType(), True),
                 StructField("load_job_number", StringType(), True), StructField("run_start_timestamp", StringType(), True),
                 StructField("run_end_timestamp", StringType(), True),
                 StructField("cdc_start_timestamp", TimestampType(), True),
                 StructField("cdc_end_timestamp", TimestampType(), True), StructField("status", StringType(), True),
                 StructField("batch_id", StringType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),
                 StructField("prev_cdc_start_timestamp", TimestampType(), True),
                 StructField("source_count", IntegerType(), True), StructField("target_count", IntegerType(), True),
                 StructField("batch_number", IntegerType(), True),
                 StructField("job_name", StringType(), True), StructField("record_delete_count", IntegerType(), True),
                 StructField("insert_gmt_timestamp", StringType(), True)])
            log_ctrl_table_name = pre_table_name + props['LOG_CONTROL_TABLE']
            df_log_control_data = file_helper_edw.create_df(spark_session, log_control_record, log_control_schema)
            
            df_log_control_data = df_log_control_data.select('bow_id', 'sbow_id', 'uow_id', 'load_job_number',
                                                             unix_timestamp('run_start_timestamp',
                                                                            "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                                 TimestampType()).alias("run_start_timestamp"),
                                                             unix_timestamp('run_end_timestamp',
                                                                            "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                                 TimestampType()).alias("run_end_timestamp"),
                                                             'cdc_start_timestamp', 'cdc_end_timestamp', 'status', 'batch_id',
                                                             'prev_cdc_end_timestamp', 'prev_cdc_start_timestamp',
                                                             'source_count', 'target_count', 'batch_number', 'job_name',
                                                             'record_delete_count', unix_timestamp('insert_gmt_timestamp',
                                                                                                   "yyyy-MM-dd HH:mm:ss.SSS").cast(
                    TimestampType()).alias("insert_gmt_timestamp"))
            print("log_ctrl_table_name" , log_ctrl_table_name)
            df_log_control_data.write.mode("append").format("text").insertInto(log_ctrl_table_name, overwrite=False)
        else:
            log_control_record = [tuple(row) for row in log_control_record]
            insert_query = file_config['INSERT_QUERY_LOG_CONTROL_R01']
            file_helper_edw.insert_data_into_abcr_db(file_config, insert_query, log_control_record, abcr_db_password)

    except Exception as e:
            print("Unable to insert data into the " ,log_ctrl_table_name," with exception message ", e)
            print("Exiting DQ code...")
            sys.exit(1)

def update_data_into_aux_control(spark_session, default_db, aux_control_record, file_config, abcr_db_password, hive_or_sql_server=0):
    try:
        print("update_data_into_aux_control",aux_control_record)
        if hive_or_sql_server == 1:
            aux_control_schema = StructType(
                [StructField("bow_id", IntegerType(), True), StructField("bow_name", StringType(), True),
                 StructField("cdc_start_timestamp", StringType(), True), StructField("cdc_end_timestamp", StringType(), True),
                 StructField("prev_cdc_start_timestamp", TimestampType(), True),
                 StructField("prev_cdc_end_timestamp", TimestampType(), True), StructField("uow_unique_id", StringType(), True),
                 StructField("cdc_type_description", StringType(), True),
                 StructField("change_data_capture_last_sequence_number", DecimalType(), True),
                 StructField("previous_change_data_capture_last_sequence_number", DecimalType(), True),
                 StructField("insert_gmt_timestamp", StringType(), True), StructField("batch_execution_id", StringType(), True),
                 StructField("batch_id", IntegerType(), True)])
            aux_ctrl_df = file_helper_edw.create_df(spark_session, aux_control_record, aux_control_schema)
    
            aux_ctrl_table_name = default_db + file_config['AUX_CONTROL_TABLE']
            aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name',
                                             unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                 TimestampType()).alias("cdc_start_timestamp"),
                                             unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                 TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp',
                                             'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description',
                                             'change_data_capture_last_sequence_number',
                                             'previous_change_data_capture_last_sequence_number',
                                             unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                 TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id',
                                             'batch_id')
            aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
        else:
           
            aux_control_record = [(row[2], row[3], row[6]) for row in aux_control_record]
            print("aux_control_record",aux_control_record)
            update_query = file_config['UPDATE_QUERY_AUX_CONTROL_R01']
            file_helper_edw.insert_data_into_abcr_db(file_config, update_query, aux_control_record, abcr_db_password)
    except Exception as e:
            print("Unable to update the " ,aux_ctrl_table_name," with exception message ", e)
            print("Exiting DQ code...")
            sys.exit(1)

def ingest_data_into_file_load_hist_table_im(spark_session, file_load_record , file_config, abcr_db_password, hive_or_sql_server=0):
    try:
        if hive_or_sql_server == 1:
            print("ingest_data_into_file_load_hist_table_im", hive_or_sql_server)
            file_load_hist_schema = StructType([StructField("bow_id", IntegerType(), True), 
                        StructField("batch_id", IntegerType(), True), 
                        StructField("uow_id", IntegerType(), True), 
                        StructField("source_file_path", StringType(), True), 
                        StructField("file_name_processed", StringType(), True), 
                        StructField("batch_execution_id", StringType(), True), 
                        StructField("file_archive_path", StringType(), True),
                        StructField("prev_insert_gmt_ts", StringType(), True),
                        StructField("curnt_insert_gmt_ts", StringType(), True)])
            
           
            file_load_hist_table_name =  pre_table_name + props['FILE_LOAD_HST_EDW_TABLE_INC']
           
                
            df_file_load_hist_data = file_helper_edw.create_df(spark_session, file_load_record, file_load_hist_schema)
            
            df_file_load_hist_data = df_file_load_hist_data.select('bow_id', 'batch_id', 'uow_id', 'source_file_path',
                                                             'file_name_processed','batch_execution_id',
                                                             'file_archive_path','prev_insert_gmt_ts', 'curnt_insert_gmt_ts')
            print("file_load_hist_table_name" , file_load_hist_table_name)
            df_file_load_hist_data.write.mode("append").format("text").insertInto(file_load_hist_table_name, overwrite=False)
        else:
            print("ingest_data_into_file_load_hist_table_hm", hive_or_sql_server)
            file_load_record = [tuple(row) for row in file_load_record]
            
            insert_query = file_config['INSERT_FILE_LOAD_HST_EDW_HIST_INC']
                
            file_helper_edw.insert_data_into_abcr_db(file_config, insert_query, file_load_record, abcr_db_password)

    except Exception as e:
            print("Unable to insert data with query " ,insert_query," with exception message ", e)
            print("Exiting DQ code...")
            sys.exit(1)            

def read_data_file(spark_session, data_file, schema, parameter_obj):
    def blank_as_null(x):
        return when(trim(col(x)) != "", col(x)).otherwise(None)
    print("Inside read_data_file", data_file)
    set_header = "false"
    if parameter_obj.is_header_included.lower() == 'y':
        set_header = "true"

    try:
        chr(int(parameter_obj.delimiter))
    except ValueError:
        file_logger.error('Invalid column separator.' + parameter_obj.delimiter)

    file_ext = parameter_obj.extension
    file_logger.info('DATA file is of type ' + file_ext)

    
    if file_ext.lower() == props['LZ4'].lower():
        try:
            file_data_df = spark_session.createDataFrame(spark_session.sparkContext.textFile(data_file).map(lambda x: x.split(chr(int(parameter_obj.delimiter))))).toDF(*schema)
            #file_data_df = spark_session.read.option("header", set_header).option("treatEmptyValuesAsNulls", "true").option("delimiter", chr(int(parameter_obj.delimiter))).csv(data_file).toDF(*schema)
        except Exception as e:
            print("Unable to read file with format " ,file_ext, " hence exiting DQ with exception ", e)
            sys.exit(1)
        exprs = [blank_as_null(x).alias(x) for x in file_data_df.columns]
        file_data_df = file_data_df.select(*exprs)
        return file_data_df

    else:
        file_logger.info('DATA file type of ' + file_ext + ' not defined. So exiting the process.')
        sys.exit(1)

def execute_spark(spark_session, source_table_name, doPreProcess, load_number, props, parameter_object,files_dict_tn,files_dict_del,exec_edw_group_lst):
    print("Inside execute_spark for lz4")
    
    
    if not source_table_name:
        file_logger.info('The target hive table is not defined, so exiting the process.')
        sys.exit(1)
    #col_name = props['TS_COLUMN_NAME']
    user = props['USER']
    keytab = props['KEYTAB']
    
    
    #===========================================================================
    # df_tn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    # df_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    # full_dataframe_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    # full_dataframe_txn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
    #===========================================================================
    
    file_hist_load_txn_list = []
    file_hist_load_del_list = []
    if doPreProcess == 'true':
        #source_system_id = parameter_object.source_system_identifier
        query = "desc " + source_table_name
        col_list, data_type_list, nullable_list = file_helper_edw.read_schema_from_hive(props['REGEX_DESCRIBE'], query, props['JDBC_URL_BEELINE'])
        file_logger.info('Schema from hive')
        file_logger.info(col_list)

        txn_table_cols = col_list[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):]
        if "extrc_eff_ts" in txn_table_cols: txn_table_cols.remove("extrc_eff_ts")
        
        #dict_col = {"string":"StringType()", "bigint":"IntegerType()","timestamp":"TimestampType()","smallint":"IntegerType()","decimal":"DecimalType()","int":"IntegerType()","date":"DateType()","varchar":"StringType()"}
 
 
        del_columns = parameter_object.del_columns
        print(" del_col_list "+del_columns+" ")
        
        del_col_list  = list(del_columns.split(","));
        print(del_col_list)

#===============================================================================
# Del file date is less than Trans file of same pattern  => del to be processed first then trans file
# Del file date > Trans file => only trans file to be processed
# Only Del file exists  => no file to be processed
# Only Trans file exists  => Trans file to be processed
# Del file and Trans file are of different sources   => only trans file to be processed
# Del file  with date 1st march, Trans files with 1st and 2nd march   => Del file to be process first and  Trans files to be processed together.
#===============================================================================

        for exec_edw_group in exec_edw_group_lst:
            print("The files to be processed oldest 1st ",exec_edw_group)
            df_tn = ''
            df_tn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
            
            df_del = ''
            df_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
            
            full_dataframe_del = ''
            full_dataframe_del = spark_session.sql(" select * from " + source_table_name + " where 1=0")
            
            full_dataframe_txn = ''
            full_dataframe_txn = spark_session.sql(" select * from " + source_table_name + " where 1=0")
#=======================================================================
# DEL files will be processed here 
#=======================================================================
            if len(files_dict_del)>0 and exec_edw_group in files_dict_del.keys():
                print("files_dict_del ", files_dict_del)
                #file_logger.info('files_list_del'+files_list_del)
                
                #for source_del_file_list in files_list_del:
                source_del_file_list = files_dict_del.get(exec_edw_group)
                global del_files_for_archival 
                del_files_for_archival = source_del_file_list
                print("del_files_for_archival",del_files_for_archival)
                print("source_del_file_list" ,source_del_file_list)
                uow_id_del = int(param_obj.del_uow_id)
                start_date_del = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                log_control_data = [[int(bow_id_arg), int(sbow_id_arg), uow_id_del, load_number_arg, start_date_del, start_date_del, None, None, 'R', batch_exec_id_arg, None, None, 0, 0, int(batch_id_arg), param_obj.job_name, 0, start_date_del]]
                #ingest_data_into_log_control(spark_session_obj, log_control_data)
                ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                #for source_del_file in source_del_file_list:
                ctl_file_del = [file for file in source_del_file_list if "DAT.ctl" in file]
                print("ctl_file_del",ctl_file_del[0])
                file_helper_edw.service_accnt_login(user,keytab)
                #print("Processing DEL file",source_del_file)
                if ctl_file_del:
                    print("Encountered DEL CTL file... reading count", ctl_file_del[0])
                    record_count = file_helper_edw.read_ctrl_file_edw(ctl_file_del[0])
                    print("record_count",record_count)
                    source_del_file_list.remove(ctl_file_del[0])
                    #continue
                print("source_del_file_list after removing ctl file" , source_tn_file_list)
                source_del_file = ",".join(source_del_file_list)
                print("source_del_file",source_del_file)
                df_del = read_data_file(spark_session, source_del_file, del_col_list, parameter_object)
                #df_del.show(1,False)
                df_del_count = df_del.count()
                file_logger.info('The df_count source_del_file is ' + str(df_del_count))
                del_cond = del_col_list;
                print("condition", del_cond)
                print("Actual Schema")
                file_logger.info('The condition is  ' + str(del_cond))
                full_dataframe_del.printSchema()
                print("DEL file Schema")
                df_del.printSchema()
                df_del_final = full_dataframe_del.join(df_del,del_cond,"outer")
                df_cols = [col(x) for x in col_list]
                full_dataframe_del = full_dataframe_del.union(df_del_final.select(df_cols))
                print("After join and union the full dataframe Schema is ")
                full_dataframe_del.printSchema()
                file_name = os.path.split(source_del_file_list[0])[-1]
                index_of_extension = file_name.lower().index(param_obj.extension.lower())
                file_name_without_ext = file_name[0:index_of_extension-1]
                print(file_name[0:index_of_extension-1])
            
                file_load_hist_del =  file_helper_edw.prepare_for_file_load_hist(file_name_without_ext,param_obj.source_file_path)
                file_load_hist_del_basename = file_helper_edw.find_basename_from_path_url(file_load_hist_del)
                #check_file_load_query_del = file_load_Sql + "=" + "'" + file_load_hist_del_basename +"'"
                #check_file_load_hist(file_config,desc_query, jdbc_url,db_password, hive_or_sql_server=0):
                is_file_processed = file_helper_edw.check_file_load_hist(props,file_load_hist_del_basename,jdbc_url_beeline,db_password, abcr_database_type)
                if is_file_processed:
                    print("File already processed , Exiting....", file_load_hist_del_basename)
                    #break
                    sys.exit(1)
                file_hist_load_del_list.append(file_load_hist_del_basename)
                print("file_hist_load_del_list",file_hist_load_del_list)
                #date_time_value_del = re.search(param_obj.del_timestamp_pattern.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(param_obj.del_timestamp_pattern.lower(), file_name_without_ext.lower()).group(2))
                #print('The DEL file name to be processed by spark ' + file_name + ' having datetime value as ' + exec_edw_group)
                #file_logger.info('The DEL file name to be processed by spark ' + file_name + ' having datetime value as ')
                #max_date_del_list.append(int(date_time_value_del));
                insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                spark_session.sql("SET hive.exec.dynamic.partition = true")
                spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
                print("before")
                
                #full_dataframe_del.printSchema()
                if parameter_object.source_system_identifier.lower() == 'n':
                    source_sys_del = parameter_object.source_system_identifier_value
                    df_del_insert = full_dataframe_del.withColumn('source_system_identifier', lit(full_dataframe_del[source_sys_del])).withColumn('logical_deletion_indicator',lit('D')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts));
                else:
                    source_sys_del = int(parameter_object.source_system_identifier_value)
                    df_del_insert = full_dataframe_del.withColumn('source_system_identifier', lit(source_sys_del)).withColumn('logical_deletion_indicator',lit('D')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts));
                print("before")
                df_del_insert.printSchema()
                df_cols = [col(x) for x in col_list]
                df_total_del_count = df_del_insert.count();
                if parameter_object.is_control_file.lower() == 'y' and "DEL".lower() in ctl_file_del[0].lower():
                    ctl_bool = file_helper_edw.validate_ctl_count_edw(df_total_del_count,record_count)
                    if ctl_bool:
                        print("CTL file for DEL validation is successful")
                    else:
                        print("CTL file for DEL validation is Failure..Exiting")
                        #sys.exit(1)
                        file_helper_edw.archive_hdfs_files(del_files_for_archival,param_obj.hdfs_reject_path)
                        sys.exit(1)
                        #break
                else:
                    print("Bypass DEL CTL check")
                #flhe_table =  pre_table_name + file_load_hst_ewd 
                prev_timestamp = data_quality_helper_edw.get_prev_timestamp(props,jdbc_url_beeline,parameter_object.bow_id,parameter_object.batch_id,parameter_object.uow_id,db_password, abcr_database_type)
                print("prev_timestamp",prev_timestamp)
                try:
                    df_del_insert.select(df_cols).write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)
                except Exception as e:
                    print("Unable to insert data in table", source_table_name, " with exception message ", e)
                    print("Exiting DQ code...")
                    sys.exit(1)
                print("After insert")
                max_date_del = exec_edw_group
                print("This is the max date of the del file",exec_edw_group)
                if max_date_del:
                    new_time_value = datetime.strptime(str(max_date_del), param_obj.timestamp_format).strftime('%Y-%m-%d %H:%M:%S')
                    aux_control_data = [[int(bow_id_arg), None, new_time_value, new_time_value, None, None, param_obj.del_uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id_arg, int(batch_id_arg)]]
                    #aux_ctrl_df = file_helper_edw.create_df(spark_session_obj, aux_control_data, aux_control_schema)
            
                    #aux_ctrl_table_name = pre_table_name + props['AUX_CONTROL_TABLE']
                    #aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name', unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_start_timestamp"), unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp', 'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description', 'change_data_capture_last_sequence_number', 'previous_change_data_capture_last_sequence_number', unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id', 'batch_id')
                    #aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
                    update_data_into_aux_control(spark_session_obj, pre_table_name, aux_control_data, props, db_password, abcr_database_type)
                    if field_validation == '2':
                        src_count, targt_count, curr_timestamp = table_validation_edw_inc.validate_parameter_obj_edw(spark_session_obj, props, param_obj, file_logger,str(prev_timestamp))
                        #src_count, targt_count = table_validation_edw_hist.validate_parameter_obj_edw(spark_session_obj, props, param_obj, file_logger,partition_col)
                        
                        end_date_del = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                        log_control_data = [[int(bow_id_arg), int(sbow_id_arg), int(uow_id_del), load_number_arg, start_date_del, end_date_del, None, None, 'S', batch_exec_id_arg, None, None, src_count, targt_count, int(batch_id_arg), param_obj.job_name, 0, end_date_del]]
                        #ingest_data_into_log_control(spark_session_obj, log_control_data)
                        ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                        file_load_hst_data = file_helper_edw.create_file_load_hst_data_edw(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path,file_hist_load_del_list,batch_exec_id_arg, param_obj.archive_file_path,str(prev_timestamp),str(curr_timestamp),abcr_database_type)
                        print("file_load_hst_data" , file_load_hst_data)
                        #file_load_hst_df = file_helper_edw.create_df(spark_session_obj, file_load_hst_data, file_load_hst_schema)
                        #file_load_hst_df.write.mode("append").format("text").insertInto(flhe_table, overwrite=False)
                        ingest_data_into_file_load_hist_table_im(spark_session_obj, file_load_hst_data, props, db_password, abcr_database_type)
                        #file_helper.clean_hdfs_working_path(param_obj.source_file_path)
            else:
                print("IS_DEL_FILE is set to N, hence not processing DEL")
                
          
#======================================================================
# Transaction files will be processed here 
#======================================================================
            if len(files_dict_tn)>0 and exec_edw_group in files_dict_tn.keys():
                print("files_list_tn ", files_dict_tn)
                
                print('txn_table_cols without preappended cols ' , txn_table_cols)
                #for source_tn_file_list in files_dict_tn:
                uow_id_txn = int(param_obj.uow_id)
                start_date_txn = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                log_control_data = [[int(bow_id_arg), int(sbow_id_arg), int(uow_id_txn), load_number_arg, start_date_txn, start_date_txn, None, None, 'R', batch_exec_id_arg, None, None, 0, 0, int(batch_id_arg), param_obj.job_name, 0, start_date_txn]]
                #ingest_data_into_log_control(spark_session_obj, log_control_data)
                ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                source_tn_file_list = files_dict_tn.get(exec_edw_group)
                global txn_files_for_archival 
                txn_files_for_archival = source_tn_file_list
                print("txn_files_for_archival",txn_files_for_archival)
                #for source_tn_file in source_tn_file_list:
                ctl_file_txn = [file for file in source_tn_file_list if "DAT.ctl" in file]
                file_helper_edw.service_accnt_login(user,keytab)
                #print("Processing TXN file ", source_tn_file)
                if ctl_file_txn:
                    print("Encountered CTL file... reading count",ctl_file_txn[0])
                    record_count = file_helper_edw.read_ctrl_file_edw(ctl_file_txn[0])
                    #print("record_count",record_count)
                    #continue
                    source_tn_file_list.remove(ctl_file_txn[0])
                #print("source_tn_file",source_tn_file)
                print("source_tn_file_list after removing ctl file" , source_tn_file_list)
                source_tn_file = ",".join(source_tn_file_list)
                print("source_tn_file",source_tn_file)
                df_tn = read_data_file(spark_session, source_tn_file, txn_table_cols, parameter_object)
                df_tn_count = df_tn.count()
                file_logger.info('The df_count source_tn_file is ' + str(df_tn_count))
                insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                print("source_system_identifier is ",parameter_object.source_system_identifier)
                if parameter_object.source_system_identifier.lower() == 'n':
                    print("source_system_identifier is ",parameter_object.source_system_identifier)
                    source_sys_txn = parameter_object.source_system_identifier_value
                    print("source_sys_txn",source_sys_txn)
                    df_tn = df_tn.withColumn("extrc_eff_ts",lit(None)).withColumn('source_system_identifier',lit(df_tn[source_sys_txn])).withColumn('logical_deletion_indicator',lit('U')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts))
                else:
                    print("source_system_identifier is ",parameter_object.source_system_identifier)
                    source_sys_txn = int(parameter_object.source_system_identifier_value)
                    print("source_sys_txn",source_sys_txn)
                    df_tn = df_tn.withColumn("extrc_eff_ts",lit(None)).withColumn('source_system_identifier',lit(source_sys_txn)).withColumn('logical_deletion_indicator',lit('U')).withColumn('insert_gmt_timestamp',lit(insert_ts)).withColumn('load_job_number',lit(load_number)).withColumn('source_system_extract_gmt_timestamp',lit(insert_ts)).withColumn('source_system_updated_timestamp',lit(insert_ts))
                df_cols = [col(x) for x in col_list]
                full_dataframe_txn = full_dataframe_txn.union(df_tn.select(df_cols))
                print("source_tn_file_list[0]",source_tn_file_list[0])
                file_name = os.path.split(source_tn_file_list[0])[-1]
                print("file_name",file_name)
                index_of_extension = file_name.lower().index(param_obj.extension.lower())
                print("index_of_extension",index_of_extension)
                file_name_without_ext = file_name[0:index_of_extension-1]
                print("file_name_without_ext",file_name_without_ext,file_name[0:index_of_extension-1])
                file_load_hist_txn =  file_helper_edw.prepare_for_file_load_hist(file_name_without_ext,param_obj.source_file_path)
                file_load_hist_txn_basename = file_helper_edw.find_basename_from_path_url(file_load_hist_txn)
                #check_file_load_query_txn = file_load_Sql + "=" + "'" + file_load_hist_txn_basename +"'"
                is_file_processed = file_helper_edw.check_file_load_hist(props,file_load_hist_txn_basename,jdbc_url_beeline,db_password, abcr_database_type)
                #is_file_processed = file_helper_edw.check_file_load_hist(check_file_load_query_txn,jdbc_url_beeline)
                if is_file_processed:
                    print("File already processed...exiting... ", file_load_hist_txn_basename)
                    sys.exit(1)
                    #break
                file_hist_load_txn_list.append(file_load_hist_txn_basename)
                print("file_hist_load_txn_list",file_hist_load_txn_list)
                #date_time_value_txn = re.search(param_obj.ad_timestamp_pattern.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(param_obj.ad_timestamp_pattern.lower(), file_name_without_ext.lower()).group(2))
                #max_date_txn_list.append(int(date_time_value_txn));
                #print('The Txn file name to be processed by spark ' + file_name + ' having datetime value as ' + exec_edw_group)
                spark_session.sql("SET hive.exec.dynamic.partition = true")
                spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
                print("parameter_object.is_control_file" ,parameter_object.is_control_file)
                if parameter_object.is_control_file.lower() == 'y' and "DEL".lower() not in ctl_file_txn[0].lower():
                    ctl_bool = file_helper_edw.validate_ctl_count_edw(full_dataframe_txn,record_count)
                    if ctl_bool:
                        print("CTL file for TXN validation is success")
                    else:
                        print("CTL file for TXN validation is failure...Moving all the files to ",param_obj.hdfs_reject_path)
                        file_helper_edw.archive_hdfs_files(txn_files_for_archival,param_obj.hdfs_reject_path)
                        sys.exit(1)
                        #break
                else:
                    print("Bypass TXN CTL check")
               
                #flhe_table =  pre_table_name + file_load_hst_ewd 
                prev_timestamp = data_quality_helper_edw.get_prev_timestamp(props,jdbc_url_beeline,parameter_object.bow_id,parameter_object.batch_id,parameter_object.uow_id,db_password, abcr_database_type)
                print("prev_timestamp",prev_timestamp)
                
                try:
                    full_dataframe_txn.write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)
                except Exception as e:
                    print("Unable to insert data in table", source_table_name, " with exception message ", e)
                    print("Exiting DQ code...")
                    sys.exit(1)
                max_date_txn = exec_edw_group
                print("This is the max date of the txn file",max_date_txn)
                if max_date_txn:
                    new_time_value = datetime.strptime(str(max_date_txn), param_obj.timestamp_format).strftime('%Y-%m-%d %H:%M:%S')
                    aux_control_data = [[int(bow_id_arg), None, new_time_value, new_time_value, None, None, param_obj.uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id_arg, int(batch_id_arg)]]
                    #aux_ctrl_df = file_helper_edw.create_df(spark_session_obj, aux_control_data, aux_control_schema)
         
                    #aux_ctrl_table_name = pre_table_name + props['AUX_CONTROL_TABLE']
                    #aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name', unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_start_timestamp"), unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp', 'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description', 'change_data_capture_last_sequence_number', 'previous_change_data_capture_last_sequence_number', unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS") .cast(TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id', 'batch_id')
                    #aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
                    update_data_into_aux_control(spark_session_obj, pre_table_name, aux_control_data, props, db_password, abcr_database_type)
                    if field_validation == '2':
                        #curr_timestamp = table_validation_edw_inc.validate_parameter_obj_edw(spark_session_obj, batch_id_arg, bow_id_arg, load_number_arg, batch_exec_id_arg, sbow_id_arg, props, param_obj, file_logger,dType,str(prev_timestamp))
                        src_count, targt_count, curr_timestamp = table_validation_edw_inc.validate_parameter_obj_edw(spark_session_obj, props, param_obj, file_logger,str(prev_timestamp))
                        #src_count, targt_count = table_validation_edw_hist.validate_parameter_obj_edw(spark_session_obj, props, param_obj, file_logger,partition_col)
                        
                        end_date_txn = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                        log_control_data = [[int(bow_id_arg), int(sbow_id_arg), int(uow_id_txn), load_number_arg, start_date_txn, end_date_txn, None, None, 'S', batch_exec_id_arg, None, None, src_count, targt_count, int(batch_id_arg), param_obj.job_name, 0, end_date_txn]]
                        #ingest_data_into_log_control(spark_session_obj, log_control_data)
                        ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                        if prev_timestamp == 'NULL':
                            prev_timestamp = curr_timestamp
                        file_load_hst_data = file_helper_edw.create_file_load_hst_data_edw(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path,file_hist_load_txn_list,batch_exec_id_arg, param_obj.archive_file_path,str(prev_timestamp),str(curr_timestamp))
                        print("file_load_hst_data" , file_load_hst_data)
                        ingest_data_into_file_load_hist_table_im(spark_session_obj, file_load_hst_data, props, db_password, abcr_database_type)
                        #file_load_hst_df = file_helper_edw.create_df(spark_session_obj, file_load_hst_data, file_load_hst_schema)
                        #file_load_hst_df.write.mode("append").format("text").insertInto(flhe_table, overwrite=False)
                        #file_helper.clean_hdfs_working_path(param_obj.source_file_path)
               
    
            
        

props = file_helper_edw.read_all_properties(file_config)
pre_table_name = props['DATABASE_NAME']
do_pre_process = props['DO_PREPROCESS']
edw_ctrl_format = props['EDW_CTRL_FORMAT']
jdbc_url_beeline = props['JDBC_URL_BEELINE']
#file_load_hst_ewd = props['FILE_LOAD_HST_EDW_TABLE_INC']
#file_load_Sql = props['FILE_LOAD_HST_EDW_TABLE_INC_SQL']
lfs_log = ''
landing_path = ''
hdfs_log = ''

if source_type.lower() == 'edw':
    all_parameter_obj = file_helper_edw.load_file_control_ingestion_for_EDW(props, batch_id_arg, bow_id_arg, exec_server_id, db_password, abcr_database_type)
    #file_load_hst_ewd_inc = props['FILE_LOAD_HST_EDW_TABLE_INC']
    #print("file_load_hst_ewd_inc",file_load_hst_ewd_inc)

if len(all_parameter_obj)>0:
    for param_obj in all_parameter_obj:
        #if param_obj.extension.lower() in ['lz4']:
            print("This is an lz4 file")
            #hdfs_cmd = ['hdfs', 'dfs', '-test', '-d', param_obj.source_file_path+";echo $?"]
            hdfs_cmd = ['hdfs', 'dfs', '-test', '-d', param_obj.source_file_path]
            hdfs_path_exists= file_helper_edw.execute_hdfs_cmd(hdfs_cmd);
            print("hdfs_path_exists", hdfs_path_exists)
            if hdfs_path_exists==0:
                print("hdfs_path_exists",hdfs_path_exists)
                pre_table_name_edw = param_obj.hive_schema_name
                print("Database Name:",pre_table_name_edw)
                source_table = param_obj.lz_table_name
                print("Table Name:",source_table)
                lfs_log = param_obj.lfs_log_path
                hdfs_log = param_obj.hdfs_log_path
                if not source_table.startswith(pre_table_name_edw):
                    source_table = pre_table_name_edw + '.' + source_table
                    print("Source Table name: " , source_table)
                    tn_files_dict , del_files_dict , exec_edw_group_lst = file_validation_edw.validate_edw_files(param_obj, props, file_logger,edw_ctrl_format)
                    print("tn_files_dict",tn_files_dict)
                    print("del_files_dict",del_files_dict)
                    if len(tn_files_dict)>0:
                        #tn_files_list = tn_files_dict.values()
                        #del_files_list = del_files_dict.values()
                        #all_data_files_list = list(all_data_files_dict.keys())
                        execute_spark(spark_session_obj, source_table, do_pre_process, load_number_arg, props, param_obj,tn_files_dict,del_files_dict ,exec_edw_group_lst)
                    else:
                        print("No txn files present in this Path, hence nothing to process, breaking...")
                        #sys.exit(1);
                        break
            else:
                print("Not a valid HDFS path for lz4....Exiting DQ...")
                sys.exit(1)
    
    print("Initiating archiving process for TXN files ", param_obj.source_file_path," to ", param_obj.archive_file_path)
    file_helper_edw.archive_hdfs_files(txn_files_for_archival,param_obj.archive_file_path)
    print("Initiating archiving process for DEL files ", param_obj.del_source_file_path," to ", param_obj.archive_file_path)
    file_helper_edw.archive_hdfs_files(del_files_for_archival,param_obj.archive_file_path)
else:
    print("No record found in Control Ingestion table, Hence exiting...")
    sys.exit(1)
app_id = spark_session_obj.sparkContext.applicationId
spark_session_obj.stop()

log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
log_file_name = lfs_log.rstrip('/') + '/dq1_ingestion_batch_id_' + str(batch_id_arg) + '_bow_id_' + str(bow_id_arg) + '_' + log_time_value + '.log'
file_logger.info("(log_file_name) " + log_file_name)
file_helper_edw.generate_log(file_logger, log_file_name, app_id, 'dummy')
file_helper_edw.copy_log_files(lfs_log, hdfs_log)
print("DQ ended :",datetime.now().strftime('%Y%m%d%H%M%S'))
