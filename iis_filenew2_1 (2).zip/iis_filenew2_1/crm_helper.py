import crm_config as config
from pyspark.sql.types import StructField, StructType, StringType
from pyspark.sql.functions import lit, col, concat, hash
from pyspark.sql import Window
import pyspark.sql.functions as f

import subprocess, re


def create_filter(column_list, regex_pattern, total_filter_list):

    filter_list = [column + " != '' and " + column + " rlike '" + regex_pattern + "'" for column in column_list]

    if filter_list:
        total_filter_list = total_filter_list + filter_list

    return total_filter_list


def check_data_type(table_name, object_name, column_names_with_data_type, logger):
    error_records = object_name.filter("1=0")

    total_count = 0

    columns_date_list = []
    columns_int_list = []
    columns_timestamp_list = []
    columns_smallint_list = []
    columns_decimal_list = []
    columns_datetime_list = []
    columns_bit_list = []
    columns_bigint_list = []

    for column, data_type in column_names_with_data_type:
        if data_type == config.INT:
            columns_int_list.append(column)
        elif data_type == config.DATE:
            columns_date_list.append(column)
        elif data_type == config.TIMESTAMP:
            columns_timestamp_list.append(column)
        elif data_type == config.SMALLINT:
            columns_smallint_list.append(column)
        elif data_type == config.DECIMAL:
            columns_decimal_list.append(column)
        elif data_type == config.DATETIME:
            columns_datetime_list.append(column)
        elif data_type == config.BIT:
            columns_bit_list.append(column)
        elif data_type == config.BIGINT:
            columns_bigint_list.append(column)

    total_filter_list = []
    total_filter_list = create_filter(columns_int_list, config.REGEX_INT, total_filter_list)
    total_filter_list = create_filter(columns_date_list, config.REGEX_DATE, total_filter_list)
    total_filter_list = create_filter(columns_timestamp_list, config.REGEX_TIMESTAMP, total_filter_list)
    total_filter_list = create_filter(columns_smallint_list, config.REGEX_SMALLINT, total_filter_list)
    total_filter_list = create_filter(columns_decimal_list, config.REGEX_DECIMAL, total_filter_list)
    total_filter_list = create_filter(columns_datetime_list, config.REGEX_DATETIME, total_filter_list)
    total_filter_list = create_filter(columns_bit_list, config.REGEX_BIT, total_filter_list)
    total_filter_list = create_filter(columns_bigint_list, config.REGEX_BIGINT, total_filter_list)

    filter_str = ' or '.join(total_filter_list)

    if filter_str != '':
        logger.debug(filter_str)
        error_records = object_name.filter(filter_str)
        total_count = error_records.count()
        if total_count > 0:
            logger.debug("There are failed records in table [" + table_name + "] due to data type check for column, Record Count=" + str(total_count))
            error_records = error_records.drop_duplicates()
        return error_records, total_count
    return error_records, total_count


def check_null_values(table_name, object_name, column_names, column_null_options, logger):
    error_records = object_name.filter("1=0")
    total_count = 0
    nullable_col_list = []
    for column, nullable in zip(column_names, column_null_options):
        if nullable.lower() == 'no':
            nullable_col_list.append(column)
    if len(nullable_col_list) > 0:
        filter_condition_list = ["(" + column + " is null) or (trim(" + column + ") = '')" for column in nullable_col_list]
        filter_condition = ' or '.join(filter_condition_list)
        error_records = object_name.filter(filter_condition)

        total_count = error_records.count()
        if total_count > 0:
            logger.debug("There are failed records in table [" + table_name + "] due to null check for column, Record Count=" + str(total_count))
            error_records = error_records.drop_duplicates()
    return error_records, total_count


def read_all_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.toDF(*schema)


def read_distinct_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select distinct * from " + table_name)

    return table_schema_df.toDF(*schema)


def read_duplicate_rows_from_hive(full_df, schema):
    hash_full_df = full_df.withColumn("_hash", hash(*schema))
    hash_full_df_window = hash_full_df.withColumn("_duplicate", f.count("*").over(Window.partitionBy("_hash")))
    duplicate_df = hash_full_df_window.filter("_duplicate > 1")
    # duplicate_df.show(20, truncate = False)
    return duplicate_df.withColumn(config.COMMENTS_COLUMN, concat(lit("There are failed records due to primary key check, Record Count="), col('_duplicate'))).drop("_hash").drop("_duplicate")


def read_schema_from_hive(regex_desc, desc_query):
    # print(desc_query)
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://g4t2953.houston.hpicorp.net:2181,g4t2954.houston.hpicorp.net:2181,g4t2955.houston.hpicorp.net:2181,g4t2956.houston.hpicorp.net:2181,g4t2957.houston.hpicorp.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", desc_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    stdout, stderr = p.communicate()
    p.wait()
    lines = stdout.splitlines()
    col_names = []
    data_types = []
    nullable = []
    for line in lines:
        cols = re.findall(regex_desc, line.replace('|', ''))
        if len(cols) == 10:
            col_names.append(cols[0])
            data_types.append(cols[1])
            nullable.append(cols[3])
    return col_names, data_types, nullable


def validate_table_data(spark, table_name, logger):

#    table_schema_df = read_schema_from_file(spark, schema_table, schema_file)
#    if table_schema_df.count() == 0:
#        logger.error(table_name + '  schema information not available for file ' + table_name)
#        return
    # table_data = table_schema_df.collect()
    desc_query = 'desc ' + table_name
    regex_desc = config.REGEX_DESCRIBE
    column_names,data_types,column_null_options = read_schema_from_hive(regex_desc, desc_query)
    logger.debug("column_names" + ','.join(column_names))
    # column_names = [i.replace('__$', '').strip() for i in column_names_tmp]
    # column_names = [str(i.ColumnName).replace('__$', '').strip() for i in table_data]
    # data_types = [str(i.Type).strip() for i in table_data]
    # column_null_options = [str(i.Nullable).strip() for i in table_data]
    column_names_with_data_type = zip(column_names, data_types)
    full_data_df = read_all_rows_from_hive(spark, table_name, column_names)
    #is_dq_required = False
    is_dq_required = True
    good_records_df = full_data_df
    error_records = full_data_df.filter("1=0")
    count_reject_records = 0
    if is_dq_required:
        distinct_records_df = read_distinct_rows_from_hive(spark, table_name, column_names)
        distinct_records_df.cache()
        # column_names_with_data_type = full_data_df.dtypes
        # column_names = [col[0] for col in column_names_with_data_type]
        # column_null_options = [f.nullable for f in full_data_df.schema.fields]
        total_count = full_data_df.count()
        distinct_count = distinct_records_df.count()
        duplicate_df = full_data_df.filter("1=0")
        count_duplicate = total_count - distinct_count
        if count_duplicate > 0:
            # duplicate_df = spark.sql("select *, count(*) as _count from " + table_name + " group by " + ','.join(column_names) + ' having _count > 1').withColumn(config.COMMENTS_COLUMN, concat(lit("There are failed records due to primary key check, Record Count="), col('_count'))).drop('_count')
            duplicate_df = read_duplicate_rows_from_hive(full_data_df, column_names)
        else:
            duplicate_df = duplicate_df.withColumn(config.COMMENTS_COLUMN, lit(''))

        logger.debug('Total number of records in ' + table_name + ' data file are ' + str(total_count))
        logger.debug('Total number of duplicate records in ' + table_name + ' data file are ' + str(duplicate_df.count()))

        bad_records_data_type_check_df, bad_record_data_type_constraint_count = check_data_type(table_name, distinct_records_df, column_names_with_data_type, logger)
        logger.debug('Number of bad records due to data type check constraint ' + str(bad_record_data_type_constraint_count))

        if bad_record_data_type_constraint_count > 0:
            bad_records_data_type_check_df = bad_records_data_type_check_df.withColumn(config.COMMENTS_COLUMN, lit("There are failed records due to data type check for columns, Record Count=" + str(bad_record_data_type_constraint_count)))
        else:
            bad_records_data_type_check_df = bad_records_data_type_check_df.withColumn(config.COMMENTS_COLUMN, lit(""))

        bad_records_null_check_df, bad_record_nullable_constraint_count = check_null_values(table_name, distinct_records_df, column_names, column_null_options, logger)

        if bad_record_nullable_constraint_count > 0:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(config.COMMENTS_COLUMN, lit("There are failed records due to null check for columns, Record Count=" + str(bad_record_nullable_constraint_count)))
        else:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(config.COMMENTS_COLUMN, lit(''))

        logger.debug('Total number of bad records due to Nullable constraint ' + str(bad_record_nullable_constraint_count))
        count_reject_records = count_duplicate + bad_record_data_type_constraint_count + bad_record_nullable_constraint_count
        logger.debug('Total number of records in good table ' + str(total_count - count_reject_records))
        error_records_df = bad_records_data_type_check_df.unionAll(bad_records_null_check_df).drop_duplicates()

        error_records = error_records_df.unionAll(duplicate_df)
        error_records_without_comment = error_records.drop(config.COMMENTS_COLUMN)
        good_records_df = distinct_records_df.subtract(error_records_without_comment)

    return good_records_df, error_records, count_reject_records
