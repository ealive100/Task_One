source_table=$1
good_table=$2
error_table=$3
project_path=$4
log_path=$5
pbrun su - crm_sowd
kinit -kt /etc/security/app-sa-keytabs/crm_sowd.keytab crm_sowd@HADOOPDEV.HOUSTON.HPICORP.NET
export SPARK_MAJOR_VERSION=2; spark-submit --master yarn --deploy-mode client --executor-memory 14G --num-executors 15 --executor-cores 8 --queue terasales --jars $project_path/spark-avro_2.10-3.1.0.jar --py-files $project_path/crm_config.py,$project_path/crm_helper.py --files /usr/hdp/current/spark2-client/conf/hive-site.xml $project_path/crm_dataquality_check.py $source_table $good_table $error_table $log_path
#python $4/exec_crm_dq_validation.py $src $good_path $reject_path $code_path $log_path $schema_name
