from pyspark.sql.functions import unix_timestamp, from_unixtime, substring, concat, lit
from pyspark.sql import SparkSession
from datetime import datetime
import data_quality_helper
import table_validation
import os, sys


def validation_all_parameter_obj():

    batch_number_arg = sys.argv[1]
    bow_id_arg = sys.argv[2]
    load_number_arg = sys.argv[3]
    batch_id_arg = sys.argv[4]
    sbow_id_arg = sys.argv[5]
    file_crm_ingestion_arg = sys.argv[6]
    table_config_arg = sys.argv[7]

    spark_session = SparkSession.builder.enableHiveSupport().appName("Field_DQ_FOR_BATCH_ID[" + batch_number_arg + ']BOW_ID[' + bow_id_arg + ']').getOrCreate()
    log4jLogger = spark_session.sparkContext._jvm.org.apache.log4j
    file_logger = log4jLogger.LogManager.getLogger(__name__)
    spark_session.sparkContext.setLogLevel("ERROR")

    file_logger.debug("DQ with pyspark script logger initialized")

    file_logger.debug("Arguments are from table_validation: arg 1 (batch_number) " + batch_number_arg)
    file_logger.debug("Arguments are from table_validation: arg 2 (bow_id) " + bow_id_arg)
    file_logger.debug("Arguments are from table_validation: arg 3 (load_number) " + load_number_arg)
    file_logger.debug("Arguments are from table_validation: arg 4 (batch_id) " + batch_id_arg)
    file_logger.debug("Arguments are from table_validation: arg 5 (sbow_id) " + sbow_id_arg)
    file_logger.debug("Arguments are from table_validation: arg 6 (file_crm_ingestion) " + file_crm_ingestion_arg)
    file_logger.debug("Arguments are from table_validation: arg 7 (table_config) " + table_config_arg)

    # file_control_props = data_quality_helper.read_all_properties(file_control_config)
    table_props = data_quality_helper.read_all_properties(table_config_arg)

    # all_parameter_obj = None
    # file_crm_ingestion = int(file_crm_ingestion)
    # if file_crm_ingestion == 0:
    #     all_parameter_obj = data_quality_helper.load_file_control_ingestion(table_props, batch_number, bow_id)
    # elif file_crm_ingestion == 1:
    #     all_parameter_obj = data_quality_helper.load_job_paramter_ingestion(table_props, batch_number, bow_id)
    all_parameter_obj = data_quality_helper.load_file_control_ingestion(table_props, batch_number_arg, bow_id_arg)
    tmp_log_table_path = ''
    actual_log_path = ''

    if all_parameter_obj:
        for parameter_obj in all_parameter_obj:
            table_validation.validate_parameter_obj(spark_session, batch_number_arg, bow_id_arg, load_number_arg, batch_id_arg, sbow_id_arg, table_props, parameter_obj, file_logger)
            tmp_log_table_path = parameter_obj.file_landing_path
            actual_log_path = parameter_obj.log_path

    app_id = spark_session.sparkContext.applicationId
    spark_session.stop()

    user = table_props['USER']
    keytab = table_props['KEYTAB']

    os.system('pbrun su - ' + user)
    os.system(keytab)
    log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
    log_table_file = tmp_log_table_path.rstrip('/') + '/dq2_batch_id_' + str(batch_number_arg) + '_bow_id_' + str(bow_id_arg) + '_' + log_time_value + '.log'
    file_logger.debug("(log_file_name) " + log_table_file)
    data_quality_helper.generate_log(file_logger, log_table_file, app_id, 'dummy')

    data_quality_helper.copy_log_files(tmp_log_table_path, actual_log_path)
    data_quality_helper.delete_lfs_file(log_table_file)


validation_all_parameter_obj()
