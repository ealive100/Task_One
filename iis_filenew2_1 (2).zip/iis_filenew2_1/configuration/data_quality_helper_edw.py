import subprocess, re, os, io ,sys
import data_quality_configuration_edw
from datetime import datetime
import ntpath

def get_connection_url(driver_name, server_name, database_name, uid_name, password):
    return 'DRIVER={' + driver_name + '};SERVER=' + server_name + ';DATABASE=' + database_name + ';UID=' + uid_name + ';PWD=' + password

def create_file_load_hst_data(bow_id, batch_id, uow_id, source_file_path, file_landing_path, processed_files, batch_exec_id, archive_file_path):
    return [[bow_id, batch_id, uow_id, data_file, processed_files[data_file], None, batch_exec_id, archive_file_path] for data_file in processed_files]


def create_df(spark, data, schema):
    return spark.createDataFrame(data, schema=schema)


def read_all_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.toDF(*schema)


def count_all_rows_from_hive(spark, table_name):
    table_schema_df = spark.sql("select * from " + table_name)

    return table_schema_df.count()


def read_distinct_rows_from_hive(spark, table_name, schema):
    table_schema_df = spark.sql("select distinct * from " + table_name)

    return table_schema_df.toDF(*schema)


def check_progress(application_id, logger):
    cmd = 'yarn application -status ' + application_id
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
    lines = out.splitlines()
    complete = False
    for line in lines:
        if 'RUNNING' in line:
            complete = False
        if 'SUCCEEDED' in line:
            complete = True
    return complete


def list_files_by_date(location, file_pattern, timestamp_pattern, logger):
    file_list_by_date = []

    if timestamp_pattern:
        dir_files = os.listdir(location)
        set_date_values = sorted(list(set(find_all_dates_for_group(logger, dir_files, file_pattern, timestamp_pattern))))
        logger.debug(set_date_values)
        for file_date in set_date_values:
            file_list = []
            for source_file in dir_files:
                if file_pattern in source_file.lower() and file_date in source_file.lower():
                    file_list.append(source_file)
            file_list_by_date.append(file_list)

    return file_list_by_date


def find_all_dates_for_group(logger, dir_files, pattern_file, regex_pattern):

    all_date_values = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]
            logger.debug(my_file)
            try:
                my_file_name = re.search(pattern_file, my_file_name.lower()).group(0)
                logger.debug('After using regex on file pattern ' + my_file_name)
            except AttributeError:
                continue
            if my_file_name:
                logger.debug('The zip file selected ' + my_file)
                try:
                    date_time_value = re.search(regex_pattern, my_file_name.lower()).group(1)
                    logger.debug('After using regex on timestamp pattern ' + date_time_value)
                except AttributeError:
                    continue
                all_date_values.append(date_time_value)
    else:
        logger.debug('No files found in the path.')
        exit(0)
    return all_date_values


def read_all_properties(config):
    prop_file = open(config, 'r')
    key_values = {}
    for line in prop_file:
            line_components = line.split('=',1)
            if line_components[0]:
                key_values[line_components[0].strip()] = line_components[1].strip()
    prop_file.close()
    return key_values


def read_parameter_file(parameter_config, line_split):
    prop_file = open(parameter_config, 'r')
    parameter_props = []

    all_columns = []
    for line in prop_file:
        line = line.rstrip('\n')
        if line:
            all_columns.append(line.split(line_split))
    prop_file.close()

    column_names = all_columns[0]
    column_values = all_columns[1:]
    for columns in column_values:
        key_values = {}
        key_value = zip(column_names, columns)
        for k, v in key_value:
            key_values[k.strip(' ')] = v.strip(' ')
        parameter_props.append(key_values)

    return parameter_props


def count_lines(dat_file):
    counter = 0
    with open(dat_file) as f:
        for i, l in enumerate(f):
            counter = counter + 1
    return counter


def find_column_count(dat_file):
    data_file_reader = open(dat_file, 'r')
    column_count = []
    counter = 0
    for line in data_file_reader:
        counter = counter + 1
        line = line.rstrip('\n')
        if len(line.split(chr(28))) != 106:
            column_count.append(str(counter) + ' ' + str(len(line.split(chr(28)))))
    data_file_reader.close()
    return column_count


def read_schema_from_hive(regex_desc, desc_query, jdbc_url):
    # print(desc_query)
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", desc_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    stdout, stderr = p.communicate()
    p.wait()
    lines = stdout.splitlines()
    col_names = []
    data_types = []
    nullable = []
    for line in lines:
        cols = re.findall(regex_desc, line.replace('|', ''))
        if len(cols) == 10:
            col_names.append(cols[0])
            data_types.append(cols[1])
            nullable.append(cols[3])
    return col_names, data_types, nullable


def load_hive_data_from_python(split_char, sql_query, jdbc_url, obj):

    first_column = sql_query.split(',')[0].strip('select').strip(' ')
    col_count = len(sql_query.split(','))
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", sql_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # print(sql_query)
    stdout, stderr = p.communicate()
    # print(p.returncode)
    p.wait()
    lines = stdout.split(chr(int(split_char)))
    object_list = []

    col_len = len(lines)
    junk_col = 1
    rows = int(round(col_len / col_count))
    counter = 1
    start_col_value_index = 0
    last_col_value_index = 0
    for i in range(0, rows):
        start_col_value_index = start_col_value_index + junk_col
        last_col_value_index = col_count + junk_col + last_col_value_index
        data = lines[start_col_value_index: last_col_value_index]
        data = [col.strip(" ") for col in data]
        if len(data) == col_count and data[0] != first_column:
            object_list.append(obj(*data))
        else:
            counter = counter + 1
        start_col_value_index = start_col_value_index + col_count
    return object_list


def generate_log(file_logger, file_path, application_id, touch_file_name):
    file_logger.debug("Spark ApplicationId " + application_id)
    # os.system('hadoop fs -rm ' + file_path)
    file_success = '_SUCCESS'
    file_failure = '_FAILED'
    yarn_failure = '_JOB_NOT_RUN'

    if application_id:
        yarn_log_cmd = 'yarn logs -applicationId ' + application_id + ' > ' + file_path
        os.system(yarn_log_cmd)
        # yarn_cmd = yarn_log_cmd.split()
        # log_p = subprocess.Popen(yarn_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        # log_out, log_err = log_p.communicate()
        # log_p.wait()
        # if log_p.returncode == 0:
        #     file_logger.info("Yarn log status Code " + str(log_p.returncode))
        # os.system('hadoop fs -rm  ' + file_path)
        # os.system('hadoop fs -put  ' + file_path + ' ' + file_log_path)
        cmd = 'yarn application -status ' + application_id
        command = cmd.split()
        p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        file_logger.debug("Job status Code " + str(p.returncode) + " with result " + out)
        lines = out.splitlines()
        status = False
        is_complete = False
        for line in lines:
            if 'FINISHED' in line:
                is_complete = True
            if 'SUCCEEDED' in line:
                status = True
        # if status and is_complete:
        #     os.system('touch ' + file_path + file_success)
        #     os.system('touch ' + touch_file_name)
        # else:
        #     os.system('touch ' + file_path + file_failure)
    else:
        file_logger.debug('YARN FAILURE')
        # os.system('touch ' + file_path + yarn_failure)


def read_aud_file_key(file_path, aud_key, logger, encoding_format):
    aud_keys = {}
    with io.open(file_path, encoding=encoding_format, errors='ignore') as file_reader:
    #with io.open(file_path, encoding='utf-16', errors='ignore') as file_reader:
        for line in file_reader:
            line = line.strip(' ')
            if ':' in line and aud_key in line:
                key_value = line.split(':')
                try:
                    aud_keys[key_value[0].strip()] = key_value[1].encode('latin-1').decode('ascii', 'ignore').strip().rstrip('\n')
                    # print(aud_keys)
                except:
                    logger.debug('Encoding error while reading' + file_path + ' for aud_key ' + aud_key)
                    aud_keys[key_value[0].strip()] = key_value[1].strip()
    return aud_keys[aud_key]


def find_all_files(archive_file, valid_files_dict):

    valid_files_dict[archive_file] = archive_file
    return valid_files_dict


def copy_files(all_files, dest_dir_name):

    # os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    if len(all_files) > 0:
        files = ' '.join(all_files)
        fs_put(files, dest_dir_name)


def copy_files_if_header_exist(all_files, dest_dir_name, is_header_included, is_compressed, logger):

    os.system('hadoop fs -rm r ' + dest_dir_name.rstrip('/') + '/*')
    # os.system('hadoop fs -mkdir -p ' + dest_dir_name)
    # header_enabled_list = props['HEADER_ENABLED'].split(',')
    if len(all_files) > 0:
        files_without_header = []
        for file in all_files:
            file_name = file.split('/')[-1]
            if is_header_included.lower() == 'y' and is_compressed.lower() == 'n':
                logger.debug('File having header ' + file)
                os.system("sed '1d' " + file + " | hdfs dfs -put - " + dest_dir_name.rstrip('/') + '/' + file_name)
            else:
                files_without_header.append(file)
        if len(files_without_header) > 0:
            files = ' '.join(files_without_header)
            fs_put(files, dest_dir_name)


def fs_put(file, dir):

    os.system('hadoop fs -put -f ' + file + ' ' + dir)


def check_if_control_exists(extension, local_path, valid_files_dict, invalid_files_dict, logger, props):
    record_count = 0
    is_control_exist = False
    ctrl_file = ''
    # print(local_path)
    if os.path.isdir(local_path):

        for file in os.listdir(local_path):
            if file.endswith(props['CTL_EXT']):
                record_count = read_ctrl_file(os.path.join(local_path, file))
                ctrl_file = file
                if int(record_count) > 0:
                    is_control_exist = True
                else:
                    logger.debug('Even though the control file exist, record count is zero. Files not to be processed.')
        if is_control_exist:
            for file in os.listdir(local_path):
                if file.endswith(extension):
                    valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, ctrl_file)
        else:
            for file in local_path:
                logger.debug('The control file does not exist for file ' + file)
                invalid_files_dict[os.path.join(local_path, file)] = props['LOG_MSG_FOR_AUD_MISSING']

    return valid_files_dict, invalid_files_dict, record_count


def read_ctrl_file(ctrl_file):
    ctrl_file_reader = open(ctrl_file, 'r')
    lines = ctrl_file_reader.readlines()
    count = 0
    for line in lines:
        if line:
            count = line
    ctrl_file_reader.close()
    return count


def check_if_aud_exists(do_validate_file, local_path, valid_files_dict, invalid_files_dict, logger, props, extension):

    if os.path.isdir(local_path):
        for file in os.listdir(local_path):
            if do_validate_file:
                # print(file)
                # print(extension)
                if file.lower().endswith(extension):
                    aud_file_name = os.path.join(local_path, file).rstrip('.' + extension) + props['AUD_EXT']
                    # print(aud_file_name)
                    if os.path.isfile(aud_file_name):
                        logger.debug('The aud exists for file ' + file)
                        valid_files_dict[os.path.join(local_path, file)] = os.path.join(local_path, aud_file_name)
                    else:
                        logger.debug('The aud does not exist for file ' + file)
                        invalid_files_dict[os.path.join(local_path, file)] = props['LOG_MSG_FOR_AUD_MISSING']
            else:
                valid_files_dict[os.path.join(local_path, file)] = ''
    return valid_files_dict, invalid_files_dict


def check_if_row_count_matches(do_validate_file, valid_files, invalid_files, logger, props, is_header_included, encoding_format):

    if props['DO_COUNT_CHECK'] == 'false':
        # print(' COUNT validation ' + props['DO_COUNT_CHECK'])
        # print(valid_files)
        #print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                print("This is file which will be read..." , dat_file)
                row_count = count_lines(dat_file)
                if is_header_included.lower() == 'y':
                    row_count = row_count - 1
                #logger.debug('rows found in dat file ', dat_file, row_count)
                print("Dat File ",dat_file)
                print("rows found in dat file" , row_count)
                # print(props['RECORD_COUNT_KEY'])
                record_count_from_aud = read_aud_file_key(valid_files[dat_file], props['RECORD_COUNT_KEY'], logger, encoding_format)
                print('count key has value', record_count_from_aud)
                logger.debug('counts are ' + str(row_count) + ' and ' + record_count_from_aud)
                if row_count == 0:
                    logger.debug('The row count is zero in the file ' + dat_file + '. So it would be invalidated.')
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_ZERO_COUNT_MATCH']
                elif str(row_count) == record_count_from_aud.strip():
                    logger.debug('The row count matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The row count does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_COUNT_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_rev_matches(is_rev_check, valid_files, invalid_files, logger, props, encoding_format):

    if is_rev_check.lower() == 'n':
        # print(' REV validation ' + is_rev_check)
        # print(valid_files)
        # print(invalid_files)

        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_rev = dat_file.split(os.path.sep)[-1].split('.')[int(props['REV_POSITION'])].strip()
                # print('rev found in dat file ', dat_file, file_rev)
                file_rev_from_aud = read_aud_file_key(valid_files[dat_file], props['REV_KEY'], logger, encoding_format).strip()
                # print('rev key has value', file_rev_from_aud)
                logger.debug('Revisions are from file name and aud as 1' + file_rev + '1 and 1' + file_rev_from_aud + '1')
                if file_rev == file_rev_from_aud:
                    logger.debug('The rev matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The rev does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_REV_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def check_if_seq_matches(is_seq_check, valid_files, invalid_files, logger, props, encoding_format):

    if is_seq_check.lower() == 'n':
        # print(' SEQ validation ' + is_seq_check)
        #print(valid_files)
        # print(invalid_files)
        return 0, valid_files, invalid_files
    else:
        valid_files_new_dict = {}
        counter = 0
        if len(valid_files) > 0:
            for dat_file in valid_files.keys():
                # print("This is file which will be read...", dat_file)
                file_seq = dat_file.split(os.path.sep)[-1].split('.')[int(props['SEQ_POSITION'])]
                # print('seq found in dat file ', dat_file, file_seq)
                file_seq_from_aud = read_aud_file_key(valid_files[dat_file], props['SEQ_KEY'], logger, encoding_format)
                # print('rev key has value', file_seq_from_aud)
                if int(file_seq) == int(file_seq_from_aud):
                    logger.debug('The sequence matches with file ' + dat_file)
                    valid_files_new_dict[dat_file] = valid_files[dat_file]
                else:
                    logger.debug('The sequence does not match with file ' + dat_file)
                    counter = counter + 1
                    invalid_files[dat_file] = props['LOG_MSG_FOR_SEQ_MISMATCH']

        return counter, valid_files_new_dict, invalid_files


def load_job_paramter_ingestion(table_config, batch_number, bow_id):

    split_char = table_config['JOB_PARAMETER_INGESTION_LAYER_COLUMN_SEPARATOR']
    sql_query = table_config['JOB_PARAMETER_INGESTION_LAYER_QUERY'] + ' where batch_number = ' + batch_number + ' and bow_id = ' + bow_id
    hive_jdbc_url = table_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration_edw.JobParameterIngestion

    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)


def load_file_control_ingestion(file_config, batch_id, bow_id):

    split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
    sql_query = file_config['FILE_CONTROL_INGESTION_QUERY'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id
    hive_jdbc_url = file_config['JDBC_URL_BEELINE']
    object_name = data_quality_configuration_edw.FileControlIngestion

    return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)


def archive_files(file_load_hst_data_list):
    for file_load_hst_data in file_load_hst_data_list:
        bow_id, batch_id, uow_id, source_file, file_landing_path, processed_file, batch_exec_id, archive_file_path = file_load_hst_data
        if os.path.isfile(source_file):
            #os.system('hdfs dfs -put -f ' + source_file + ' ' + archive_file_path)
            os.system('hdfs dfs -moveFromLocal ' + source_file + ' ' + archive_file_path)		


def clean_working_path(destination_path):
    os.system('rm -fr  ' + destination_path.rstrip('/') + '/*')


def copy_log_files(source_path, destination_path):
    log_file_list = []
    if os.path.isdir(source_path):
        for file in os.listdir(source_path):
            log_file = os.path.join(source_path, file)
            if os.path.isfile(log_file) and log_file.endswith('.log'):
                log_file_list.append(log_file)
    # print(log_file_list)
    copy_files(log_file_list, destination_path)


def find_all_files_for_group(location, pattern_file):
    dir_files = os.listdir(location)
    all_file_names = []
    if len(dir_files) > 0:
        for my_file in dir_files:
            my_file_name = os.path.splitext(my_file)[0]

            try:
                my_file_name = re.search(pattern_file.lower(), my_file_name.lower()).group(0)

            except AttributeError:
                continue
            if my_file_name:
                all_file_names.append(my_file)
    else:
        print('No files found in the path.')
        exit(0)
    return all_file_names


def sorted_list_files_by_date(dir_files, file_pattern):
    if file_pattern:

        set_file_names = sorted(list(set(find_all_files_for_group(dir_files, file_pattern))))
        # print(set_file_names)
        return set_file_names

    return []


def clean_hdfs_working_path(source_tn_file_list):
    for files in source_tn_file_list:
        os.system('hdfs dfs -rm -r  ' + files)


def delete_lfs_file(lfs_file):
    if os.path.isfile(lfs_file):
        os.system('rm  ' + lfs_file)
        


def load_file_control_ingestion_for_EDW(file_config, batch_id, bow_id, exec_serv_id , db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        print("Hive database")
        split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
        sql_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id + ' and active_flag = ' + "'Y'" + ' and execution_server_id = '  + exec_serv_id  
        hive_jdbc_url = file_config['JDBC_URL_BEELINE']
        object_name = data_quality_configuration_edw.EDWControlIngestion
        print("sql_query" ,sql_query)
        return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)
    else:
        print("SQL database")
        select_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_SQLDB'] + '  where batch_id=? and bow_id=? and active_flag =' + "'Y'" + ' and execution_server_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ',select_query)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, data_quality_configuration_edw.EDWControlIngestion, select_query, batch_id, bow_id , exec_serv_id)
        return object_list

def load_file_control_ingestion_for_EDW_3_Year(file_config, batch_id, bow_id, exec_serv_id , db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        print("Hive database")
        split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
        sql_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_3_Year'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id + ' and active_flag = ' + "'Y'" + ' and execution_server_id = ' + exec_serv_id
        hive_jdbc_url = file_config['JDBC_URL_BEELINE']
        object_name = data_quality_configuration_edw.EDWControlIngestionHistory
        print("sql_query" ,sql_query)
        return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)
    else:
        print("SQL database")
        select_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_3_Year_SQLDB'] + '  where batch_id=? and bow_id=? and active_flag=' + "'Y'" + ' and execution_server_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ', select_query)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, data_quality_configuration_edw.EDWControlIngestionHistory, select_query, batch_id, bow_id , exec_serv_id)
        return object_list

def load_file_control_ingestion_for_EDW_7_Year(file_config, batch_id, bow_id, exec_serv_id, db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        print("Hive database")
        split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
        sql_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_7_Year'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id + ' and active_flag = ' + "'Y'" + ' and execution_server_id = ' + exec_serv_id
        hive_jdbc_url = file_config['JDBC_URL_BEELINE']
        object_name = data_quality_configuration_edw.EDWControlIngestionHistory
        print("sql_query" ,sql_query)
        return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)
    else:
        print("SQL database")
        select_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_7_Year_SQLDB'] + '  where batch_id=? and bow_id=? and active_flag=' + "'Y'" + ' and execution_server_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ', select_query)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, data_quality_configuration_edw.EDWControlIngestionHistory, select_query, batch_id, bow_id , exec_serv_id)
        return object_list

def find_all_files_for_edw_group(txn_src_path,pattern_file_del,timestamp_pattern_del,pattern_file_ad,timestamp_pattern_ad,file_ext,is_del_file,ctrl_file_format,del_src_path,reject_hdfs_path):
    
    txn_files = read_hdfs_files(txn_src_path)
    #print("txn_files",txn_files)
    
    #ctrl_file_format="DAT.ctl"
    del_hdfs_file_names_dict = {}
    tn_hdfs_file_names_dict = {}
    date_time_value_del = 0;
    date_time_value_ad = 0;
    
    if len(txn_files) > 0:
            for my_txn_file in txn_files:
                if ctrl_file_format not in my_txn_file:
                    #print("my_txn_file",my_txn_file)
                    file_name = os.path.split(my_txn_file)[-1]
                    index_of_extension = file_name.lower().index(file_ext)
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    try:
                        
                        file_name_without_ext = re.search(pattern_file_ad.lower(), file_name_without_ext.lower()).group(0)
                        if file_name_without_ext:
                            try:
                                date_time_value_ad = re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(2))
                                date_time_value_ad_int = int(date_time_value_ad)
                                
                                if date_time_value_ad_int in tn_hdfs_file_names_dict.keys(): 
                                    tn_hdfs_file_names_dict[date_time_value_ad_int].append(my_txn_file)
                                else:
                                    tn_hdfs_file_names_dict[date_time_value_ad_int] = [my_txn_file]
                                
                            except AttributeError:
                                continue
                    except AttributeError:
                        continue
                else:
                    if "DEL".lower() not in my_txn_file.lower():
                        #print("Inside")
                        #file_name = os.path.split(my_txn_file)[-1]
                        #print("file_name",file_name)
                        index_of_hdfs = my_txn_file.lower().index(ctrl_file_format.lower())
                        #print("index_of_hdfs",index_of_hdfs)
                        file_name_without_hdfs = my_txn_file[0:index_of_hdfs-1]
                        #print("file_name_without_hdfs",file_name_without_hdfs)
                        file_ctl_split = file_name_without_hdfs.split("_")
                        #print("file_ctl_split",file_ctl_split)
                        prep_file_ctl_ts = file_ctl_split[-3:-1]
                        file_ctl_ts =  "".join(prep_file_ctl_ts)
                        file_ctl_ts_int = int(file_ctl_ts)
                        if file_ctl_ts_int in tn_hdfs_file_names_dict.keys(): 
                            tn_hdfs_file_names_dict[file_ctl_ts_int].append(my_txn_file)
                        else:
                            tn_hdfs_file_names_dict[file_ctl_ts_int] = [my_txn_file]
                  
    else:
        print('No LZ4 files found in the path.')
    print('ad_hdfs_file_names_dict',tn_hdfs_file_names_dict)
    try:
        max_txn_key_dict = max(tn_hdfs_file_names_dict.keys())
        print("max_txn_key_dict",max_txn_key_dict)
    except Exception as e:
        print("Could not TXN files with the mentioned pattern...Exiting DQ and rejecting to ",reject_hdfs_path, e)
        archive_hdfs_files_all(txn_src_path,reject_hdfs_path)
        sys.exit(1)
         
    if len(tn_hdfs_file_names_dict)>0 and is_del_file.lower()=="y":  
            del_files = read_hdfs_files(del_src_path)
            #print("del_files",del_files) 
            for my_del_file in del_files:
                if ctrl_file_format not in my_del_file:
                    file_name = os.path.split(my_del_file)[-1]
                    index_of_extension = file_name.lower().index(file_ext)
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    try:
                        file_name_without_ext = re.search(pattern_file_del.lower(), file_name_without_ext.lower()).group(0)
                        if file_name_without_ext:
                            try:
                                date_time_value_del = re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(2))
                                date_time_value_del_int = int(date_time_value_del)
                                if date_time_value_del_int <= max_txn_key_dict:
                                    if date_time_value_del_int in del_hdfs_file_names_dict.keys(): 
                                        del_hdfs_file_names_dict[date_time_value_del_int].append(my_del_file)
                                    else:
                                        del_hdfs_file_names_dict[date_time_value_del_int] = [my_del_file]   
                            except AttributeError:
                                continue
                    except AttributeError:
                        #print("Error")
                        continue
                else:
                    if "DEL".lower() in my_del_file.lower():
                        #file_name = os.path.split(my_del_file)[-1]
                        index_of_hdfs = my_del_file.lower().index(ctrl_file_format.lower())
                        file_name_without_hdfs = my_del_file[0:index_of_hdfs-1]
                        file_ctl_split = file_name_without_hdfs.split("_")
                        prep_file_ctl_ts = file_ctl_split[-3:-1]
                        file_ctl_ts =  "".join(prep_file_ctl_ts)
                        file_ctl_ts_int = int(file_ctl_ts)
                        if file_ctl_ts_int in del_hdfs_file_names_dict.keys() and file_ctl_ts_int <= max_txn_key_dict: 
                            del_hdfs_file_names_dict[file_ctl_ts_int].append(my_del_file)
                        else:
                            del_hdfs_file_names_dict[file_ctl_ts_int] = [my_del_file]
            if len(del_hdfs_file_names_dict)==0:
                print("DEL files not found with matching pattern hence rejecting it to ",reject_hdfs_path)
                archive_hdfs_files_all(del_src_path,reject_hdfs_path)
                    
    else:
        print('Either Txn file not found or is_del_file is set to N ....')
        
    print('del_hdfs_file_names_dict ', del_hdfs_file_names_dict)
              
    return tn_hdfs_file_names_dict , del_hdfs_file_names_dict

def find_all_files_for_edw_hist_group(txn_src_path,pattern_file_del,timestamp_pattern_del,pattern_file_ad,timestamp_pattern_ad,file_ext,is_del_file,ctrl_file_format,del_src_path):
    
    txn_files = read_hdfs_files(txn_src_path)
    #print("txn_files",txn_files)
    
    #ctrl_file_format="DAT.ctl"
    del_hdfs_file_names_dict = {}
    tn_hdfs_file_names_dict = {}
    date_time_value_del = 0;
    date_time_value_ad = 0;
    
    if len(txn_files) > 0:
            for my_txn_file in txn_files:
                if ctrl_file_format not in my_txn_file:
                    #print("my_txn_file",my_txn_file)
                    file_name = os.path.split(my_txn_file)[-1]
                    index_of_extension = file_name.lower().index(file_ext)
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    try:
                        
                        file_name_without_ext = re.search(pattern_file_ad.lower(), file_name_without_ext.lower()).group(0)
                        if file_name_without_ext:
                            try:
                                date_time_value_ad = re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_ad.lower(), file_name_without_ext.lower()).group(2))
                                date_time_value_ad_int = int(date_time_value_ad)
                                
                                if date_time_value_ad_int in tn_hdfs_file_names_dict.keys(): 
                                    tn_hdfs_file_names_dict[date_time_value_ad_int].append(my_txn_file)
                                else:
                                    tn_hdfs_file_names_dict[date_time_value_ad_int] = [my_txn_file]
                                
                            except AttributeError:
                                continue
                    except AttributeError:
                        continue
                
    else:
        print('No LZ4 files found in the path.')
    #print('ad_hdfs_file_names_dict',tn_hdfs_file_names_dict)
    try:
        max_txn_key_dict = max(tn_hdfs_file_names_dict.keys())
        print("max_txn_key_dict",max_txn_key_dict)
    except Exception as e:
        print("Could not find TXN files with the mentioned pattern...Exiting DQ with exception ", e)
        sys.exit(1)
         
    if len(tn_hdfs_file_names_dict)>0 and is_del_file.lower()=="y":
            del_files = read_hdfs_files(del_src_path)
            #print("del_files",del_files)   
            for my_del_file in del_files:
                if ctrl_file_format not in my_del_file:
                    file_name = os.path.split(my_del_file)[-1]
                    index_of_extension = file_name.lower().index(file_ext)
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    try:
                        file_name_without_ext = re.search(pattern_file_del.lower(), file_name_without_ext.lower()).group(0)
                        if file_name_without_ext:
                            try:
                                date_time_value_del = re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(1)+"".join(re.search(timestamp_pattern_del.lower(), file_name_without_ext.lower()).group(2))
                                date_time_value_del_int = int(date_time_value_del)
                                if date_time_value_del_int <= max_txn_key_dict:
                                    if date_time_value_del_int in del_hdfs_file_names_dict.keys(): 
                                        del_hdfs_file_names_dict[date_time_value_del_int].append(my_del_file)
                                    else:
                                        del_hdfs_file_names_dict[date_time_value_del_int] = [my_del_file]   
                            except AttributeError:
                                continue
                    except AttributeError:
                        print("Error")
                        continue
                else:
                    if "DEL".lower() in my_del_file.lower():
                        #file_name = os.path.split(my_del_file)[-1]
                        index_of_hdfs = my_del_file.lower().index(ctrl_file_format.lower())
                        file_name_without_hdfs = my_del_file[0:index_of_hdfs-1]
                        file_ctl_split = file_name_without_hdfs.split("_")
                        prep_file_ctl_ts = file_ctl_split[-3:-1]
                        file_ctl_ts =  "".join(prep_file_ctl_ts)
                        file_ctl_ts_int = int(file_ctl_ts)
                        if file_ctl_ts_int in del_hdfs_file_names_dict.keys() and file_ctl_ts_int <= max_txn_key_dict: 
                            del_hdfs_file_names_dict[file_ctl_ts_int].append(my_del_file)
                        else:
                            del_hdfs_file_names_dict[file_ctl_ts_int] = [my_del_file]
                    
    else:
        print('Either Txn file not found or is_del_file is set to N ....')
        
    #print('del_hdfs_file_names_dict ', del_hdfs_file_names_dict)
              
    return tn_hdfs_file_names_dict , del_hdfs_file_names_dict


def sort_edw_group_asc(hdfs_trans_files,hdfs_del_files):
    del_hdfs_file_names_list = list(hdfs_del_files.keys())
    tn_hdfs_file_names_list = list(hdfs_trans_files.keys())
    
    total_exec_list = del_hdfs_file_names_list + tn_hdfs_file_names_list
    print("total_list",total_exec_list)
    
    exec_list = list(dict.fromkeys(total_exec_list))
    print("Removed Duplicates",exec_list)
    
    exec_edw_grp_reverse_list = sorted(exec_list, key=None, reverse=False)
    
    print("reverse_my_list",exec_edw_grp_reverse_list)
    return exec_edw_grp_reverse_list;
        

def execute_hdfs_cmd(args_list):
    print('Running hdfs command to check if hdfs path exists: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    proc.communicate()
    print("execute_hdfs_cmd return code 0-Success 1- Failure",proc.returncode)
    return proc.returncode

#create_file_load_hst_data_edw(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path,source_del_file_list,batch_exec_id_arg, param_obj.archive_file_path)
def create_file_load_hst_data_edw(bow_id, batch_id, uow_id,src_path, processed_files, batch_exec_id, archive_file_path , prev_ts, curr_ts, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        return [[bow_id, batch_id, uow_id, src_path, data_file, batch_exec_id, archive_file_path,prev_ts, curr_ts] for data_file in processed_files]
    else:
        return [(bow_id, batch_id, uow_id, src_path, data_file, batch_exec_id, archive_file_path,prev_ts, curr_ts) for data_file in processed_files]
    
def create_file_load_hst_data_edw_history(bow_id, batch_id, uow_id,src_path, processed_files, batch_exec_id, max_part_num , min_upd_gmt_ts, max_upd_gmt_ts,hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        return [[bow_id, batch_id, uow_id, src_path, data_file, batch_exec_id, max_part_num , min_upd_gmt_ts, max_upd_gmt_ts] for data_file in processed_files]
    else:
        return [(bow_id, batch_id, uow_id, src_path, data_file, batch_exec_id, max_part_num , min_upd_gmt_ts, max_upd_gmt_ts) for data_file in processed_files]


def read_ctrl_file_edw(ctrl_file):
    ctrl_file_cmd = 'hdfs dfs -cat ' + ctrl_file;
    
    command = ctrl_file_cmd.split()
    print("ctrl_file_cmd command",command)
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    count, err = p.communicate()
    #print("count" + count)
    return count

def curnt_insert_gmt_ts(table_name,jdbc_url):
    timestamp_ts ='NULL'
    max_timestamp_query = "select max(insert_gmt_timestamp) from " + table_name;
    p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", max_timestamp_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    if p.returncode == 0:    
        lines = stdout.splitlines();
        max_time = lines[3].replace('|','').replace('-','').replace('+','').strip(' ')
        print("find_max_insert_gmt_ts max_time",max_time)
        if max_time == 'NULL' or max_time == '':
            today_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
            timestamp_ts =int(datetime.strptime(today_ts, '%Y%m%d %H:%M:%S.%f').strftime('%Y%m%d%H%M%S'));
        else:
            timestamp_ts =int(datetime.strptime(max_time, '%Y%m%d %H:%M:%S.%f').strftime('%Y%m%d%H%M%S'));
    else:
        print("Table ",table_name, " does not exist...")
        sys.exit(1)
    return timestamp_ts


def get_prev_timestamp(file_config,jdbc_url, bow_id, batch_id, uow_id, db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        prev_timestamp = 'NULL'
        #max_prev_timestamp_query = "select max(prev_insert_gmt_ts) from " + fhle_table_name + " where BOW_ID= "+ bow_id  +" and batch_id="+batch_id + " and uow_id=" + uow_id;
        max_prev_timestamp_query = "select max(curnt_insert_gmt_ts) from " + fhle_table_name + " where BOW_ID= "+ bow_id  +" and batch_id="+batch_id + " and uow_id=" + uow_id;
        print("max_prev_timestamp_query",max_prev_timestamp_query)
        p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", max_prev_timestamp_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        if p.returncode == 0:    
            lines = stdout.splitlines();
            max_time = lines[3].replace('|','').replace('-','').replace('+','').strip(' ');
            print("get_prev_timestamp max_time",max_time)
            if max_time == 'NULL' or max_time == '':
                prev_timestamp = 'NULL'
                #today_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                #prev_timestamp =int(datetime.strptime(today_ts, '%Y-%m-%d %H:%M:%S.%f').strftime('%Y%m%d'));
            else:
                prev_timestamp =int(max_time);
        else:
            print("Table ",fhle_table_name, " does not exist...")
            sys.exit(1)
        return prev_timestamp
    else:
        print("SQL database")
       
        select_query = file_config['FILE_LOAD_HST_EDW_TABLE_INC_PREV_TS_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        #select_query = file_config['FILE_LOAD_HST_EDW_HIST_7_YEAR_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ',select_query, batch_id, bow_id, uow_id)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, int, select_query, batch_id, bow_id, uow_id)
        print("object_list",object_list)
        if len(object_list)>0:
            return object_list[0]
        else:
            return 0;
    

def prepare_for_file_load_hist(file_name_without_ext,src_path):
    
    file_split_without_part = file_name_without_ext.split("_")
    print("file_split_without_part",file_split_without_part)
    prep_file_hist_load = file_split_without_part[0:-1]
    file_hist_load = src_path + "_".join(prep_file_hist_load)
    print("file_hist_load" ,file_hist_load)
    return file_hist_load

def validate_ctl_count_edw(data_frame,record_count):
    ctl_flag = False
    #record_count = read_ctrl_file_edw(ctl_file)
    if int(record_count) > 0:
        if data_frame.count() == int(record_count):
            print('The control file validation successful with dataframe count' ,data_frame.count())
            print('The control file validation successful with record count',record_count)
            #file_logger.info('The control file validation successful')
            ctl_flag = True
        else:
            print('The control file validation failed with dataframe count' ,data_frame.count())
            print('The control file validation failed with record count',record_count)
            #file_logger.info('The record count does not match')
            ctl_flag = False
    
    return ctl_flag

def find_basename_from_path_url(path_url):
    #s = "/landing/edw/working/NEO_EDW_PRO_ADJ_D_20190308_033605"
    base_name = ntpath.basename(path_url)
    return base_name

def check_file_load_hist(file_config, file_load_basename, jdbc_url,db_password, hive_or_sql_server=0):
    # print(desc_query)
    is_file_processed = False
    if hive_or_sql_server == 1:
        
        desc_query = file_config['FILE_LOAD_HST_EDW_TABLE_INC_SQL'] + ' where file_name_processed='+file_load_basename
        p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", desc_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        print("stdout:",stdout, " stderr: " , stderr)
        print("p.returncode" , p.returncode)
        if p.returncode==0:
            lines = stdout.splitlines();
            file_processed = lines[3].replace('|','').replace('-','').replace('+','').strip(' ');
            print("File processed in File load hist table",file_processed)
            if file_processed == 'NULL' or file_processed == '':
                is_file_processed = False;
            else:
                is_file_processed = True
        else:
            print("Table or Query is incorrect ",desc_query, " and beeline_url", jdbc_url,"hence exiting...")
            #sys.exit(1)
        return is_file_processed
    else:
        print("SQL database")
        
        select_query = file_config['FILE_LOAD_HST_EDW_TABLE_INC_QUERY_SQLDB'] + ' where file_name_processed=?'
        #select_query = file_config['FILE_LOAD_HST_EDW_HIST_7_YEAR_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ',select_query, file_load_basename)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, str, select_query, file_load_basename)
        print("object_list",object_list)
        if len(object_list)>0:
            is_file_processed = True
            return is_file_processed
        else:
            is_file_processed = False
            return is_file_processed

def read_hdfs_files(hdfs_path):
    cmd = 'hdfs dfs -ls -C ' + hdfs_path;
    command = cmd.split()
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    #print("HDFS LS execution status " + str(p.returncode) + " with result " + out)
    files = out.splitlines()
    return files

def prepare_for_file_load_hist_HST(file_name_without_ext,src_path):
   
    file_split_with_dot = file_name_without_ext.split(".")
    print("file_split_with_dot",file_split_with_dot)
    file_table = file_split_with_dot[0:-1]
    file_hist_load = "_".join(file_table)
    print("file_table_join",file_hist_load)
    file_split_with_us = file_hist_load.split("_")
    print("file_split_with_us",file_split_with_us)
    file_part = file_split_with_us[-1:]
    file_part_num = int(file_part[0])
    print("file_part_num_int",file_part_num)

    return file_hist_load,file_part

def filter_and_copy_hdfs(source,destination,ctrl_file_format,file_ext,pattern_file_ad):
    all_files = read_hdfs_files(source) 
    if len(all_files) > 0:
            for my_txn_file in all_files:
                if ctrl_file_format not in my_txn_file:
                    print("my_txn_file",my_txn_file)
                    file_name = os.path.split(my_txn_file)[-1]
                    index_of_extension = file_name.lower().index(file_ext)
                    file_name_without_ext = file_name[0:index_of_extension-1]
                    try:
                        
                        file_name_without_ext = re.search(pattern_file_ad.lower(), file_name_without_ext.lower()).group(0)
                        if file_name_without_ext:
                            full_list = [my_txn_file]
                    except AttributeError:
                        continue
                else:
                    full_list = [my_txn_file]    
                  
    else:
        print('No LZ4 files found in the source path.')
    return full_list

def archive_hdfs_files(source_file,archive_file_path):
    #src_path = read_hdfs_files(source_file)
    print("archive_hdfs_files source_file" , source_file)
    if len(source_file)>0:
        print("Archive list contains files...")
        for src_hdfs_files in source_file:
                print("Archiving..." ,'hdfs dfs -mv ' + src_hdfs_files + ' ' + archive_file_path)
                os.system('hdfs dfs -mv ' + src_hdfs_files + ' ' + archive_file_path)   

def archive_hdfs_files_all(source_file,archive_file_path):
    src_path = read_hdfs_files(source_file)
    print("rejecting source_file" , src_path)
    if len(source_file)>0:
        print("Rejection list contains files...")
        for src_hdfs_files in src_path:
                print("Archiving..." ,'hdfs dfs -mv ' + src_hdfs_files + ' ' + archive_file_path)
                os.system('hdfs dfs -mv ' + src_hdfs_files + ' ' + archive_file_path)     

def read_schema_from_hive_using_collect(spark, desc_query):
    print(desc_query)
    # print("collect schema from dataframe")
    schema_list = spark.sql(desc_query).collect()
    col_name_list = [str(row.col_name) for row in schema_list]
    datatype_list = [str(row.data_type) for row in schema_list]
    nullable_list = [str(row.comment).split(":")[0] for row in schema_list]

    return col_name_list, datatype_list, nullable_list

def getget(file_config, batch_id, bow_id, exec_serv_id , db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        print("Hive database")
        split_char = file_config['FILE_CONTROL_INGESTION_COLUMN_SEPARATOR']
        sql_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW'] + ' where batch_id = ' + batch_id + ' and bow_id = ' + bow_id + ' and active_flag = ' + "'Y'" + ' and execution_server_id = '  + exec_serv_id  
        hive_jdbc_url = file_config['JDBC_URL_BEELINE']
        object_name = data_quality_configuration_edw.EDWControlIngestion
        print("sql_query" ,sql_query)
        return load_hive_data_from_python(split_char, sql_query, hive_jdbc_url, object_name)
    else:
        print("SQL database")
        select_query = file_config['FILE_CONTROL_INGESTION_QUERY_EDW_SQLDB'] + '  where batch_id=? and bow_id=? and active_flag =' + "'Y'" + ' and execution_server_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ',select_query)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, data_quality_configuration_edw.EDWControlIngestion, select_query, batch_id, bow_id , exec_serv_id)
        return object_list

def get_max_part_num(file_config, jdbc_url, bow_id, batch_id, uow_id, db_password,hist_type, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        if hist_type == 0:
                file_load_hist_table_name =  pre_table_name + file_config['FILE_LOAD_HST_EDW_TABLE_HIST_3_YEAR']
        else:
                file_load_hist_table_name =  pre_table_name + file_config['FILE_LOAD_HST_EDW_TABLE_HIST_7_YEAR']
        print("Hive database")
        prev_part_num = 0
        max_prev_part_num_query = "select max(MAX_PART_NUMBER) from " + file_load_hist_table_name + " where BOW_ID= "+ bow_id  +" and batch_id="+batch_id + " and uow_id=" + uow_id;
        print("max_prev_part_num_query",max_prev_part_num_query)
        p = subprocess.Popen(["beeline", "-u", "jdbc:hive2://" + jdbc_url + "/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2", "-e", max_prev_part_num_query], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        if p.returncode == 0:    
            lines = stdout.splitlines();
            max_part_num = lines[3].replace('|','').replace('-','').replace('+','').strip(' ')
            print("get_max_part_num max_part_num",max_part_num)
            if max_part_num == 0 or max_part_num == '' or max_part_num == 'NULL':
                print("Initially max_part_num",max_part_num)
                prev_part_num = 0
            else:
                print("Initially max_part_num",max_part_num)
                prev_part_num =int(max_part_num);
        else:
            print("Table ",fhle_table_name, " does not exist...or beeline is responding to status 1")
            #sys.exit(1)
        return prev_part_num
    else:
        print("SQL database")
        if hist_type == 0:
                select_query = file_config['FILE_LOAD_HST_EDW_HIST_3_YEAR_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        else:
                select_query = file_config['FILE_LOAD_HST_EDW_HIST_7_YEAR_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        #select_query = file_config['FILE_LOAD_HST_EDW_HIST_7_YEAR_QUERY_SQLDB'] + '  where batch_id=? and bow_id=? and uow_id=?'
        sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'], file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'], db_password)
        print('query ',select_query, batch_id, bow_id, uow_id)
        # print('con string ' + sql_connection_string)
        object_list = data_quality_configuration_edw.get_data_object_list(sql_connection_string, int, select_query, batch_id, bow_id, uow_id)
        print("object_list",object_list)
        if len(object_list)>0:
            return object_list[0]
        else:
            return 0;
    

def service_accnt_login(user,keytab):
    os.system('pbrun su - ' + user)
    os.system(keytab)
    
def connect(pyodbc,driver,server,database,username,password):
    """ Connect to MS SQL database """
    print(pyodbc,driver,server,database,username,password)
    try:
        print('Connecting to MSSQL database...')
        sqlserver = data_quality_configuration_edw.SQLServer(driver,server,database,username,password)
        conn = sqlserver.create_connection(pyodbc)
        print(conn.cursor())
        if conn.cursor():
            print('connection established.')
            return conn
        else:
            print('connection failed.')
    except Exception as error:
        print(error)

def get_part_num(my_file,extension):
    file_name = os.path.split(my_file)[-1]
    #print(file_name)
    index_of_extension = file_name.lower().index(extension)
    #print(index_of_extension)
    file_name_without_ext = file_name[0:index_of_extension-1]
    file_split_with_dot = file_name_without_ext.split(".")
    #print("file_split_with_dot",file_split_with_dot)
    file_table = file_split_with_dot[0:-1]
    file_table_join = "_".join(file_table)
    #print("file_table_join",file_table_join)
    file_split_with_us = file_table_join.split("_")
    #print("file_split_with_us",file_split_with_us)
    file_part_num = file_split_with_us[-1:]
    file_part_num_int = int(file_part_num[0])
    #print("file_part_num_int",file_part_num_int)
    return file_part_num_int

def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
   
    return [ atoi(c) for c in re.split(r'(\d+)', text) ]

def insert_data_into_abcr_db(file_config, insert_query, data_object_list, db_password):
    sql_connection_string = get_connection_url(file_config['SQL_DRIVER_NAME'], file_config['SQL_SERVER_NAME'],
                                               file_config['SQL_DATABASE_NAME'], file_config['SQL_UID_NAME'],
                                               db_password)
    data_quality_configuration_edw.insert_data_object_list(sql_connection_string, insert_query, data_object_list)