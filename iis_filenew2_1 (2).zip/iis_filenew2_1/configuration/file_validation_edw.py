import os, zipfile, sys, tarfile ,re
import data_quality_helper_edw as file_helper ,data_quality_helper_edw


def validate_file(do_validate_file, archive_file, logger, props, parameter_obj, archive_file_with_extracted_file_dict):

    filename, file_extension = os.path.splitext(archive_file)

    is_valid_zip = False

    extract_path = parameter_obj.file_landing_path.rstrip('/') + '/' + str(filename).split('/')[-1]
    # logger.info('The files would be extracted to ' + extract_path)

    if archive_file.endswith("zip"):
        is_valid_zip = True
        try:
            archive = zipfile.ZipFile(archive_file)
            archive.extractall(extract_path)
            archive.close()
        except zipfile.BadZipfile:
            logger.debug("The archive file format not supported " + archive_file)
            is_valid_zip = False
    elif archive_file.endswith("tar.gz"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:gz")
        tar.extractall(extract_path)
        tar.close()
    elif archive_file.endswith("tar"):
        is_valid_zip = True
        tar = tarfile.open(archive_file, "r:")
        tar.extractall(extract_path)
        tar.close()

    if is_valid_zip:
        archive_file_with_extracted_file_dict[archive_file] = extract_path
    else:
        archive_file_with_extracted_file_dict[archive_file] = ""

    valid_files_dict = {}
    invalid_files_dict = {}

    # if is_valid_zip and do_validate_file:
    #     print('The files are in archive format.')
    #     extract_path = extract_path.rstrip('/')

    if do_validate_file and is_valid_zip:

        if parameter_obj.is_audit_file.lower() == 'y':
            logger.debug('The file validation is done as per audit file')
            valid_files_aud_check, invalid_files = file_helper.check_if_aud_exists(do_validate_file, extract_path, valid_files_dict, invalid_files_dict, logger, props, parameter_obj.extension.lower())

            counter_row_mismatch, valid_files_row_count, invalid_files = file_helper.check_if_row_count_matches(do_validate_file, valid_files_aud_check, invalid_files, logger, props, parameter_obj.is_header_included, parameter_obj.audit_code)

            counter_rev_mismatch, valid_files_rev_check, invalid_files = file_helper.check_if_rev_matches(parameter_obj.is_rev_id, valid_files_row_count, invalid_files, logger, props, parameter_obj.audit_code)

            counter_seq_mismatch, valid_files_seq_check, invalid_files = file_helper.check_if_seq_matches(parameter_obj.is_src_sys_cd_seq, valid_files_rev_check, invalid_files, logger, props, parameter_obj.audit_code)
            return valid_files_seq_check, invalid_files
        elif parameter_obj.is_control_file.lower() == 'y':
            logger.debug('The file validation is done as per control file')
            valid_files_ctl_check, invalid_files, record_count = file_helper.check_if_control_exists(parameter_obj.extension, extract_path, valid_files_dict,
                                                                       invalid_files_dict, logger, props)

            return valid_files_ctl_check, invalid_files, record_count
        else:
            logger.debug('The validation flag enabled but either audit or control flag is disabled.')
            sys.exit(0)
    elif not do_validate_file and is_valid_zip:
        logger.debug('The file validation disabled... but files are in archive format')

        if os.path.isdir(extract_path):
            for file in os.listdir(extract_path):
                file_helper.find_all_files(os.path.join(extract_path, file), valid_files_dict)

        return valid_files_dict, invalid_files_dict
    elif not do_validate_file and not is_valid_zip:
        logger.debug('The file validation disabled... and files are not in archive format')

        return file_helper.find_all_files(archive_file, valid_files_dict), invalid_files_dict


def validate(do_validate_file, files, logger, props, parameter_obj, archive_files):
    all_valid_files = {}
    all_invalid_files = {}

    for file in files:
        logger.debug('File to be validated ' + file + ' where file validation is set to ' + str(do_validate_file))
        valid_files, invalid_files = validate_file(do_validate_file, os.path.join(parameter_obj.source_file_path, file), logger, props, parameter_obj, archive_files)
        valid = all_valid_files.copy()
        valid.update(valid_files)
        all_valid_files = valid
        # all_valid_files = all_valid_files + valid_files
        invalid = all_invalid_files.copy()
        invalid.update(invalid_files)
        all_invalid_files = invalid

        # all_invalid_files = all_invalid_files + invalid_files
    logger.debug('The valid files..')
    logger.debug(all_valid_files)
    logger.debug('The invalid files...')
    logger.debug(all_invalid_files)
    return all_valid_files, all_invalid_files


def post_process(valid_files, invalid_files, good_path_files, reject_path_files, is_header_included, logger):
    if len(valid_files) > 0:
        # print(valid_files)
        all_files = list(valid_files.keys()) # + list(valid_files.values())
        file_helper.copy_files(all_files, good_path_files)
        # file_helper.copy_files_if_header_exist(all_files, good_path_files, is_header_included, is_compressed, logger)

    if len(invalid_files) > 0:
        # print(invalid_files)
        all_files = list(invalid_files.keys())
        file_helper.copy_files(all_files, reject_path_files)


def get_valid_files_dict(parameter_obj, props, logger):

    all_good_files = {}
    archive_file_dict = {}
    file_validation = True
    if parameter_obj.is_file_validation.lower() == 'n':
        file_validation = False

    dir_files = file_helper.sorted_list_files_by_date(parameter_obj.source_file_path, parameter_obj.file_pattern)
    if len(dir_files) > 0:
        all_valid_files_dict, all_invalid_files_dict = validate(file_validation, dir_files, logger,  props, parameter_obj, archive_file_dict)
        all_good_files = all_valid_files_dict
        post_process(all_valid_files_dict, all_invalid_files_dict, parameter_obj.hdfs_good_path, parameter_obj.hdfs_reject_path, parameter_obj.is_header_included, logger)
    else:
        logger.debug('No files selected with the mentioned file pattern.')

    return all_good_files, archive_file_dict

def validate_edw_files_for_hist(parameter_obj, props, logger,ctrl_file,hist_path):
    logger.info('inside validate_edw_files_for_hist')
    file_validation = False
    
    print("Reading file from ",hist_path)
    hdfs_trans_files , hdfs_del_files = file_helper.find_all_files_for_edw_hist_group(hist_path,parameter_obj.del_file_pattern,parameter_obj.del_timestamp_pattern,parameter_obj.ad_file_pattern,parameter_obj.ad_timestamp_pattern,parameter_obj.extension,parameter_obj.is_del_file,ctrl_file,parameter_obj.del_source_file_path)
    print("Param " , parameter_obj.source_file_path,parameter_obj.del_file_pattern,parameter_obj.del_timestamp_pattern,parameter_obj.ad_file_pattern,parameter_obj.ad_timestamp_pattern,parameter_obj.extension)
    logger.info(hdfs_trans_files)
    exec_edw_group_list = file_helper.sort_edw_group_asc(hdfs_trans_files,hdfs_del_files)
    return hdfs_trans_files , hdfs_del_files , exec_edw_group_list


def validate_edw_files(parameter_obj, props, logger,ctrl_file):
    logger.info('inside validate_edw_files')
    file_validation = False
    hdfs_trans_files , hdfs_del_files = file_helper.find_all_files_for_edw_group(parameter_obj.source_file_path,parameter_obj.del_file_pattern,parameter_obj.del_timestamp_pattern,parameter_obj.ad_file_pattern,parameter_obj.ad_timestamp_pattern,parameter_obj.extension,parameter_obj.is_del_file,ctrl_file,parameter_obj.del_source_file_path,parameter_obj.hdfs_reject_path)
    print("Param " , parameter_obj.source_file_path,parameter_obj.del_file_pattern,parameter_obj.del_timestamp_pattern,parameter_obj.ad_file_pattern,parameter_obj.ad_timestamp_pattern,parameter_obj.extension)
    logger.info(hdfs_trans_files)
    exec_edw_group_list = file_helper.sort_edw_group_asc(hdfs_trans_files,hdfs_del_files)
    return hdfs_trans_files , hdfs_del_files , exec_edw_group_list



def prepare_and_copy_edw_files(txn_list_files,counter_max,logger,src_path,edw_ctrl_format,counter_init):
    logger.info('inside prepare_and_copy_edw_files')
    
    
    #list_len = len(txn_list_files);
    sorted_list = txn_list_files
    init_count = int(counter_init)
    print("init_count",init_count)
    maximum_counter = int(counter_max)
    print("maximum_counter",maximum_counter)
    max_counter = int(init_count)  + int(maximum_counter)
    print("Initial Counter:", init_count, " Max counter after addition:" ,max_counter)
    #unsorted_list = sorted(txn_list_files, key=None, reverse=False)
    #print("unsorted_list len" , len(unsorted_list))
    sorted_list.sort(key=file_helper.natural_keys)
    print("sorted_list",sorted_list)
    if init_count>0:
        print("deleting old files...")
        for i,e in list(enumerate(sorted_list)):
            print("i is deleting" , i)
            if(i==init_count):
                print("Breaking after deleting....",init_count,i)
                break
            else:
                for x in sorted_list:
                    part_num = file_helper.get_part_num(x,".lz4")
                    if (i==part_num):
                        print("removed already processed files ",x)
                        sorted_list.remove(x)
    
    sorted_list_len = len(sorted_list)
    print("sorted_list_len",sorted_list_len)
    #===========================================================================
    # if init_count>0:
    #     init_count_next = init_count + 1
    # else:
    #     init_count_next = init_count
    #===========================================================================
    if sorted_list_len>0:
        for i,e in list(enumerate(sorted_list)):
            #copy
            print("i is" , i)
            if edw_ctrl_format not in e:
                if(i<=maximum_counter):
                    print(i,e,len(sorted_list))
                    #for x in sorted_list:
                        #part_num = file_helper.get_part_num(x,".lz4")
                        #if((i%10)==(part_num%10)):
                    cp_txn_cmd = ['hdfs', 'dfs', '-cp','-f', e, src_path]
                    print("cp_txn_cmd",cp_txn_cmd)
                    status = file_helper.execute_hdfs_cmd(cp_txn_cmd)
                    if status == 0: 
                        sorted_list.remove(e)
                        sorted_list_len = len(sorted_list)
                        print("i",i,"max_counter",max_counter,"sorted_list_len",sorted_list_len)
                        if (i==maximum_counter-1) or (sorted_list_len==0):
                            print("Copying done...breaking as max_counter is ",max_counter,i)
                            print(sorted_list_len,sorted_list,i)
                            return sorted_list ,max_counter , i
                    else:
                        print("Could not copy the files due to command failure")
                        sys.exit(1)
            else:
                print("This file is a CTL file ", e)
                sorted_list.remove(e)
        
    print("Exiting prepare_and_copy_edw_files....")
    return sorted_list ,max_counter , i

