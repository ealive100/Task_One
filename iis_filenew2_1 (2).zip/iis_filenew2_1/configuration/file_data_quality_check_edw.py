import sys, os
import data_quality_helper_edw as file_helper

python_path = sys.argv[1]
lib_path = sys.argv[2]
config_path = sys.argv[3]
batch_id = sys.argv[4]
bow_id = sys.argv[5]
load_number = sys.argv[6]
batch_exec_id = sys.argv[7]
sbow_id = sys.argv[8]
field_validation = sys.argv[9]
exec_server_id = sys.argv[10]
source_type = sys.argv[11]
db_password = sys.argv[12]
abcr_db_type = sys.argv[13]
secret_password = '@'.join([str(ord(c)) for c in db_password])

print("(python_path) " + python_path)
print("(lib_path) " + lib_path)
print("(config_path) " + config_path)
print("Arguments are : arg 1 (batch_id) " + batch_id)
print("Arguments are : arg 2 (bow_id) " + bow_id)
print("Arguments are : arg 3 (load_number) " + load_number)
print("Arguments are : arg 4 (batch_exec_id) " + batch_exec_id)
print("Arguments are : arg 5 (sbow_id) " + sbow_id)
print("Arguments are : arg 6 (field_validation) " + field_validation)
print("Arguments are : arg 7 (exec_server_id) " + exec_server_id)
print("Arguments are : arg 8 (source_type) " + source_type)
print("Arguments are : arg 9 (db_password) " + secret_password)
print("Arguments are : arg 10 (abcr_db_type) " + abcr_db_type)
file_config = config_path.rstrip('/') + '/data_quality_config_edw.ini'

props = file_helper.read_all_properties(file_config)

user = props['USER']
keytab = props['KEYTAB']
os.system('pbrun su - ' + user)
os.system(keytab)

mode = props['DEPLOY_MODE']
exec_mem = props['EXECUTOR_MEMORY']
num_exec = props['NUM_OF_EXECUTOR']
queue = props['JOB_QUEUE']
cores = props['EXECUTOR_CORES']
hive_config = props['HIVE_CONFIG_PATH']
#===============================================================================
# edw
# edw_3_year
# edw_7_year
#===============================================================================
if source_type.lower() =='edw':
#script_path = python_path.rstrip('/') + '/file_ingestion.py'
    print("Ingestion EDW of type ",source_type)
    script_path = python_path.rstrip('/') + '/file_ingestion_edw_inc.py'
    file_path = python_path.rstrip('/') + '/file_validation_edw.py,' + python_path.rstrip(
        '/') + '/data_quality_helper_edw.py,' + python_path.rstrip(
        '/') + '/data_quality_configuration_edw.py,' + python_path.rstrip(
        '/') + '/table_validation_edw_inc.py'
    jar_file = lib_path.rstrip('/') + '/spark-csv_2.11-1.5.0.jar,' + lib_path.rstrip('/') + '/spark-excel_2.11-0.8.6.jar'
    spark_submit_args = ['export SPARK_MAJOR_VERSION=2; spark-submit --master yarn', '--jars', jar_file, '--executor-memory', exec_mem, '--num-executors', num_exec, '--executor-cores', cores, '--queue', queue, '--py-files', file_path, '--files', hive_config, script_path, batch_id, bow_id, load_number, batch_exec_id, sbow_id, file_config, field_validation, exec_server_id, source_type, secret_password, abcr_db_type]
    os.system(' '.join(spark_submit_args))
    
elif source_type.lower() =='edw_3_year' or source_type.lower() =='edw_7_year':
    print("Ingestion EDW of type ",source_type)
    script_path = python_path.rstrip('/') + '/file_ingestion_edw_hist.py'
    file_path = python_path.rstrip('/') + '/file_validation_edw.py,' + python_path.rstrip(
        '/') + '/data_quality_helper_edw.py,' + python_path.rstrip(
        '/') + '/data_quality_configuration_edw.py,' + python_path.rstrip(
        '/') + '/table_validation_edw_hist.py'
    jar_file = lib_path.rstrip('/') + '/spark-csv_2.11-1.5.0.jar,' + lib_path.rstrip('/') + '/spark-excel_2.11-0.8.6.jar'
    spark_submit_args = ['export SPARK_MAJOR_VERSION=2; spark-submit --master yarn', '--jars', jar_file, '--executor-memory', exec_mem, '--num-executors', num_exec, '--executor-cores', cores, '--queue', queue, '--py-files', file_path, '--files', hive_config, script_path, batch_id, bow_id, load_number, batch_exec_id, sbow_id, file_config, field_validation, exec_server_id, source_type, secret_password, abcr_db_type]
    os.system(' '.join(spark_submit_args))
        
#jar_file = lib_path.rstrip('/') + '/spark-csv_2.11-1.5.0.jar,' + lib_path.rstrip('/') + '/spark-excel_2.11-0.8.6.jar'

#===============================================================================
# if field_validation == '2':
#     file_path = python_path.rstrip('/') + '/file_validation.py,' + python_path.rstrip(
#         '/') + '/data_quality_helper.py,' + python_path.rstrip(
#         '/') + '/data_quality_configuration.py,' + python_path.rstrip(
#         '/') + '/table_validation.py,' + python_path.rstrip('/') + '/table_ingestion.py'
# else:
#     file_path = python_path.rstrip('/') + '/file_validation.py,' + python_path.rstrip(
#         '/') + '/data_quality_helper.py,' + python_path.rstrip(
#         '/') + '/data_quality_configuration.py'
#===============================================================================

#spark_submit_args = ['export SPARK_MAJOR_VERSION=2; spark-submit --master yarn', '--jars', jar_file, '--executor-memory', exec_mem, '--num-executors', num_exec, '--executor-cores', cores, '--queue', queue, '--py-files', file_path, '--files', hive_config, script_path, batch_id, bow_id, load_number, batch_exec_id, sbow_id, file_config, field_validation]
#os.system(' '.join(spark_submit_args))
