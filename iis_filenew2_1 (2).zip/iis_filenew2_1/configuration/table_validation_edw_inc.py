from pyspark.sql.functions import lit, col, unix_timestamp, concat, from_unixtime, substring, hash , regexp_replace
from pyspark.sql import Window
import pyspark.sql.functions as f
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType
from datetime import datetime
import data_quality_helper_edw as data_quality_helper

"""
This class provides various functions to do data quality checks on source records in form of dat file.
1.Data type check
2.Duplicate record check
3.Null check
"""
# batch_number_arg = sys.argv[1]
# bow_id_arg = sys.argv[2]
# logical_deletion_indicator_arg = sys.argv[3]
# load_number_arg = sys.argv[4]
# batch_id_arg = sys.argv[5]
# sbow_id_arg = sys.argv[6]
# file_crm_ingestion_arg = sys.argv[7]
# table_config_arg = sys.argv[8]
#
# spark_session = SparkSession.builder.enableHiveSupport().appName("Field_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']').getOrCreate()
# log4jLogger = spark_session.sparkContext._jvm.org.apache.log4j
# file_logger = log4jLogger.LogManager.getLogger(__name__)
# file_logger.info("DQ with pyspark script logger initialized")


def read_duplicate_rows_from_hive(full_df, schema, props):
    hash_full_df = full_df.withColumn("_hash", hash(*schema))
    hash_full_df_window = hash_full_df.withColumn("_duplicate", f.count("*").over(Window.partitionBy("_hash")))
    duplicate_df = hash_full_df_window.filter("_duplicate > 1")
    # duplicate_df.show(20, truncate = False)
    return duplicate_df.withColumn(props['COMMENTS_COLUMN'], concat(lit("There are failed records due to primary key check, Record Count="), col('_duplicate'))).drop("_hash").drop("_duplicate")


def create_filter(column_list, regex_pattern, total_filter_list):

    filter_list = [column + " != '' and " + column + " rlike '" + regex_pattern + "'" for column in column_list]

    if filter_list:
        total_filter_list = total_filter_list + filter_list

    return total_filter_list


def check_data_type(table_name, object_name, column_names_with_data_type, logger, props):
    error_records = object_name.filter("1=0")

    total_count = 0

    columns_date_list = []
    columns_int_list = []
    columns_timestamp_list = []
    columns_smallint_list = []
    columns_decimal_list = []
    columns_datetime_list = []
    columns_bit_list = []
    columns_bigint_list = []

    for column, data_type in column_names_with_data_type:
        if data_type == props['INT']:
            columns_int_list.append(column)
        elif data_type == props['DATE']:
            columns_date_list.append(column)
        elif data_type == props['TIMESTAMP']:
            columns_timestamp_list.append(column)
        elif data_type == props['SMALLINT']:
            columns_smallint_list.append(column)
        elif data_type == props['DECIMAL']:
            columns_decimal_list.append(column)
        elif data_type == props['DATETIME']:
            columns_datetime_list.append(column)
        elif data_type == props['BIT']:
            columns_bit_list.append(column)
        elif data_type == props['BIGINT']:
            columns_bigint_list.append(column)

    total_filter_list = []
    total_filter_list = create_filter(columns_int_list, props['REGEX_INT'], total_filter_list)
    total_filter_list = create_filter(columns_date_list, props['REGEX_DATE'], total_filter_list)
    total_filter_list = create_filter(columns_timestamp_list, props['REGEX_TIMESTAMP'], total_filter_list)
    total_filter_list = create_filter(columns_smallint_list, props['REGEX_SMALLINT'], total_filter_list)
    total_filter_list = create_filter(columns_decimal_list, props['REGEX_DECIMAL'], total_filter_list)
    total_filter_list = create_filter(columns_datetime_list, props['REGEX_DATETIME'], total_filter_list)
    total_filter_list = create_filter(columns_bit_list, props['REGEX_BIT'], total_filter_list)
    total_filter_list = create_filter(columns_bigint_list, props['REGEX_BIGINT'], total_filter_list)

    filter_str = ' or '.join(total_filter_list)

    if filter_str != '':
        logger.debug(filter_str)
        error_records = object_name.filter(filter_str)
        total_count = error_records.count()
        if total_count > 0:
            logger.debug("There are failed records in table [" + table_name + "] due to data type check for column, Record Count=" + str(total_count))
            error_records = error_records.drop_duplicates()
        return error_records, total_count
    return error_records, total_count


def check_null_values(table_name, object_name, column_names, column_null_options, logger):
    error_records = object_name.filter("1=0")
    total_count = 0
    nullable_col_list = []
    for column, nullable in zip(column_names, column_null_options):
        if nullable.lower() == 'no':
            nullable_col_list.append(column)
    if len(nullable_col_list) > 0:
        filter_condition_list = ["(" + column + " is null) or (trim(" + column + ") = '')" for column in nullable_col_list]
        filter_condition = ' or '.join(filter_condition_list)
        error_records = object_name.filter(filter_condition)

        total_count = error_records.count()
        if total_count > 0:
            logger.debug("There are failed records in table [" + table_name + "] due to null check for column, Record Count=" + str(total_count))
            error_records = error_records.drop_duplicates()
    return error_records, total_count


def validate_table_data(spark, table_name, logger, props, file_logger,is_dq_enabled):

    desc_query = 'desc ' + table_name

    column_names,data_types,column_null_options = data_quality_helper.read_schema_from_hive(props['REGEX_DESCRIBE'], desc_query, props['JDBC_URL_BEELINE'])

    logger.debug(' Columns are ' + ''.join(column_names))
    column_names_with_data_type = zip(column_names, data_types)
    full_data_df = data_quality_helper.read_all_rows_from_hive(spark, table_name, column_names)
    source_count = full_data_df.count()
    #is_dq_required = False
    #is_dq_required = True
    good_records_df = full_data_df
    error_records = full_data_df.filter("1=0")
    count_reject_records = 0
    if is_dq_enabled:
        distinct_records_df = data_quality_helper.read_distinct_rows_from_hive(spark, table_name, column_names)
        distinct_records_df.cache()
        total_count = full_data_df.count()
        distinct_count = distinct_records_df.count()
        duplicate_df = full_data_df.filter("1=0")
        count_duplicate = total_count - distinct_count
        if count_duplicate > 0:
            # duplicate_df = spark.sql("select *, count(*) as _count from " + table_name + " group by " + ','.join(column_names) + ' having _count > 1').withColumn(props['COMMENTS_COLUMN'], concat(lit("There are failed records due to primary key check, Record Count="), col('_count'))).drop('_count')
            duplicate_df = read_duplicate_rows_from_hive(full_data_df, column_names, props)
        else:
            duplicate_df = duplicate_df.withColumn(props['COMMENTS_COLUMN'], lit(''))

        logger.debug('Total number of records in ' + table_name + ' data file are ' + str(total_count))
        logger.debug('Total number of duplicate records in ' + table_name + ' data file are ' + str(duplicate_df.count()))

        bad_records_data_type_check_df, bad_record_data_type_constraint_count = check_data_type(table_name, distinct_records_df, column_names_with_data_type, logger, props)
        logger.debug('Number of bad records due to data type check constraint ' + str(bad_record_data_type_constraint_count))

        if bad_record_data_type_constraint_count > 0:
            bad_records_data_type_check_df = bad_records_data_type_check_df.withColumn(props['COMMENTS_COLUMN'], lit("There are failed records due to data type check for columns, Record Count=" + str(bad_record_data_type_constraint_count)))
        else:
            bad_records_data_type_check_df = bad_records_data_type_check_df.withColumn(props['COMMENTS_COLUMN'], lit(""))

        bad_records_null_check_df, bad_record_nullable_constraint_count = check_null_values(table_name, distinct_records_df, column_names, column_null_options, logger)

        if bad_record_nullable_constraint_count > 0:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(props['COMMENTS_COLUMN'], lit("There are failed records due to null check for columns, Record Count=" + str(bad_record_nullable_constraint_count)))
        else:
            bad_records_null_check_df = bad_records_null_check_df.withColumn(props['COMMENTS_COLUMN'], lit(''))

        logger.debug('Total number of bad records due to Nullable constraint ' + str(bad_record_nullable_constraint_count))
        count_reject_records = count_duplicate + bad_record_data_type_constraint_count + bad_record_nullable_constraint_count
        logger.debug('Total number of good records in source table ' + str(total_count - count_reject_records))
        error_records_df = bad_records_data_type_check_df.union(bad_records_null_check_df).drop_duplicates()

        error_records = error_records_df.union(duplicate_df)
        error_records_without_comment = error_records.drop(props['COMMENTS_COLUMN'])
        good_records_df = distinct_records_df.subtract(error_records_without_comment)
    target_count = good_records_df.count()
    return good_records_df, error_records, count_reject_records, source_count, target_count


def execute_validation(spark, table_name, good_table, reject_table, props, log_control_table_data, start_time, partition_col, bow_id, sbow_id, uow_id, load_number, batch_id, batch_number, job_name, file_logger,load_type):

    unique_records_df, error_records, count_error_records, source_count, target_count = validate_table_data(spark, table_name, file_logger, props, file_logger)
    end_time = insert_data(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table,load_type)
    log_control_table_data.append(
        [int(bow_id), sbow_id, uow_id, load_number, start_time, end_time, None, None,
         'S', batch_id, None, None, source_count, target_count, int(batch_number), job_name, 0,
         datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]])

#execute_edw_validation(spark_session, source_table_name, good_table_name, reject_table_name, props, partition_col, file_logger ,type_of_load,jdbc_url_beeline,prev_timestamp,is_dq_enabled)
def execute_edw_validation(spark, table_name, good_table, reject_table, props, partition_col, file_logger,load_type,jdbc_bl_url,ts_prev,is_dq_enabled):

    unique_records_df, error_records, count_error_records, source_count, target_count = validate_table_data(spark, table_name, file_logger, props, file_logger,is_dq_enabled)
    curr_ts = insert_edw_dat(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table,load_type,table_name,jdbc_bl_url,ts_prev)
    
    return source_count, target_count , curr_ts

def validate_parameter_obj(spark_session, batch_number_arg, bow_id_arg, load_number_arg, batch_id_arg, sbow_id_arg, props, parameter_obj, file_logger):
    log_control_schema = StructType(
        [StructField("bow_id", IntegerType(), True), StructField("sbow_id", IntegerType(), True),
         StructField("uow_id", IntegerType(), True),
         StructField("load_job_number", StringType(), True), StructField("run_start_timestamp", StringType(), True),
         StructField("run_end_timestamp", StringType(), True),
         StructField("cdc_start_timestamp", TimestampType(), True),
         StructField("cdc_end_timestamp", TimestampType(), True), StructField("status", StringType(), True),
         StructField("batch_id", StringType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),
         StructField("prev_cdc_start_timestamp", TimestampType(), True),
         StructField("source_count", IntegerType(), True), StructField("target_count", IntegerType(), True),
         StructField("batch_number", IntegerType(), True),
         StructField("job_name", StringType(), True), StructField("record_delete_count", IntegerType(), True),
         StructField("insert_gmt_timestamp", StringType(), True)])

    partition_col = props['PARTITION_COLUMN_NAME']
    pre_table_name = props['DATABASE_NAME']
    log_control_data = []
    sbow_id = int(sbow_id_arg)

    uow_id = int(parameter_obj.uow_id)
    job_name = parameter_obj.job_name
    source_table_name = parameter_obj.lz_table_name
    good_table_name = parameter_obj.hst_table_name
    reject_table_name = parameter_obj.reject_table_name
    type_of_load = parameter_obj.type_of_load

    if not source_table_name.startswith(parameter_obj.hive_schema_name):
        source_table_name = parameter_obj.hive_schema_name + '.' + source_table_name

    if not good_table_name.startswith(parameter_obj.hive_schema_name):
        good_table_name = parameter_obj.hive_schema_name + '.' + good_table_name

    if not reject_table_name.startswith(parameter_obj.hive_schema_name):
        reject_table_name = parameter_obj.hive_schema_name + '.' + reject_table_name

    file_logger.debug("(source_table_name) " + source_table_name)
    file_logger.debug("(good_table_name) " + good_table_name)
    file_logger.debug("(reject_table_name) " + reject_table_name)
    start_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    src_table_count = data_quality_helper.count_all_rows_from_hive(spark_session, source_table_name)
    if src_table_count > 0:
        log_control_data.append(
            [int(bow_id_arg), sbow_id, uow_id, load_number_arg, start_date, start_date, None, None, 'R', batch_id_arg, None, None,
             0, 0, int(batch_number_arg), job_name, 0, start_date])
        execute_validation(spark_session, source_table_name, good_table_name, reject_table_name, props,
                           log_control_data, start_date, partition_col, bow_id_arg, sbow_id, uow_id, load_number_arg, batch_id_arg, batch_number_arg, job_name, file_logger,type_of_load)

    #data_quality_helper.archive_files(parameter_obj.source_file_path, parameter_obj.archive_file_path)

    log_ctrl_table_name = pre_table_name + props['LOG_CONTROL_TABLE']
    df_log_control_data = data_quality_helper.create_df(spark_session, log_control_data, log_control_schema)
    df_log_control_data = df_log_control_data.select('bow_id', 'sbow_id', 'uow_id', 'load_job_number',
                                                     unix_timestamp('run_start_timestamp',
                                                                    "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                         TimestampType()).alias("run_start_timestamp"),
                                                     unix_timestamp('run_end_timestamp',
                                                                    "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                         TimestampType()).alias("run_end_timestamp"),
                                                     'cdc_start_timestamp', 'cdc_end_timestamp', 'status', 'batch_id',
                                                     'prev_cdc_end_timestamp', 'prev_cdc_start_timestamp',
                                                     'source_count', 'target_count', 'batch_number', 'job_name',
                                                     'record_delete_count', unix_timestamp('insert_gmt_timestamp',
                                                                                           "yyyy-MM-dd HH:mm:ss.SSS").cast(
            TimestampType()).alias("insert_gmt_timestamp"))

    df_log_control_data.write.mode("append").format("text").insertInto(log_ctrl_table_name, overwrite=False)


def insert_data(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table,load_type):

    #unique_records_df.show(5)
    # unique_records_df.write.mode("overwrite").saveAsTable(good_table)
    spark.sql("SET hive.exec.dynamic.partition = true")
    spark.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
    unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType())).write.mode("append").format("avro").insertInto(good_table, overwrite=False)
    if count_error_records > 0:
        error_records.write.mode("append").format("text").insertInto(reject_table, overwrite=False)
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

def validate_parameter_obj_edw(spark_session,props, parameter_obj, file_logger,prev_timestamp):
   

    partition_col = props['PARTITION_COLUMN_NAME']
    
    jdbc_url_beeline = props['JDBC_URL_BEELINE']
    
    #===========================================================================
    # if edw_type=="DEL":
    #     uow_id = int(parameter_obj.del_uow_id)
    # else:
    #     uow_id = int(parameter_obj.uow_id)
    # job_name = parameter_obj.job_name
    #===========================================================================
    source_table_name = parameter_obj.lz_table_name
    good_table_name = parameter_obj.hst_table_name
    reject_table_name = parameter_obj.reject_table_name
    type_of_load = parameter_obj.type_of_load
    if not source_table_name.startswith(parameter_obj.hive_schema_name):
        source_table_name = parameter_obj.hive_schema_name + '.' + source_table_name

    if not good_table_name.startswith(parameter_obj.hive_schema_name):
        good_table_name = parameter_obj.hive_schema_name + '.' + good_table_name

    if not reject_table_name.startswith(parameter_obj.hive_schema_name):
        reject_table_name = parameter_obj.hive_schema_name + '.' + reject_table_name
        
    if parameter_obj.is_dq_required.lower() == 'y':
        is_dq_enabled = True
    else:
        is_dq_enabled = False

    file_logger.debug("(source_table_name) " + source_table_name)
    file_logger.debug("(good_table_name) " + good_table_name)
    file_logger.debug("(reject_table_name) " + reject_table_name)
    
    src_table_count = data_quality_helper.count_all_rows_from_hive(spark_session, source_table_name)
    if src_table_count > 0:
        source_count, target_count , ts_curr = execute_edw_validation(spark_session, source_table_name, good_table_name, reject_table_name, props, partition_col, file_logger ,type_of_load,jdbc_url_beeline,prev_timestamp,is_dq_enabled)

    return source_count, target_count , ts_curr

def insert_edw_dat(spark, unique_records_df, error_records, count_error_records, partition_col, good_table, reject_table,load_type,table_name,jdbc_url,prev_ts):

    #unique_records_df.show(5)
    # unique_records_df.write.mode("overwrite").saveAsTable(good_table)
    spark.sql("SET hive.exec.dynamic.partition = true")
    spark.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
    # Truncate and Load
    if load_type == "I":
        print("Load type as Incremential:", load_type)
        curr_timestamp = "NULL";
        #unique_records_df.withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType())).write.mode("append").format("avro").insertInto(good_table, overwrite=False)
        unique_records_df.withColumn(partition_col,regexp_replace(substring(from_unixtime(unix_timestamp()),1,10),'-','')).write.mode("append").format("avro").insertInto(good_table, overwrite=False)
    else:
        print("Load type as Full:", load_type)
        #max_timestamp_query = "select max(insert_gmt_timestamp) from " + table_name;
        curr_timestamp = data_quality_helper.curnt_insert_gmt_ts(table_name,jdbc_url)
        #curr_timestamp = "20190311"
        print('curr_timestamp',curr_timestamp); 
        unique_records_df.withColumn(partition_col, lit(curr_timestamp)).write.mode("append").format("avro").insertInto(good_table, overwrite=False)
        df1= spark.sql("select count(1) from "+ good_table);
        df1.show();
        if prev_ts!='NULL':
            sql_drop_partition = " ALTER TABLE "+ good_table + " DROP IF EXISTS PARTITION " + "(partition_insert_gmt_timestamp_yyyymmddhhmmss="+prev_ts+")"
            spark.sql(sql_drop_partition);
            print("$$$$$$$$after deleting old partition$$$$$$$$")
            df2 = spark.sql("select count(1) from "+ good_table);
            df2.show();
    if count_error_records > 0:
        error_records.write.mode("append").format("text").insertInto(reject_table, overwrite=False)
    #return datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],curr_timestamp
    return curr_timestamp