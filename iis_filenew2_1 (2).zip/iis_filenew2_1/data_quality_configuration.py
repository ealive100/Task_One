def get_data_object_list(connection_url, data_object, select_query, *query_arguments):
    import pyodbc
    data_object_list = []
    cursor_object = None
    connection_object = None
    try:
        connection_object = pyodbc.connect(connection_url)
        if connection_object:
            cursor_object = connection_object.cursor()
            if cursor_object:
                cursor_object.execute(select_query, *query_arguments)
                for row_object in cursor_object.fetchall():
                    # print(row_object)
                    data = list(row_object)
                    data_object_list.append(data_object(*data))
                cursor_object.close()
            else:
                print('cursor object is null')
            connection_object.close()
        else:
            print('Connection object is null')
    except Exception as e:
        print("Exception while fetching records from SQL Server")
        print(e)
        if cursor_object is not None:
            cursor_object.close()
        if connection_object is not None:
            connection_object.close()
    return data_object_list


def insert_data_object_list(connection_url, insert_query, data_list):
    import pyodbc

    print(data_list)
    cursor_object = None
    connection_object = None
    try:
        connection_object = pyodbc.connect(connection_url)
        cursor_object = connection_object.cursor()
        for data in data_list:
            cursor_object.execute(insert_query, data)
        connection_object.commit()
    except Exception as e:
        print("Exception while inserting records in SQL Server")
        print(e)
        if cursor_object is not None:
            cursor_object.close()
        if connection_object is not None:
            connection_object.close()


class JobParameterIngestion(object):

    def __init__(self, insert_gmt_timestamp, batch_number, uow_id, job_name, lz_table_name, stage_table_name, hst_table_name, number_of_days_count, active_flag, delete_flag, release_number, pattern, bow_id, devconn_id, itgconn_id, prodconn_id, filedelimiter, dry_run_flag):
        self._insert_gmt_timestamp = insert_gmt_timestamp
        self._batch_number = batch_number
        self._uow_id = uow_id
        self._job_name = job_name
        self._lz_table_name = lz_table_name
        self._stage_table_name = stage_table_name
        self._hst_table_name = hst_table_name
        # self._source_query_text = source_query_text
        self._number_of_days_count = number_of_days_count
        self._active_flag = active_flag
        self._delete_flag = delete_flag
        self._release_number = release_number
        self._pattern = pattern
        self._bow_id = bow_id
        self._devconn_id = devconn_id
        self._itgconn_id = itgconn_id
        self._prodconn_id = prodconn_id
        self._filedelimiter = filedelimiter
        # self._dryrunquery = dryrunquery
        self._dry_run_flag = dry_run_flag

    @property
    def insert_gmt_timestamp(self):
        return self._insert_gmt_timestamp

    @insert_gmt_timestamp.setter
    def insert_gmt_timestamp(self, value):
        self._insert_gmt_timestamp = value

    @property
    def batch_number(self):
        return self._batch_number

    @batch_number.setter
    def batch_number(self, value):
        self._batch_number = value

    @property
    def uow_id(self):
        return self._uow_id

    @uow_id.setter
    def uow_id(self, value):
        self._uow_id = value

    @property
    def job_name(self):
        return self._job_name

    @job_name.setter
    def job_name(self, value):
        self._job_name = value

    @property
    def lz_table_name(self):
        return self._lz_table_name

    @lz_table_name.setter
    def lz_table_name(self, value):
        self._lz_table_name = value

    @property
    def stage_table_name(self):
        return self._stage_table_name

    @stage_table_name.setter
    def stage_table_name(self, value):
        self._stage_table_name = value

    @property
    def hst_table_name(self):
        return self._hst_table_name

    @hst_table_name.setter
    def hst_table_name(self, value):
        self._hst_table_name = value

    # @property
    # def source_query_text(self):
    #     return self._source_query_text
    #
    # @source_query_text.setter
    # def source_query_text(self, value):
    #     self._source_query_text = value

    @property
    def number_of_days_count(self):
        return self._number_of_days_count

    @number_of_days_count.setter
    def number_of_days_count(self, value):
        self._number_of_days_count = value

    @property
    def active_flag(self):
        return self._active_flag

    @active_flag.setter
    def active_flag(self, value):
        self._active_flag = value

    @property
    def delete_flag(self):
        return self._delete_flag

    @delete_flag.setter
    def delete_flag(self, value):
        self._delete_flag = value

    @property
    def release_number(self):
        return self._release_number

    @release_number.setter
    def release_number(self, value):
        self._release_number = value

    @property
    def pattern(self):
        return self._pattern

    @pattern.setter
    def pattern(self, value):
        self._pattern = value

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def devconn_id(self):
        return self._devconn_id

    @devconn_id.setter
    def devconn_id(self, value):
        self._devconn_id = value

    @property
    def itgconn_id(self):
        return self._itgconn_id

    @itgconn_id.setter
    def itgconn_id(self, value):
        self._itgconn_id = value

    @property
    def prodconn_id(self):
        return self._prodconn_id

    @prodconn_id.setter
    def prodconn_id(self, value):
        self._prodconn_id = value

    @property
    def filedelimiter(self):
        return self._filedelimiter

    @filedelimiter.setter
    def filedelimiter(self, value):
        self._filedelimiter = value

    # @property
    # def dryrunquery(self):
    #     return self._dryrunquery
    #
    # @dryrunquery.setter
    # def dryrunquery(self, value):
    #     self._dryrunquery = value

    @property
    def dry_run_flag(self):
        return self._dry_run_flag

    @dry_run_flag.setter
    def dry_run_flag(self, value):
        self._dry_run_flag = value

    @staticmethod
    def populate_job_parameter_ingestion(self, data):
        return JobParameterIngestion(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17])


class FileControlIngestion(object):

    def __init__(self, batch_id, bow_id, uow_id, source_file_path, lz_table_name, hst_table_name, reject_table_name, file_pattern, timestamp_pattern, source_system_identifier, extension, delimiter, type_of_load, is_part_file, is_compressed, compression_format, is_file_validation, is_audit_file, is_control_file, is_header_included, hdfs_good_path, hdfs_reject_path, file_landing_path, log_path, hive_schema_name, logical_flag, logical_flag_value, del_column_list, active_flag, job_name, is_rev_id, is_src_sys_cd_seq, timestamp_format, archive_file_path, audit_code, xlsx_sheet_name, bow_name, timestamp_value_format, partition_column, increment_value):
        self._batch_id = batch_id
        self._bow_id = bow_id
        self._uow_id = uow_id
        self._source_file_path = source_file_path
        self._lz_table_name = lz_table_name
        self._hst_table_name = hst_table_name
        self._reject_table_name = reject_table_name
        self._file_pattern = file_pattern
        self._timestamp_pattern = timestamp_pattern
        self._source_system_identifier = source_system_identifier
        self._extension = extension
        self._delimiter = delimiter
        self._type_of_load = type_of_load
        self._is_part_file = is_part_file
        self._is_compressed = is_compressed
        self._compression_format = compression_format
        self._is_file_validation = is_file_validation
        self._is_audit_file = is_audit_file
        self._is_control_file = is_control_file
        self._is_header_included = is_header_included
        self._hdfs_good_path = hdfs_good_path
        self._hdfs_reject_path = hdfs_reject_path
        self._file_landing_path = file_landing_path
        self._log_path = log_path
        self._hive_schema_name = hive_schema_name
        self._logical_flag = logical_flag
        self._logical_flag_value = logical_flag_value
        self._del_column_list = del_column_list
        self._active_flag = active_flag
        self._job_name = job_name
        self._is_rev_id = is_rev_id
        self._is_src_sys_cd_seq = is_src_sys_cd_seq
        self._timestamp_format = timestamp_format
        # self._zip_file_pattern = zip_file_pattern
        self._archive_file_path = archive_file_path
        self._audit_code = audit_code
        self._xlsx_sheet_name = xlsx_sheet_name
        self._bow_name = bow_name
        self._timestamp_value_format = timestamp_value_format
        self._partition_column = partition_column
        self._increment_value = increment_value

    @property
    def batch_id(self):
        return self._batch_id

    @batch_id.setter
    def batch_id(self, value):
        self._batch_id = value

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def uow_id(self):
        return self._uow_id

    @uow_id.setter
    def uow_id(self, value):
        self._uow_id = value

    @property
    def source_file_path(self):
        return self._source_file_path

    @source_file_path.setter
    def source_file_path(self, value):
        self._source_file_path = value

    @property
    def lz_table_name(self):
        return self._lz_table_name

    @lz_table_name.setter
    def lz_table_name(self, value):
        self._lz_table_name = value

    @property
    def hst_table_name(self):
        return self._hst_table_name

    @hst_table_name.setter
    def hst_table_name(self, value):
        self._hst_table_name = value

    @property
    def reject_table_name(self):
        return self._reject_table_name

    @reject_table_name.setter
    def reject_table_name(self, value):
        self._reject_table_name = value

    @property
    def file_pattern(self):
        return self._file_pattern

    @file_pattern.setter
    def file_pattern(self, value):
        self._file_pattern = value

    @property
    def timestamp_pattern(self):
        return self._timestamp_pattern

    @timestamp_pattern.setter
    def timestamp_pattern(self, value):
        self._timestamp_pattern = value

    @property
    def source_system_identifier(self):
        return self._source_system_identifier

    @source_system_identifier.setter
    def source_system_identifier(self, value):
        self._source_system_identifier = value

    @property
    def extension(self):
        return self._extension

    @extension.setter
    def extension(self, value):
        self._extension = value

    @property
    def delimiter(self):
        return self._delimiter

    @delimiter.setter
    def delimiter(self, value):
        self._delimiter = value

    @property
    def type_of_load(self):
        return self._type_of_load

    @type_of_load.setter
    def type_of_load(self, value):
        self._type_of_load = value

    @property
    def is_part_file(self):
        return self._is_part_file

    @is_part_file.setter
    def is_part_file(self, value):
        self._is_part_file = value

    @property
    def is_compressed(self):
        return self._is_compressed

    @is_compressed.setter
    def is_compressed(self, value):
        self._is_compressed = value

    @property
    def compression_format(self):
        return self._compression_format

    @compression_format.setter
    def compression_format(self, value):
        self._compression_format = value

    @property
    def is_file_validation(self):
        return self._is_file_validation

    @is_file_validation.setter
    def is_file_validation(self, value):
        self._is_file_validation = value

    @property
    def is_audit_file(self):
        return self._is_audit_file

    @is_audit_file.setter
    def is_audit_file(self, value):
        self._is_audit_file = value

    @property
    def is_control_file(self):
        return self._is_control_file

    @is_control_file.setter
    def is_control_file(self, value):
        self._is_control_file = value

    @property
    def is_header_included(self):
        return self._is_header_included

    @is_header_included.setter
    def is_header_included(self, value):
        self._is_header_included = value

    @property
    def hdfs_good_path(self):
        return self._hdfs_good_path

    @hdfs_good_path.setter
    def hdfs_good_path(self, value):
        self._hdfs_good_path = value

    @property
    def hdfs_reject_path(self):
        return self._hdfs_reject_path

    @hdfs_reject_path.setter
    def hdfs_reject_path(self, value):
        self._hdfs_reject_path = value

    @property
    def file_landing_path(self):
        return self._file_landing_path

    @file_landing_path.setter
    def file_landing_path(self, value):
        self._file_landing_path = value

    @property
    def log_path(self):
        return self._log_path

    @log_path.setter
    def log_path(self, value):
        self._log_path = value

    @property
    def hive_schema_name(self):
        return self._hive_schema_name

    @hive_schema_name.setter
    def hive_schema_name(self, value):
        self._hive_schema_name = value

    @property
    def logical_flag(self):
        return self._logical_flag

    @logical_flag.setter
    def logical_flag(self, value):
        self._logical_flag = value

    @property
    def logical_flag_value(self):
        return self._logical_flag_value

    @logical_flag_value.setter
    def logical_flag_value(self, value):
        self._logical_flag_value = value

    @property
    def del_column_list(self):
        return self._del_column_list

    @del_column_list.setter
    def del_column_list(self, value):
        self._del_column_list = value

    @property
    def active_flag(self):
        return self._active_flag

    @active_flag.setter
    def active_flag(self, value):
        self._active_flag = value

    @property
    def job_name(self):
        return self._job_name

    @job_name.setter
    def job_name(self, value):
        self._job_name = value

    @property
    def is_rev_id(self):
        return self._is_rev_id

    @is_rev_id.setter
    def is_rev_id(self, value):
        self._is_rev_id = value

    @property
    def is_src_sys_cd_seq(self):
        return self._is_src_sys_cd_seq

    @is_src_sys_cd_seq.setter
    def is_src_sys_cd_seq(self, value):
        self._is_src_sys_cd_seq = value

    @property
    def timestamp_format(self):
        return self._timestamp_format

    @timestamp_format.setter
    def timestamp_format(self, value):
        self._timestamp_format = value

    @property
    def archive_file_path(self):
        return self._archive_file_path

    @archive_file_path.setter
    def archive_file_path(self, value):
        self._archive_file_path = value

    @property
    def audit_code(self):
        return self._audit_code

    @audit_code.setter
    def audit_code(self, value):
        self._audit_code = value

    @property
    def xlsx_sheet_name(self):
        return self._xlsx_sheet_name

    @xlsx_sheet_name.setter
    def xlsx_sheet_name(self, value):
        self._xlsx_sheet_name = value

    @property
    def bow_name(self):
        return self._bow_name

    @bow_name.setter
    def bow_name(self, value):
        self._bow_name = value

    @property
    def timestamp_value_format(self):
        return self._timestamp_value_format

    @timestamp_value_format.setter
    def timestamp_value_format(self, value):
        self._timestamp_value_format = value

    @property
    def partition_column(self):
        return self._partition_column

    @partition_column.setter
    def partition_column(self, value):
        self._partition_column = value

    @property
    def increment_value(self):
        return self._increment_value

    @increment_value.setter
    def increment_value(self, value):
        self._increment_value = value

    @staticmethod
    def populate_file_control_ingestion(self, data):
        return FileControlIngestion(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17], data[18], data[19], data[20], data[21], data[22], data[23], data[24], data[25], data[26], data[27], data[28], data[29], data[30], data[31], data[32], data[33], data[34], data[35], data[36], data[37], data[38], data[39])


class BowCdcAuxControlR01(object):

    def __init__(self, bow_id, bow_name, cdc_start_timestamp, cdc_end_timestamp, prev_cdc_start_timestamp, prev_cdc_end_timestamp, uow_unique_id, cdc_type_description, change_data_capture_last_sequence_number, previous_change_data_capture_last_sequence_number, insert_gmt_timestamp, query_id):
        self._bow_id = bow_id
        self._bow_name = bow_name
        self._cdc_start_timestamp = cdc_start_timestamp
        self._cdc_end_timestamp = cdc_end_timestamp
        self._prev_cdc_start_timestamp = prev_cdc_start_timestamp
        self._prev_cdc_end_timestamp = prev_cdc_end_timestamp
        self._uow_unique_id = uow_unique_id
        self._cdc_type_description = cdc_type_description
        self._change_data_capture_last_sequence_number = change_data_capture_last_sequence_number
        self._previous_change_data_capture_last_sequence_number = previous_change_data_capture_last_sequence_number
        self._insert_gmt_timestamp = insert_gmt_timestamp
        self._query_id = query_id

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def bow_name(self):
        return self._bow_name

    @bow_name.setter
    def bow_name(self, value):
        self._bow_name = value

    @property
    def cdc_start_timestamp(self):
        return self._cdc_start_timestamp

    @cdc_start_timestamp.setter
    def cdc_start_timestamp(self, value):
        self._cdc_start_timestamp = value

    @property
    def cdc_end_timestamp(self):
        return self._cdc_end_timestamp

    @cdc_end_timestamp.setter
    def cdc_end_timestamp(self, value):
        self._cdc_end_timestamp = value

    @property
    def prev_cdc_start_timestamp(self):
        return self._prev_cdc_start_timestamp

    @prev_cdc_start_timestamp.setter
    def prev_cdc_start_timestamp(self, value):
        self._prev_cdc_start_timestamp = value

    @property
    def prev_cdc_end_timestamp(self):
        return self._prev_cdc_end_timestamp

    @prev_cdc_end_timestamp.setter
    def prev_cdc_end_timestamp(self, value):
        self._prev_cdc_end_timestamp = value

    @property
    def uow_unique_id(self):
        return self._uow_unique_id

    @uow_unique_id.setter
    def uow_unique_id(self, value):
        self._uow_unique_id = value

    @property
    def cdc_type_description(self):
        return self._cdc_type_description

    @cdc_type_description.setter
    def cdc_type_description(self, value):
        self._cdc_type_description = value

    @property
    def change_data_capture_last_sequence_number(self):
        return self._change_data_capture_last_sequence_number

    @change_data_capture_last_sequence_number.setter
    def change_data_capture_last_sequence_number(self, value):
        self._change_data_capture_last_sequence_number = value

    @property
    def previous_change_data_capture_last_sequence_number(self):
        return self._previous_change_data_capture_last_sequence_number

    @previous_change_data_capture_last_sequence_number.setter
    def previous_change_data_capture_last_sequence_number(self, value):
        self._previous_change_data_capture_last_sequence_number = value

    @property
    def insert_gmt_timestamp(self):
        return self._insert_gmt_timestamp

    @insert_gmt_timestamp.setter
    def insert_gmt_timestamp(self, value):
        self._insert_gmt_timestamp = value

    @property
    def query_id(self):
        return self._query_id

    @query_id.setter
    def query_id(self, value):
        self._query_id = value

    @staticmethod
    def populate_bow_cdc_aux_control_r01(self, data):
        return BowCdcAuxControlR01(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11])


class LogControlR01(object):

    def __init__(self, bow_id, sbow_id, uow_id, load_job_number, run_start_timestamp, run_end_timestamp, cdc_start_timestamp, cdc_end_timestamp, status, batch_id, prev_cdc_end_timestamp, prev_cdc_start_timestamp, source_count, target_count, batch_number, job_name, record_delete_count, insert_gmt_timestamp):
        self._bow_id = bow_id
        self._sbow_id = sbow_id
        self._uow_id = uow_id
        self._load_job_number = load_job_number
        self._run_start_timestamp = run_start_timestamp
        self._run_end_timestamp = run_end_timestamp
        self._cdc_start_timestamp = cdc_start_timestamp
        self._cdc_end_timestamp = cdc_end_timestamp
        self._status = status
        self._batch_id = batch_id
        self._prev_cdc_end_timestamp = prev_cdc_end_timestamp
        self._prev_cdc_start_timestamp = prev_cdc_start_timestamp
        self._source_count = source_count
        self._target_count = target_count
        self._batch_number = batch_number
        self._job_name = job_name
        self._record_delete_count = record_delete_count
        self._insert_gmt_timestamp = insert_gmt_timestamp

    @property
    def bow_id(self):
        return self._bow_id

    @bow_id.setter
    def bow_id(self, value):
        self._bow_id = value

    @property
    def sbow_id(self):
        return self._sbow_id

    @sbow_id.setter
    def sbow_id(self, value):
        self._sbow_id = value

    @property
    def uow_id(self):
        return self._uow_id

    @uow_id.setter
    def uow_id(self, value):
        self._uow_id = value

    @property
    def load_job_number(self):
        return self._load_job_number

    @load_job_number.setter
    def load_job_number(self, value):
        self._load_job_number = value

    @property
    def run_start_timestamp(self):
        return self._run_start_timestamp

    @run_start_timestamp.setter
    def run_start_timestamp(self, value):
        self._run_start_timestamp = value

    @property
    def run_end_timestamp(self):
        return self._run_end_timestamp

    @run_end_timestamp.setter
    def run_end_timestamp(self, value):
        self._run_end_timestamp = value

    @property
    def cdc_start_timestamp(self):
        return self._cdc_start_timestamp

    @cdc_start_timestamp.setter
    def cdc_start_timestamp(self, value):
        self._cdc_start_timestamp = value

    @property
    def cdc_end_timestamp(self):
        return self._cdc_end_timestamp

    @cdc_end_timestamp.setter
    def cdc_end_timestamp(self, value):
        self._cdc_end_timestamp = value

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value

    @property
    def batch_id(self):
        return self._batch_id

    @batch_id.setter
    def batch_id(self, value):
        self._batch_id = value

    @property
    def prev_cdc_end_timestamp(self):
        return self._prev_cdc_end_timestamp

    @prev_cdc_end_timestamp.setter
    def prev_cdc_end_timestamp(self, value):
        self._prev_cdc_end_timestamp = value

    @property
    def prev_cdc_start_timestamp(self):
        return self._prev_cdc_start_timestamp

    @prev_cdc_start_timestamp.setter
    def prev_cdc_start_timestamp(self, value):
        self._prev_cdc_start_timestamp = value

    @property
    def source_count(self):
        return self._source_count

    @source_count.setter
    def source_count(self, value):
        self._source_count = value

    @property
    def target_count(self):
        return self._target_count

    @target_count.setter
    def target_count(self, value):
        self._target_count = value

    @property
    def batch_number(self):
        return self._batch_number

    @batch_number.setter
    def batch_number(self, value):
        self._batch_number = value

    @property
    def job_name(self):
        return self._job_name

    @job_name.setter
    def job_name(self, value):
        self._job_name = value

    @property
    def record_delete_count(self):
        return self._record_delete_count

    @record_delete_count.setter
    def record_delete_count(self, value):
        self._record_delete_count = value

    @property
    def insert_gmt_timestamp(self):
        return self._insert_gmt_timestamp

    @insert_gmt_timestamp.setter
    def insert_gmt_timestamp(self, value):
        self._insert_gmt_timestamp = value

    @staticmethod
    def populate_log_control_r01(self, data):
        return LogControlR01(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15], data[16], data[17])
