#!/bin/sh
cd /executables/
pbrun su - crmsowp
kinit -kt /etc/security/app-sa-keytabs/crmsowp_prod.keytab crmsowp@HADOOPPROD.AUSTIN.HPICORP.NET

export HADOOP_CLASSPATH="/executables/salesfedw/lib/ojdbc6.jar"

if [ $9 -ne 1 ];
then
        {
        execute_command="sqoop import -Dorg.apache.sqoop.splitter.allow_text_splitter=true --verbose --connect 'jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=$1)(port=$2))(connect_data=(service_name=$3)))' --username $4 --password $5 -query $6 --direct --split-by 'cast($7 as NUMBER(25,10))' --delete-target-dir --target-dir $8 --fields-terminated-by '\\034' --lines-terminated-by '\\n' --hive-delims-replacement ' ' -m $9 "
        }
else
        {
        execute_command="sqoop import -Dorg.apache.sqoop.splitter.allow_text_splitter=true --verbose --connect 'jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=$1)(port=$2))(connect_data=(service_name=$3)))' --username $4 --password $5 -query $6 --direct --delete-target-dir --target-dir $8 --fields-terminated-by '\\034' --lines-terminated-by '\\n' --hive-delims-replacement ' ' -m 1 "
        }
fi
eval $execute_command
