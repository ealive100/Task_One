#!/bin/sh 

echo "Taking backup of '/executables/salesfedw/' dir with current timestamp"
current_time=$(date "+%Y%m%d%H%M%S")
cd /executables/
mkdir salesfedw_bckup_$current_time
cp -rf /executables/salesfedw/* /executables/salesfedw_bckup_$current_time/
chmod 755 /executables/salesfedw_bckup_$current_time
echo "Created backup dir with name /executables/salesfedw_bckup_"$current_time
