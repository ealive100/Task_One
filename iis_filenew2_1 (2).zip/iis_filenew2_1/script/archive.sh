#!/bin/sh
source_path=$1
filename=$2
target_path=$3
enc_string="hadoop fs -copyFromLocal $source_path$filename $target_path"
echo $enc_string
#if [ $filename == "" ] ; then 
#echo "File not found"
#exit 0
#else
##eval $enc_string
#fi
