#!/bin/sh 

dir_path=${1}
#hdfs://hdpdevnn/loading/edw/history/data/so_dtl_rpt_f

if [[ "$#" -ne 1 ]];
	then
       echo "Please pass in the HDFS directory path as argument"
	   exit 0
	else
	total_count=0
	for i in `hdfs dfs -ls -R $dir_path | awk '{print $8}'`; 
	do echo "File:" $i ; 
	count="$(hdfs dfs -cat $i | wc -l)";
	echo "Count:" $count
	total_count=$((total_count+count))
	done;
	echo "Total_Count:" $total_count
fi
#done;
