#!/bin/sh 

file_location=${1}
target_location=${2}
pattern=${3}

if [[ "$#" -ne 3 ]];
	then
       echo "Please pass in the 1.Source_LZ4_Path 2.Target_LZ4_PATH 3.Pattern as arguments"
	   exit 0
	else
	   echo "Please wait while the lz4 file are getting created with timestamp..."
	   cp $1$3*.HDFS.lz4 $2  
	   cd $2
	   chmod 777 *.lz4
	   for file in $2/$3*.HDFS.lz4; do
	   file_name=$(basename -- "$file")
	   echo "complete file name $file_name"
	   file_without_ext="${file_name%.*}"
	   file_without_dot="${file_without_ext//./_}"
	   echo $file_without_dot
	   echo "file name without ext $file_without_ext"
	   extension="${file_name##*.}"
	   echo "Extension $extension"
	   current_time=$(date "+%Y%m%d%H%M%S%4N")
	   echo $current_time
	   new_lz4_file=${file_without_dot}_${current_time}.${extension}
	   mv $file_name $2$new_lz4_file
	   #cp $3* $2$new_lz4_file
	   echo "New files are $new_lz4_file"
	   done
	   
fi
