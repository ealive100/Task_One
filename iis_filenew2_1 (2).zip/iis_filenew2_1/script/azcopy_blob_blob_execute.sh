#!/bin/bash
export https_proxy=web-proxy.austin.hpicorp.net:8080
account_name=$1
container=$2
source_file_location_blob=$3
account_key=$4
journalfilepath=$5
blob_archieve_location=$6
filepattern=$7
if [ "$filepattern" != "ALL" ] ; then
includeOption=" --include "$filepattern
else
echo "No File Patteren Specified, download all fiels to edl"
fi
echo "src_location:"$source_file_location_blob
echo "account_name:"$account_name
echo "container:"$container
echo "account_key:"$account_key
echo "blob_archieve_location:"$blob_archieve_location
echo "journalfilepath:"$journalfilepath
if [ "$source_file_location_blob" = "NULL" ] ; then
azcopycmd="azcopy --source https://$account_name.blob.core.windows.net/$container --destination https://$account_name.blob.core.windows.net/$blob_archieve_location --source-key $account_key --dest-key $account_key --recursive --resume $journalfilepath --quiet"$includeOption
echo "----AZCOPY COMMAND----"$azcopycmd
$azcopycmd
else
azcopycmd_storagefolder="azcopy --source https://$account_name.blob.core.windows.net/$container/$source_file_location_blob --destination https://$account_name.blob.core.windows.net/$blob_archieve_location --source-key $account_key --dest-key $account_key --recursive --resume $journalfilepath --quiet"$includeOption
echo "----AZCOPY COMMAND WITH STORAGE FOLDER: ----"$azcopycmd_storagefolder
$azcopycmd_storagefolder
fi
exit 0
