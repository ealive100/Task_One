#!/bin/bash
export https_proxy=web-proxy.austin.hpicorp.net:8080
target_edl_folder_location=$1
account_name=$2
container=$3
storage_folder=$4
account_key=$5
journalfilepath=$6
#filepattern=$7
#if [ "$filepattern" != "ALL" ] ; then
#includeOption=" --include "$filepattern
#else
#echo "No File Patteren Specified, download all fiels to edl"
#fi
#echo "target_edl_folder_location:"$target_edl_folder_location
#echo "account_name:"$account_name
#echo "container:"$container
#echo "account_key:"$account_key
#echo "storage_folder:"$storage_folder
#echo "journalfilepath:"$journalfilepath
if [ "$storage_folder" = "NULL" ] ; then
azcopycmd="azcopy --source https://$account_name.blob.core.windows.net/$container --destination $target_edl_folder_location --source-key $account_key --recursive --resume $journalfilepath --quiet"
echo "AZCOPY COMMAND:"$azcopycmd
$azcopycmd
else
azcopycmd_storagefolder="azcopy --source https://$account_name.blob.core.windows.net/$container/$storage_folder --destination $target_edl_folder_location --source-key $account_key --recursive --resume $journalfilepath --quiet"
echo "AZCOPY COMMAND WITH STORAGE FOLDER:"$azcopycmd_storagefolder
$azcopycmd_storagefolder
fi

