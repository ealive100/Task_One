#!/bin/sh
source /tmp/executables/salesfedw/configuration/sqoop_config.confg
cd /
eval $pbrun_command
eval $kinit_command

source_DB=${10}
echo $source_DB

jar_path="${source_DB}_jar_path"
jar_path=${!jar_path}

export HADOOP_CLASSPATH="$jar_path"

connection_string="${source_DB}_connection"
connection_string=${!connection_string}

split_column="${source_DB}_split_column"
split_column=${!split_column}


if [ $9 -ne 1 ];
then
        {
        execute_command="sqoop import -Dorg.apache.sqoop.splitter.allow_text_splitter=true --verbose --connect '$connection_string' --username $4 --password $5 -query $6 --direct --split-by '$split_column' --delete-target-dir --target-dir $8 --fields-terminated-by '\\034' --lines-terminated-by '\\n' --hive-delims-replacement ' ' -m $9 "
        }
else
        {
        execute_command="sqoop import -Dorg.apache.sqoop.splitter.allow_text_splitter=true --verbose --connect '$connection_string' --username $4 --password $5 -query $6 --direct --delete-target-dir --target-dir $8 --fields-terminated-by '\\034' --lines-terminated-by '\\n' --hive-delims-replacement ' ' -m 1 "
        }
fi

eval $execute_command


