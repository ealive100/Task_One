#!/bin/sh
aes_bits_mode=$1
target_location=$2
filename=$3
pass_key=$4
landing_path=$5
target_filename=$6
#echo $filename
#target_filename=$(echo $filename | awk '{ print substr( $0, 0, length($0)-4 ) }')
#echo $target_filename
enc_string="openssl $aes_bits_mode -d -a -in $target_location$filename -k $pass_key -out $landing_path$target_filename.zip"
echo $enc_string
if [ $target_filename == "" ] ; then 
echo "File not found"
exit 0
else
eval $enc_string
fi
