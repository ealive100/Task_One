from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, unix_timestamp, col, lower, when, trim, regexp_replace, from_unixtime, to_timestamp
from pyspark.sql.types import StructField, StructType, IntegerType, StringType, TimestampType, DecimalType
from datetime import datetime
import sys, os, re, time
import data_quality_helper as file_helper
import file_validation
import table_validation
import xlrd

batch_id_arg = sys.argv[1]
bow_id_arg = sys.argv[2]
load_number_arg = sys.argv[3]
batch_exec_id_arg = sys.argv[4]
sbow_id_arg = sys.argv[5]
file_config = sys.argv[6]
field_validation = sys.argv[7]
db_password_arg = sys.argv[8]
abcr_database_type = sys.argv[9]
unicode_arr = db_password_arg.split('@')
secret_pass = [chr(int(x)) for x in unicode_arr]
db_password = ''.join(secret_pass)

print("Arguments are : arg 1 (batch_id) " + batch_id_arg)
print("Arguments are : arg 2 (bow_id) " + bow_id_arg)
print("Arguments are : arg 3 (load_number) " + load_number_arg)
print("Arguments are : arg 4 (batch_exec_id) " + batch_exec_id_arg)
print("Arguments are : arg 5 (sbow_id) " + sbow_id_arg)
print("Arguments are : arg 6 (file_config) " + file_config)
print("Arguments are : arg 7 (field_validation) " + field_validation)
print("Arguments are : arg 8 (db_password) " + db_password_arg)
print("Arguments are : arg 9 (abcr_database_type) " + abcr_database_type)

file_load_hst_schema = StructType([StructField("bow_id", IntegerType(), True), StructField("batch_id", IntegerType(), True), StructField("uow_id", IntegerType(), True), StructField("source_file_path", StringType(), True), StructField("file_landing_path", StringType(), True), StructField("file_name_processed", StringType(), True), StructField("batch_execution_id", StringType(), True), StructField("file_archive_path", StringType(), True)])

app_name = ''
if field_validation == '2':
    app_name = "File_and_Field_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'
else:
    app_name = "File_DQ_FOR_BATCH_ID[" + batch_id_arg + ']BOW_ID[' + bow_id_arg + ']'

spark_session_obj = SparkSession.builder.enableHiveSupport().appName(app_name).getOrCreate()
spark_session_obj.sparkContext.setLogLevel("ERROR")
log4jLogger = spark_session_obj.sparkContext._jvm.org.apache.log4j
file_logger = log4jLogger.LogManager.getLogger(app_name)


def update_data_into_aux_control(spark_session, default_db, aux_control_record, file_config, abcr_db_password, hive_or_sql_server=0):

    if hive_or_sql_server == 1:
        aux_control_schema = StructType(
            [StructField("bow_id", IntegerType(), True), StructField("bow_name", StringType(), True),
             StructField("cdc_start_timestamp", StringType(), True), StructField("cdc_end_timestamp", StringType(), True),
             StructField("prev_cdc_start_timestamp", TimestampType(), True),
             StructField("prev_cdc_end_timestamp", TimestampType(), True), StructField("uow_unique_id", StringType(), True),
             StructField("cdc_type_description", StringType(), True),
             StructField("change_data_capture_last_sequence_number", DecimalType(), True),
             StructField("previous_change_data_capture_last_sequence_number", DecimalType(), True),
             StructField("insert_gmt_timestamp", StringType(), True), StructField("batch_execution_id", StringType(), True),
             StructField("batch_id", IntegerType(), True)])
        aux_ctrl_df = file_helper.create_df(spark_session, aux_control_record, aux_control_schema)

        aux_ctrl_table_name = default_db + file_config['AUX_CONTROL_TABLE']
        aux_ctrl_df = aux_ctrl_df.select('bow_id', 'bow_name',
                                         unix_timestamp('cdc_start_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                             TimestampType()).alias("cdc_start_timestamp"),
                                         unix_timestamp('cdc_end_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                             TimestampType()).alias("cdc_end_timestamp"), 'prev_cdc_start_timestamp',
                                         'prev_cdc_end_timestamp', 'uow_unique_id', 'cdc_type_description',
                                         'change_data_capture_last_sequence_number',
                                         'previous_change_data_capture_last_sequence_number',
                                         unix_timestamp('insert_gmt_timestamp', "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                             TimestampType()).alias("insert_gmt_timestamp"), 'batch_execution_id',
                                         'batch_id')
        aux_ctrl_df.write.mode("append").format("text").insertInto(aux_ctrl_table_name, overwrite=False)
    else:
        aux_control_record = [(row[2], row[3], row[6]) for row in aux_control_record]
        update_query = file_config['UPDATE_QUERY_AUX_CONTROL_R01']
        file_helper.insert_data_into_abcr_db(file_config, update_query, aux_control_record, abcr_db_password)


def ingest_data_into_log_control(spark_session, log_control_record, file_config, abcr_db_password, hive_or_sql_server=0):
    if hive_or_sql_server == 1:
        log_control_schema = StructType(
            [StructField("bow_id", IntegerType(), True), StructField("sbow_id", IntegerType(), True),
             StructField("uow_id", IntegerType(), True),
             StructField("load_job_number", StringType(), True), StructField("run_start_timestamp", StringType(), True),
             StructField("run_end_timestamp", StringType(), True),
             StructField("cdc_start_timestamp", TimestampType(), True),
             StructField("cdc_end_timestamp", TimestampType(), True), StructField("status", StringType(), True),
             StructField("batch_id", StringType(), True), StructField("prev_cdc_end_timestamp", TimestampType(), True),
             StructField("prev_cdc_start_timestamp", TimestampType(), True),
             StructField("source_count", IntegerType(), True), StructField("target_count", IntegerType(), True),
             StructField("batch_number", IntegerType(), True),
             StructField("job_name", StringType(), True), StructField("record_delete_count", IntegerType(), True),
             StructField("insert_gmt_timestamp", StringType(), True)])
        log_ctrl_table_name = pre_table_name + props['LOG_CONTROL_TABLE']
        df_log_control_data = file_helper.create_df(spark_session, log_control_record, log_control_schema)
        df_log_control_data = df_log_control_data.select('bow_id', 'sbow_id', 'uow_id', 'load_job_number',
                                                         unix_timestamp('run_start_timestamp',
                                                                        "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                             TimestampType()).alias("run_start_timestamp"),
                                                         unix_timestamp('run_end_timestamp',
                                                                        "yyyy-MM-dd HH:mm:ss.SSS").cast(
                                                             TimestampType()).alias("run_end_timestamp"),
                                                         'cdc_start_timestamp', 'cdc_end_timestamp', 'status', 'batch_id',
                                                         'prev_cdc_end_timestamp', 'prev_cdc_start_timestamp',
                                                         'source_count', 'target_count', 'batch_number', 'job_name',
                                                         'record_delete_count', unix_timestamp('insert_gmt_timestamp',
                                                                                               "yyyy-MM-dd HH:mm:ss.SSS").cast(
                TimestampType()).alias("insert_gmt_timestamp"))

        df_log_control_data.write.mode("append").format("text").insertInto(log_ctrl_table_name, overwrite=False)
    else:
        log_control_record = [tuple(row) for row in log_control_record]
        insert_query = file_config['INSERT_QUERY_LOG_CONTROL_R01']
        file_helper.insert_data_into_abcr_db(file_config, insert_query, log_control_record, abcr_db_password)


def read_data_file(spark_session, data_file, schema, parameter_obj, source_file):
    def blank_as_null(x):
        return when(trim(col(x)) != "", col(x)).otherwise(None)

    #try:
    #    chr(int(parameter_obj.delimiter))
    #except ValueError:
    #    file_logger.debug('Invalid column separator.' + parameter_obj.delimiter)

    file_ext = parameter_obj.extension
    file_logger.debug('DATA file is of type ' + file_ext)

    if file_ext.lower() == props['XLSX'].lower():
        set_header = "false"
        if parameter_obj.is_header_included.lower() == 'y':
            set_header = "true"

        xls = xlrd.open_workbook(source_file, on_demand=True)
        sheet_name = xls.sheet_names()[0]
        excel_data_df = spark_session.read.format("com.crealytics.spark.excel").option("location", data_file).option("sheetName", sheet_name).option("addColorColumns", "false").option("useHeader", set_header).option("spark.read.simpleMode", "true").load("com.databricks.spark.csv").toDF(*schema)
        excel_data_df = excel_data_df.na.drop(how="all")
        return excel_data_df

    elif file_ext.lower() == props['FILE_ENDSWITH_DAT'].lower() or file_ext.lower() == props['LZ4'].lower() or file_ext.lower() == props['TXT'].lower():
        if parameter_obj.is_part_file.lower() == 'y':
            dir_name = '/'.join(data_file.split('/')[:-1])
            file_data_df = spark_session.createDataFrame(spark_session.sparkContext.textFile(dir_name).map(lambda x: x.split(chr(int(parameter_obj.delimiter))))).toDF(*schema)
        else:
            file_data_df = spark_session.createDataFrame(spark_session.sparkContext.textFile(data_file).map(lambda x: x.split(chr(int(parameter_obj.delimiter))))).toDF(*schema)

        exprs = [blank_as_null(x).alias(x) for x in file_data_df.columns]
        file_data_df = file_data_df.select(*exprs)

        return file_data_df

    elif file_ext.lower() == props['CSV'].lower():
        file_data_df = spark_session.read.format("com.databricks.spark.csv").option("encoding", "UTF-8").option("ignoreLeadingWhiteSpace", "true").option("ignoreTrailingWhiteSpace", "true").option("treatEmptyValuesAsNulls", "true").option("inferSchema", "true").option("escape", '"').option("quote", "\"").option("multiLine", "true").load(data_file).toDF(*schema)
        return file_data_df

    else:
        file_logger.debug('DATA file type of ' + file_ext + ' not defined. So exiting the process.')
        sys.exit(1)


def execute_spark(spark_session, file, source_table_name, good_table_name, doPreProcess, load_number, props, parameter_object, audit_control_file, source_file):

    def remove_char(df_object, column_list):
        for column_name in column_list:
            df_object = df_object.withColumn(column_name, regexp_replace(col(column_name), ',', ''))
        return df_object

    if not source_table_name:
        file_logger.debug('The target hive table is not defined, so exiting the process.')
        sys.exit(1)
    col_name = props['TS_COLUMN_NAME']
    new_col_name = col_name + '_copy'
    file_logger.debug('File name ' + file)
    if doPreProcess == 'true':
        source_system_id = parameter_object.source_system_identifier

        query = "desc " + source_table_name
        col_list, data_type_list, nullable_list = file_helper.read_schema_from_hive(props['REGEX_DESCRIBE'], query, props['JDBC_URL_BEELINE'])

        # col_list, data_type_list, nullable_list = file_helper.read_schema_from_hive_using_collect(spark_session, query)

        file_logger.debug('Schema from hive')
        file_logger.debug(col_list)

        table_cols = col_list[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):]
        table_data_type_list = data_type_list[int(props['COUNT_EXCLUDING_PRE_PROCESS_COLUMNS']):]
        columns_int_list = []
        column_decimal_list = []
        for column, data_type in zip(table_cols, table_data_type_list):
            if data_type == props['INT']:
                columns_int_list.append(column)
            elif props['DECIMAL'] in data_type:
                column_decimal_list.append(column)

        df = read_data_file(spark_session, file, table_cols, parameter_object, source_file)

        if parameter_object.extension.lower() != props['XLSX'].lower():
            if parameter_object.is_header_included.lower() == 'n':
                df_header = df.filter(lower(df[table_cols[0]]) == table_cols[0].lower())
                if df_header.count() > 0:
                    file_logger.debug("Header is set to False and file has header. So File is rejected.")
                    return None, False, False
                else:
                    file_logger.debug("Header is set to False and file does not have header.")
            else:
                df_header = df.filter(lower(df[table_cols[0]]) == table_cols[0].lower())
                if df_header.count() <= 0:
                    file_logger.debug("Header is set to True and file does not have header. So File is rejected.")
                    return None, False, False
                else:
                    df = df.filter(lower(df[table_cols[0]]) != table_cols[0].lower())
                    file_logger.debug("Header is set to True and file has header. So removing the header from data.")
        else:
            file_logger.debug("Excel File header is checked while loading data")
        df = remove_char(df, columns_int_list)
        df = remove_char(df, column_decimal_list)

        df_count = df.count()
        file_logger.debug('The df_count is ' + str(df_count))

        if parameter_object.is_control_file.lower() == 'y':
            record_count = file_helper.read_ctrl_file(audit_control_file)
            if int(record_count) > 0:
                if df_count == int(record_count):
                    file_logger.debug('The control file validation successful')
                else:
                    file_logger.debug('The record count does not match')
                    sys.exit(1)
        #system_id, log_ind, insert_ts, load_job_number, insert_ts
        insert_ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        spark_session.sql("SET hive.exec.dynamic.partition = true")
        spark_session.sql("SET hive.exec.dynamic.partition.mode = nonstrict ")
        # partition_col = props['PARTITION_COLUMN_NAME'] .withColumn(partition_col, concat(substring(from_unixtime(unix_timestamp()), 1, 4),substring(from_unixtime(unix_timestamp()), 6, 2)).cast(IntegerType()))
        indicator = None
        if parameter_object.logical_flag.lower() == 'y':
            indicator = lit(parameter_object.logical_flag_value)
        else:
            indicator = col(parameter_object.logical_flag_value)
        if df_count > 0:
            select_columns = [col(column).cast("string") for column in col_list]
            if bow_id_arg != props['PRODUCT_FILES_SYSTEM'] and parameter_object.bow_name.lower() != 'apollo':
                df = df.withColumn("source_system_identifier", lit(source_system_id)).withColumn("logical_deletion_indicator", indicator).withColumn("insert_gmt_timestamp", lit(insert_ts)).withColumn("load_job_number", lit(load_number)).withColumn("source_system_extract_gmt_timestamp", lit(insert_ts)).withColumn("source_system_updated_timestamp", lit(insert_ts)).select(select_columns)

            elif bow_id_arg == props['PRODUCT_FILES_SYSTEM']:
                df_max_date = spark_session.sql("select max(distinct " + props['PARTITION_COLUMN_NAME'] + ") as max_date from " + good_table_name)
                max_date_value = None
                max_src_sys_upd_ts = None
                if df_max_date.head()[0] is not None:
                    max_date_value = str(df_max_date.head()[0])
                    file_logger.debug(max_date_value)
                if max_date_value is not None:
                    df_max_src_sys_upd_ts = spark_session.sql("select max(" + props['SOURCE_SYSTEM_UPDATED_TIMESTAMP'] + ") from " + good_table_name + " where " + props['PARTITION_COLUMN_NAME'] + "= " + max_date_value)
                    if df_max_src_sys_upd_ts.head()[0] is not None:
                        max_src_sys_upd_ts = str(df_max_src_sys_upd_ts.head()[0])
                        file_logger.debug(max_src_sys_upd_ts)
                if max_src_sys_upd_ts is not None:
                    df = df.filter(props['SOURCE_SYSTEM_UPDATED_TIMESTAMP'] + " > '" + max_src_sys_upd_ts + "'")
                    file_logger.debug('The df_count after max date filtration is ' + str(df.count()))
                if df.count() <= 0:
                    return None, False, True
                df = df.withColumn("source_system_identifier", lit(source_system_id)).withColumn("logical_deletion_indicator", indicator).withColumn("insert_gmt_timestamp",lit(insert_ts)).withColumn("load_job_number",lit(load_number)).withColumn("source_system_extract_gmt_timestamp", lit(insert_ts)).withColumn("source_system_updated_timestamp",col(props['SOURCE_SYSTEM_UPDATED_TIMESTAMP'])).select(select_columns)

            elif parameter_object.bow_name.lower() == 'apollo':
                df_max_date = spark_session.sql("select max(distinct " + props[
                    'PARTITION_COLUMN_NAME'] + ") as max_date from " + good_table_name)
                max_date_value = None
                max_src_sys_upd_ts = None
                if df_max_date.head()[0] is not None:
                    max_date_value = str(df_max_date.head()[0])
                    file_logger.debug(max_date_value)
                if max_date_value is not None:
                    df_max_src_sys_upd_ts = spark_session.sql("select max(" + parameter_object.increment_value + ") from " + good_table_name + " where " + props['PARTITION_COLUMN_NAME'] + "= " + max_date_value)
                    if df_max_src_sys_upd_ts.head()[0] is not None:
                        max_src_sys_upd_ts = str(df_max_src_sys_upd_ts.head()[0])
                        file_logger.debug(max_src_sys_upd_ts)
                if max_src_sys_upd_ts is not None:
                    time_tuple = datetime.strptime(max_src_sys_upd_ts, "%m/%d/%Y %H:%M:%S").timetuple()
                    max_src_sys_upd_ts = int(time.mktime(time_tuple))  # convert to int here
                    tmp_column_name = parameter_object.increment_value + "_tmp"
                    df = df.withColumn(tmp_column_name, unix_timestamp(df[parameter_object.increment_value], format='MM/dd/yyyy HH:mm:ss'))
                    df = df.filter(tmp_column_name + " > " + str(max_src_sys_upd_ts)).drop(tmp_column_name)
                    file_logger.debug('The df_count after max date filtration is ' + str(df.count()))
                if df.count() <= 0:
                    return None, False, True
                df = df.withColumn("source_system_identifier", lit(source_system_id)).withColumn("logical_deletion_indicator", indicator).withColumn("insert_gmt_timestamp", lit(insert_ts)).withColumn("load_job_number", lit( load_number)).withColumn("source_system_extract_gmt_timestamp", lit(insert_ts)).withColumn("source_system_updated_timestamp", to_timestamp(parameter_object.increment_value,'MM/dd/yyyy HH:mm:ss')).select(select_columns)

            df.write.option("sep", props['COLUMN_SEPARATOR']).format('csv').insertInto(source_table_name, overwrite=True)
            return df, True, True
    return None, False, False


props = file_helper.read_all_properties(file_config)
pre_table_name = props['DATABASE_NAME']
do_pre_process = props['DO_PREPROCESS']
landing_path = ''
log_path = ''

all_parameter_obj = file_helper.load_file_control_ingestion(props, batch_id_arg, bow_id_arg, db_password, abcr_database_type)
for param_obj in all_parameter_obj:
    source_table = param_obj.lz_table_name
    good_table = param_obj.hst_table_name
    landing_path = param_obj.file_landing_path
    log_path = param_obj.log_path
    if not source_table.startswith(param_obj.hive_schema_name):
        source_table = param_obj.hive_schema_name + '.' + source_table
    if not good_table.startswith(param_obj.hive_schema_name):
        good_table = param_obj.hive_schema_name + '.' + good_table

    valid_files_dict, archive_files, reject_files_dict = file_validation.get_valid_files_dict(param_obj, props, file_logger)
    valid_files_list = list(valid_files_dict.keys())
    valid_files_list = file_helper.sorted_on_datetime(valid_files_list, param_obj.extension, param_obj.timestamp_pattern)
    file_logger.debug(valid_files_list)
    for source_file in valid_files_list:
        if os.path.isfile(source_file):
            try:
                start_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                log_control_data = [[int(bow_id_arg), int(sbow_id_arg), int(param_obj.uow_id), load_number_arg, start_date, start_date, None, None, 'R', batch_exec_id_arg, None, None, 0, 0, int(batch_id_arg), param_obj.job_name, 0, start_date]]
                ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                file_name = os.path.split(source_file)[-1]
                #file_name_without_ext = file_name.lower().rstrip('.' + param_obj.extension.lower())
                index_of_extension = file_name.lower().index('.' + param_obj.extension.lower())
                file_name_without_ext = file_name.lower()[0:index_of_extension]
                #print(file_name[0:index_of_extension-1])
                new_file = param_obj.hdfs_good_path.rstrip('/') + '/' + file_name
                date_time_value = re.search(param_obj.timestamp_pattern.lower(), file_name_without_ext).group(1)
                new_time_value = datetime.strptime(date_time_value, param_obj.timestamp_format).strftime('%Y-%m-%d %H:%M:%S.%f')

                source_system_id = param_obj.source_system_identifier

                file_logger.debug('The file name to be processed by spark ' + file_name + ' having datetime value as ' + new_time_value)

                file_df, is_lz_data_loaded, is_file_selected = execute_spark(spark_session_obj, new_file, source_table, good_table, do_pre_process, load_number_arg, props, param_obj, valid_files_dict[source_file], source_file)

                if not is_file_selected:
                    reject_files_dict = file_helper.update_reject_files(archive_files, param_obj.hdfs_reject_path, source_file, reject_files_dict, 'Header issue')

                if is_lz_data_loaded:
                    aux_control_data = [[int(bow_id_arg), param_obj.bow_name, new_time_value[:-3], new_time_value[:-3], None, None, param_obj.uow_id, 'timestamp', None, None, datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3], batch_exec_id_arg, int(batch_id_arg)]]

                    update_data_into_aux_control(spark_session_obj, pre_table_name, aux_control_data, props, db_password, abcr_database_type)

                if field_validation == '2' and is_lz_data_loaded:
                    source_count, target_count = table_validation.validate_parameter_obj(file_df, spark_session_obj, props, param_obj, file_logger)
                    end_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                    log_control_data = [[int(bow_id_arg), int(sbow_id_arg), int(param_obj.uow_id), load_number_arg, start_date, end_date, None, None, 'S', batch_exec_id_arg, None, None, source_count, target_count, int(batch_id_arg), param_obj.job_name, 0, end_date]]
                    ingest_data_into_log_control(spark_session_obj, log_control_data, props, db_password, abcr_database_type)
                if param_obj.is_part_file.lower() == 'y':
                    break
            except Exception as e:
                file_logger.debug("The source file ingestion issue: " + source_file)
                reject_files_dict = file_helper.update_reject_files(archive_files, param_obj.hdfs_reject_path, source_file, reject_files_dict, 'Source file issue')
                print(e)
    if field_validation == '2':
        file_load_hst_table_name = pre_table_name + props['FILE_LOAD_HST_TABLE']
        file_load_hst_data = file_helper.create_file_load_hst_data(int(bow_id_arg), int(batch_id_arg), int(param_obj.uow_id),param_obj.source_file_path, param_obj.file_landing_path, archive_files, batch_exec_id_arg, param_obj.archive_file_path)
        file_load_hst_df = file_helper.create_df(spark_session_obj, file_load_hst_data, file_load_hst_schema)
        # file_load_hst_df.write.mode("append").format("text").insertInto(file_load_hst_table_name, overwrite=False)
        file_helper.archive_source_files(archive_files, reject_files_dict, param_obj.archive_file_path)
        file_helper.clean_hadoop_working_path(param_obj.hdfs_good_path)
        file_helper.clean_local_working_path(archive_files)

app_id = spark_session_obj.sparkContext.applicationId
spark_session_obj.stop()

log_time_value = datetime.now().strftime('%Y%m%d%H%M%S')
log_file_name = landing_path.rstrip('/') + '/dq1_ingestion_batch_id_' + str(batch_id_arg) + '_bow_id_' + str(bow_id_arg) + '_' + log_time_value + '.log'
file_logger.debug("(log_file_name) " + log_file_name)
file_helper.generate_log(file_logger, log_file_name, app_id, 'dummy')
file_helper.move_log_files(landing_path, log_path)
sys.exit(0)
