package test.com.Kafkatest;

/**
 * Hello world!
 *
 */

import java.util.*;
import org.apache.kafka.clients.producer.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import test.com.Kafkatest.Supplier;
public class SimpleProducer {
  
   /*public static void main(String[] args) throws Exception{
           
      String topicName = "TestTopic";
	  String key = "Key1";
	  String value = "Value-1";
      
      Properties props = new Properties();
      props.put("bootstrap.servers", "10.0.135.10:9092");
      System.out.println("SimpleProducer Completed.");
      props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");         
      props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	        
      Producer<String, String> producer = new KafkaProducer <String, String>(props);
	
	  ProducerRecord<String, String> record = new ProducerRecord<String, String>(topicName,key,value);
	  producer.send(record);	       
      producer.close();
	  
	  System.out.println("SimpleProducer Completed.");
   }*/
	
	public static void main(String[] args) throws Exception{

	      String topicName = "TestTopic";
	      System.out.println("topic name is "+topicName);
	      Properties props = new Properties();
	      System.out.println("props called "+props);
	      props.put("bootstrap.servers", "10.0.135.10:6667");
	      System.out.println("props after bootstrap connected ");
	      props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
	      props.put("value.serializer","org.apache.kafka.common.serialization.StringSerializer");
	      System.out.println("props finished "+props.getProperty("value.serializer"));
	      Thread.currentThread().setContextClassLoader(null);
	      Producer<String, String> producer = new KafkaProducer <> (props);
	      System.out.println("producer called "+producer);
	          DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	          Supplier sp1 = new Supplier(101,"Xyz Pvt Ltd.",df.parse("2016-04-01"));
	          Supplier sp2 = new Supplier(102,"Abc Pvt Ltd.",df.parse("2012-01-01"));
	      System.out.println("before producer sending "+sp1.getID());
	         producer.send(new ProducerRecord<String,String>(topicName,"SUP",sp1.getName())).get();
	         producer.send(new ProducerRecord<String,String>(topicName,"SUP",sp2.getName())).get();

	                 System.out.println("SupplierProducer Completed.");
	         producer.close();

	   }
}
