package org.test
import kafka.serializer.{DefaultDecoder, StringDecoder}
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j.Logger
import org.apache.spark._
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}
import scopt.OptionParser

case class Params(hdfsHost: String = "", kafkaBootstrapServer: String = "", kafkaTopics: Seq[String] = Seq())

object WordCountStream extends App  {

  val logger = Logger.getLogger(getClass)



  val parser = new OptionParser[Params]("") {
    head("kafka example", "1.0")
    help("help") text "print this usage text"

    opt[String]("hdfs-host") required() action { (data, conf) =>
      conf.copy(hdfsHost = data)
    } text "URI of the hdfs host. Example: hdfs://IP:8020"

    opt[String]("kafka-bootstrap-server") required() action { (data, conf) =>
      conf.copy(kafkaBootstrapServer = data)
    } text "URI of the kafka server. Example: hdfs://IP:8020"

    opt[Seq[String]]("kafka-topics") valueName "TestTopic" required() action { (data, conf) =>
      conf.copy(kafkaTopics = data)
    } text "Topics to consume"
  }

  parser.parse(args, Params()) match {
    case Some(params) =>
      logger.info(s"Params: $params")
      startStreaming(params)
    case None =>
  }

    def startStreaming(Param: Params ) = {
 // def main( args:Array[String] ){
      val conf = new SparkConf().setMaster("local[*]").setAppName("KafkaReceiver")
      //val spark_session = SparkSession.builder().config(conf)
      val ssc = new StreamingContext(conf, Seconds(10))
      val topics = List("TestTopic")
     val preferredHosts = LocationStrategies.PreferConsistent
     println("topics:-----------" ,topics)
      val kafkaConf = Map[String,Object](
      /*"bootstrap.servers"->"ip-10-0-140-166.ec2.internal:6667",*/
      "bootstrap.servers"->Param.kafkaBootstrapServer,
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "spark-streaming-notes",
      "auto.offset.reset" -> "earliest"
    )
    val kafkaStream = KafkaUtils.createDirectStream[String, String](ssc,preferredHosts,ConsumerStrategies.Subscribe[String, String](Param.kafkaTopics, kafkaConf))
    println("kafkaConf:-----------" ,kafkaConf.get("bootstrap.servers"))
    //val kafkaStream = KafkaUtils.createDirectStream[String, String](ssc,LocationStrategies.PreferConsistent,ConsumerStrategies.Subscribe[String, String](topics, kafkaConf,offsets))
    /*val lines = kafkaStream.map(_.value)
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1L)).reduceByKey(_ + _)*/

    val rdds = kafkaStream.map(r => (r.key, r.value()))
        rdds.saveAsTextFiles(Param.hdfsHost +"/user/hdfs/a_test" , "abc")

      rdds.foreachRDD { rdd =>
        if (!rdd.isEmpty()) {
          rdd.saveAsTextFile(Param.hdfsHost +"/user/hdfs/a_test")

          rdd.foreach(r => logger.info("key: %s, value %s".format(r._1, r._2)))
        }
      }
       //prints the wordcount result of the stream*/
    ssc.start()
    ssc.awaitTermination()
  }
}

