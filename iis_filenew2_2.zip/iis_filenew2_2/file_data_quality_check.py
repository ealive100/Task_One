"""This script invokes data quality file validation spark job with expected spark job properties configured in spark submit command."""

import sys
import os
import data_quality_helper as file_helper

PYTHON_PATH = sys.argv[1]
LIBRARY_PATH = sys.argv[2]
CONFIGURATION_PATH = sys.argv[3]
BATCH_ID = sys.argv[4]
BOW_ID = sys.argv[5]
LOAD_JOB_NUMBER = sys.argv[6]
BATCH_EXECUTION_ID = sys.argv[7]
SBOW_ID = sys.argv[8]
FIELD_VALIDATION_INDICATOR = sys.argv[9]
DB_PASSWORD = sys.argv[10]
ABCR_DB_TYPE = sys.argv[11]
secret_password = '@'.join([str(ord(c)) for c in DB_PASSWORD])

print("(python_path) " + PYTHON_PATH)
print("(lib_path) " + LIBRARY_PATH)
print("(config_path) " + CONFIGURATION_PATH)
print("Arguments are : arg 1 (batch_id) " + BATCH_ID)
print("Arguments are : arg 2 (bow_id) " + BOW_ID)
print("Arguments are : arg 3 (load_number) " + LOAD_JOB_NUMBER)
print("Arguments are : arg 4 (batch_exec_id) " + BATCH_EXECUTION_ID)
print("Arguments are : arg 5 (sbow_id) " + SBOW_ID)
print("Arguments are : arg 6 (field_validation) " + FIELD_VALIDATION_INDICATOR)
print("Arguments are : arg 7 (DB_PASSWORD) " + secret_password)
print("Arguments are : arg 8 (ABCR_DB_TYPE) " + ABCR_DB_TYPE)

FILE_CONFIG = CONFIGURATION_PATH.rstrip('/') + '/data_quality_config.ini'

DATA_QUALITY_PROPERTIES = file_helper.read_all_properties(FILE_CONFIG)

#SERVICE_USER_NAME = DATA_QUALITY_PROPERTIES['USER']
#SERVICE_USER_CERTIFICATE = DATA_QUALITY_PROPERTIES['KEYTAB']
#os.system('pbrun su - ' + SERVICE_USER_NAME)
#os.system(SERVICE_USER_CERTIFICATE)

SPARK_JOB_MODE = DATA_QUALITY_PROPERTIES['DEPLOY_MODE']
SPARK_DRIVER_MEMORY = DATA_QUALITY_PROPERTIES['DRIVER_MEMORY']
SPARK_EXECUTOR_MEMORY = DATA_QUALITY_PROPERTIES['EXECUTOR_MEMORY']
SPARK_NUMBER_OF_EXECUTORS = DATA_QUALITY_PROPERTIES['NUM_OF_EXECUTOR']
SPARK_JOB_QUEUE = DATA_QUALITY_PROPERTIES['JOB_QUEUE']
SPARK_NUMBER_OF_EXECUTOR_CORE = DATA_QUALITY_PROPERTIES['EXECUTOR_CORES']
HIVE_CONFIGURATION_PATH = DATA_QUALITY_PROPERTIES['HIVE_CONFIG_PATH']

LIBRARY_PATH = LIBRARY_PATH.rstrip('/') + '/'
PYTHON_PATH = PYTHON_PATH.rstrip('/') + '/'
SPARK_EXECUTION_SCRIPT = PYTHON_PATH + DATA_QUALITY_PROPERTIES['FILE_INGESTION_PY_SCRIPT']
LIBRARY_REQUIRED = ','.join([LIBRARY_PATH + SPARK_JAR for SPARK_JAR in DATA_QUALITY_PROPERTIES['SPARK_JARS_REQUIRED'].split(',')])
#LIBRARY_REQUIRED = LIBRARY_PATH.rstrip('/') + '/spark-csv_2.11-1.5.0.jar,' + LIBRARY_PATH.rstrip('/') + '/spark-excel_2.11-0.8.6.jar,' + LIBRARY_PATH.rstrip('/') + '/spark-xml_2.11-0.5.0.jar'

if FIELD_VALIDATION_INDICATOR == '2':
    PYTHON_SCRIPTS_REQUIRED = ','.join([PYTHON_PATH + SPARK_JAR for SPARK_JAR in DATA_QUALITY_PROPERTIES['PY_SCRIPTS_FOR_DQ_1_2'].split(',')]) + ',' + ','.join([LIBRARY_PATH + LIB_SCRIPT for LIB_SCRIPT in DATA_QUALITY_PROPERTIES['LIB_SCRIPTS_FOR_DQ_1_2'].split(',')])
else:
    PYTHON_SCRIPTS_REQUIRED = ','.join([PYTHON_PATH + SPARK_JAR for SPARK_JAR in DATA_QUALITY_PROPERTIES['PY_SCRIPTS_FOR_DQ_1'].split(',')]) + ',' + ','.join([LIBRARY_PATH + LIB_SCRIPT for LIB_SCRIPT in DATA_QUALITY_PROPERTIES['LIB_SCRIPTS_FOR_DQ_1_2'].split(',')])
print("PYTHON_SCRIPTS_REQUIRED check " + PYTHON_SCRIPTS_REQUIRED)
#SPARK_SUBMIT_ARGUMENTS = ['export SPARK_MAJOR_VERSION=2; spark-submit --master yarn --deploy-mode', SPARK_JOB_MODE, '--jars', LIBRARY_REQUIRED, '--driver-memory', SPARK_DRIVER_MEMORY, '--executor-memory', SPARK_EXECUTOR_MEMORY, '--num-executors', SPARK_NUMBER_OF_EXECUTORS, '--executor-cores', SPARK_NUMBER_OF_EXECUTOR_CORE, '--queue', SPARK_JOB_QUEUE, '--py-files', PYTHON_SCRIPTS_REQUIRED, '--files', HIVE_CONFIGURATION_PATH, SPARK_EXECUTION_SCRIPT, BATCH_ID, BOW_ID, LOAD_JOB_NUMBER, BATCH_EXECUTION_ID, SBOW_ID, FILE_CONFIG, FIELD_VALIDATION_INDICATOR, secret_password, ABCR_DB_TYPE]
SPARK_SUBMIT_ARGUMENTS = ['export SPARK_MAJOR_VERSION=2; spark-submit --master local[*]', '--jars', LIBRARY_REQUIRED, '--py-files', PYTHON_SCRIPTS_REQUIRED, '--files', HIVE_CONFIGURATION_PATH, SPARK_EXECUTION_SCRIPT, BATCH_ID, BOW_ID, LOAD_JOB_NUMBER, BATCH_EXECUTION_ID, SBOW_ID, FILE_CONFIG, FIELD_VALIDATION_INDICATOR, secret_password, ABCR_DB_TYPE]
os.system(' '.join(SPARK_SUBMIT_ARGUMENTS))
