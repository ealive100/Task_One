/home/centos/spark_dq/iis_File_new/script/data_quality_check.sh 3 6 12345 abcd1234de 5 2 root 1
