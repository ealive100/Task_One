#!/bin/sh
python_path=/home/centos/spark_dq/iis_File_new/python
lib_path=/home/centos/spark_dq/iis_File_new/lib
config_path=/home/centos/spark_dq/iis_File_new/configuration
batch_id=${1}
bow_id=${2}
load_number=${3}
batch_exec_id=${4}
sbow_id=${5}
dq_process_type=${6}
db_password=${7}
abcr_db_type=${8}
file_crm_ingestion=0

if [[ "$dq_process_type" -eq 0 ]];then
       echo "dq1 process being called."
       python $python_path/file_data_quality_check.py $python_path $lib_path $config_path $batch_id $bow_id $load_number $batch_exec_id $sbow_id $dq_process_type $db_password $abcr_db_type
    elif [[ "$dq_process_type" -eq 1 ]]
    then
	echo "dq2 process being called."
	python $python_path/table_data_quality_check.py $python_path $lib_path $config_path $batch_id $bow_id $load_number $batch_exec_id $sbow_id $file_crm_ingestion
    elif [[ "$dq_process_type" -eq 2 ]]
    then
	echo "dq1 and dq2 process being called."
	python $python_path/file_data_quality_check.py $python_path $lib_path $config_path $batch_id $bow_id $load_number $batch_exec_id $sbow_id $dq_process_type $db_password $abcr_db_type
	#python $python_path/table_data_quality_check.py $python_path $lib_path $config_path $batch_id $bow_id $logical_deletion_indicator $load_number $batch_exec_id $sbow_id $file_crm_ingestion
    else
       echo "Unknown argument, Please use 0, 1, 2 values for last (4th) argument."
    fi
