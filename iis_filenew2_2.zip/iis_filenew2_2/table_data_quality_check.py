"""This script invokes data quality field validation spark job with expected spark job properties configured in spark submit command."""

import sys
import os
import data_quality_helper

PYTHON_PATH = sys.argv[1]
LIBRARY_PATH = sys.argv[2]
CONFIGURATION_PATH = sys.argv[3]
BATCH_ID = sys.argv[4]
BOW_ID = sys.argv[5]
LOAD_JOB_NUMBER = sys.argv[6]
BATCH_EXECUTION_ID = sys.argv[7]
SBOW_ID = sys.argv[8]
FILE_CRM_INGESTION = sys.argv[9]

print("(python_path) " + PYTHON_PATH)
print("(lib_path) " + LIBRARY_PATH)
print("(config_path) " + CONFIGURATION_PATH)
print("Arguments are : arg 1 (batch_id) " + BATCH_ID)
print("Arguments are : arg 2 (bow_id) " + BOW_ID)
print("Arguments are : arg 3 (load_number) " + LOAD_JOB_NUMBER)
print("Arguments are : arg 4(batch_exec_id) " + BATCH_EXECUTION_ID)
print("Arguments are : arg 5 (sbow_id) " + SBOW_ID)
print("Arguments are : arg 6 (file_crm_ingestion) " + FILE_CRM_INGESTION)

FIELD_CONFIG = CONFIGURATION_PATH.rstrip('/') + '/data_quality_config.ini'
DATA_QUALITY_PROPERTIES = data_quality_helper.read_all_properties(FIELD_CONFIG)

#SERVICE_USER_NAME = DATA_QUALITY_PROPERTIES['USER']
#SERVICE_USER_CERTIFICATE = DATA_QUALITY_PROPERTIES['KEYTAB']
#os.system('pbrun su - ' + SERVICE_USER_NAME)
#os.system(SERVICE_USER_CERTIFICATE)

SPARK_JOB_MODE = DATA_QUALITY_PROPERTIES['DEPLOY_MODE']
SPARK_DRIVER_MEMORY = DATA_QUALITY_PROPERTIES['EXECUTOR_MEMORY']
SPARK_EXECUTOR_MEMORY = DATA_QUALITY_PROPERTIES['NUM_OF_EXECUTOR']
SPARK_JOB_QUEUE = DATA_QUALITY_PROPERTIES['JOB_QUEUE']
SPARK_NUMBER_OF_EXECUTOR_CORE = DATA_QUALITY_PROPERTIES['EXECUTOR_CORES']
HIVE_CONFIGURATION_PATH = DATA_QUALITY_PROPERTIES['HIVE_CONFIG_PATH']

SPARK_EXECUTION_SCRIPT = PYTHON_PATH.rstrip('/') + '/table_ingestion.py'
PYTHON_SCRIPTS_REQUIRED = PYTHON_PATH.rstrip('/') + '/table_validation.py,' + PYTHON_PATH.rstrip('/') + '/data_quality_helper.py,' + PYTHON_PATH.rstrip('/') + '/data_quality_configuration.py'
LIBRARY_REQUIRED = LIBRARY_PATH.rstrip('/') + '/spark-avro_2.10-3.1.0.jar'

#SPARK_SUBMIT_ARGUMENTS = ['export SPARK_MAJOR_VERSION=2; spark-submit --master yarn --deploy-mode', SPARK_JOB_MODE, '--jars', LIBRARY_REQUIRED, '--executor-memory', SPARK_DRIVER_MEMORY, '--num-executors', SPARK_EXECUTOR_MEMORY, '--executor-cores', SPARK_NUMBER_OF_EXECUTOR_CORE, '--queue', SPARK_JOB_QUEUE, '--py-files', PYTHON_SCRIPTS_REQUIRED, '--files', HIVE_CONFIGURATION_PATH, SPARK_EXECUTION_SCRIPT, BATCH_ID, BOW_ID, LOAD_JOB_NUMBER, BATCH_EXECUTION_ID, SBOW_ID, FILE_CRM_INGESTION, FIELD_CONFIG]
SPARK_SUBMIT_ARGUMENTS = ['export SPARK_MAJOR_VERSION=2; spark-submit --master local[*]', '--jars', LIBRARY_REQUIRED, '--py-files', PYTHON_SCRIPTS_REQUIRED, '--files', HIVE_CONFIGURATION_PATH, SPARK_EXECUTION_SCRIPT, BATCH_ID, BOW_ID, LOAD_JOB_NUMBER, BATCH_EXECUTION_ID, SBOW_ID, FILE_CRM_INGESTION, FIELD_CONFIG]
os.system(' '.join(SPARK_SUBMIT_ARGUMENTS))
